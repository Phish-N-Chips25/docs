#!/usr/bin/env python3
"""
Concurrent test script to validate multi-user performance.
Outputs saved under Tests/results.
"""

import requests
import json
import time
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed
from collections import defaultdict
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent
RESULTS_DIR = BASE_DIR / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

# Configuration
API_ENDPOINT = "http://localhost:8080/evaluate"
OPENPHISH_FEED = "https://openphish.com/feed.txt"
TEST_LIMIT = 1000  # Number of phishing URLs to test
CONCURRENT_WORKERS = 10  # Number of parallel requests

# Legitimate URLs for false positive testing
LEGITIMATE_URLS = [
    "https://www.google.com",
    "https://www.facebook.com",
    "https://www.amazon.com",
    "https://www.microsoft.com",
    "https://www.github.com",
    "https://www.apple.com",
    "https://www.twitter.com",
    "https://www.linkedin.com",
    "https://www.wikipedia.org",
    "https://www.reddit.com",
    "https://www.youtube.com",
    "https://www.netflix.com",
    "https://www.paypal.com",
    "https://www.ebay.com",
    "https://www.stackoverflow.com"
]


def fetch_phishing_urls(limit=TEST_LIMIT):
    """Fetch recent phishing URLs from OpenPhish"""
    print(f"[*] Fetching {limit} phishing URLs from OpenPhish...")
    try:
        response = requests.get(OPENPHISH_FEED, timeout=10)
        response.raise_for_status()
        urls = response.text.strip().split('\n')[:limit]
        print(f"[+] Fetched {len(urls)} phishing URLs")
        return urls
    except Exception as e:
        print(f"[!] Error fetching URLs: {e}")
        return []


def test_url(index, url, expected_malicious=True):
    """Test a single URL against the API"""
    start_time = time.time()
    try:
        payload = {"url": url}
        response = requests.post(API_ENDPOINT, json=payload, timeout=60)
        elapsed = time.time() - start_time

        if response.status_code == 200:
            result = response.json()
            status = result.get("status", "UNKNOWN")
            score = result.get("score", result.get("finalScore", 0))
            triggered_rules = result.get("totalRulesTriggered", 0)

            triggered_rules_map = result.get("triggeredRules", {})
            dom_executed = any("DOM:" in rule_name for rule_name in triggered_rules_map.keys())

            # Binary policy: PHISHING and PROBABLE_PHISHING are considered detected phishing; SUSPICIOUS is not
            detected_phishing = status in ["PHISHING", "PROBABLE_PHISHING"]
            correct = (detected_phishing if expected_malicious else not detected_phishing)

            return {
                "index": index,
                "url": url,
                "status": status,
                "score": score,
                "triggered_rules": triggered_rules,
                "dom_executed": dom_executed,
                "expected_malicious": expected_malicious,
                "correct": correct,
                "success": True,
                "elapsed": elapsed
            }
        else:
            return {
                "index": index,
                "url": url,
                "status": "ERROR",
                "score": 0,
                "triggered_rules": 0,
                "dom_executed": False,
                "expected_malicious": expected_malicious,
                "correct": False,
                "success": False,
                "elapsed": elapsed,
                "error": f"HTTP {response.status_code}"
            }
    except requests.exceptions.Timeout:
        elapsed = time.time() - start_time
        return {
            "index": index,
            "url": url,
            "status": "TIMEOUT",
            "score": 0,
            "triggered_rules": 0,
            "dom_executed": False,
            "expected_malicious": expected_malicious,
            "correct": False,
            "success": False,
            "elapsed": elapsed,
            "error": "Request timeout"
        }
    except Exception as e:
        elapsed = time.time() - start_time
        return {
            "index": index,
            "url": url,
            "status": "ERROR",
            "score": 0,
            "triggered_rules": 0,
            "dom_executed": False,
            "expected_malicious": expected_malicious,
            "correct": False,
            "success": False,
            "elapsed": elapsed,
            "error": str(e)
        }


def print_concurrent_progress(completed, total, elapsed_time):
    pct = (completed / total) * 100
    throughput = completed / elapsed_time if elapsed_time > 0 else 0
    print(f"\r[Progress] {completed}/{total} ({pct:.1f}%) | {elapsed_time:.1f}s | {throughput:.2f} req/s", end='', flush=True)


def print_results_table(results):
    print("\n" + "="*135)
    print("CONCURRENT TEST RESULTS")
    print("="*135)
    print(f"{'#':<4} {'Type':<12} {'Result':<8} {'Verdict':<20} {'Score':<6} {'DOM':<5} {'Time':<8} {'URL':<60}")
    print("-" * 135)
    for r in sorted(results, key=lambda x: x["index"]):
        expected_type = "PHISHING" if r["expected_malicious"] else "LEGITIMATE"
        result_icon = "✓" if r["correct"] else "✗"
        verdict = r["status"]
        score = r["score"]
        dom_icon = "✓" if r.get("dom_executed", False) else "✗"
        elapsed = f"{r['elapsed']:.2f}s"
        url = r["url"]
        if len(url) > 60:
            url = url[:57] + "..."
        print(f"{r['index']:<4} {expected_type:<12} {result_icon:<8} {verdict:<20} {score:<6} {dom_icon:<5} {elapsed:<8} {url:<60}")
    print("="*135)


def print_statistics(results, total_elapsed):
    total = len(results)
    successful = sum(1 for r in results if r["success"])
    correct = sum(1 for r in results if r["correct"])
    phishing_urls = [r for r in results if r["expected_malicious"]]
    legitimate_urls = [r for r in results if not r["expected_malicious"]]
    true_positives = sum(1 for r in phishing_urls if r["correct"] and r["success"]) 
    false_negatives = sum(1 for r in phishing_urls if not r["correct"] and r["success"]) 
    true_negatives = sum(1 for r in legitimate_urls if r["correct"] and r["success"]) 
    false_positives = sum(1 for r in legitimate_urls if not r["correct"] and r["success"]) 
    successful_requests = [r for r in results if r["success"]]
    if successful_requests:
        avg_time = sum(r["elapsed"] for r in successful_requests) / len(successful_requests)
        min_time = min(r["elapsed"] for r in successful_requests)
        max_time = max(r["elapsed"] for r in successful_requests)
    else:
        avg_time = min_time = max_time = 0
    throughput = total / total_elapsed if total_elapsed > 0 else 0
    print("\n" + "="*70)
    print("PERFORMANCE STATISTICS")
    print("="*70)
    print(f"\nTotal wall-clock time: {total_elapsed:.2f}s")
    print(f"Average request time: {avg_time:.2f}s")
    print(f"Min request time: {min_time:.2f}s")
    print(f"Max request time: {max_time:.2f}s")
    print(f"Throughput: {throughput:.2f} requests/second")
    print(f"Concurrency level: {CONCURRENT_WORKERS} workers")
    print("\n" + "="*70)
    print("DETECTION STATISTICS")
    print("="*70)
    print(f"\nTotal tests: {total}")
    print(f"  - Phishing URLs tested: {len(phishing_urls)}")
    print(f"  - Legitimate URLs tested: {len(legitimate_urls)}")
    print(f"  - Successful requests: {successful}/{total} ({successful/total*100:.1f}%)")
    print(f"\nDetection Accuracy:")
    accuracy_pct = (correct/successful*100) if successful > 0 else 0.0
    print(f"  - Correct classifications: {correct}/{successful} ({accuracy_pct:.1f}%)")
    print(f"  - True Positives (phishing detected): {true_positives}")
    print(f"  - True Negatives (legitimate detected): {true_negatives}")
    print(f"  - False Positives (legitimate flagged): {false_positives}")
    print(f"  - False Negatives (phishing missed): {false_negatives}")
    if len(phishing_urls) > 0 and sum(1 for r in phishing_urls if r["success"]) > 0:
        phishing_detection_rate = true_positives / sum(1 for r in phishing_urls if r["success"]) * 100
        print(f"\nPhishing Detection Rate: {phishing_detection_rate:.1f}%")
    if len(legitimate_urls) > 0 and sum(1 for r in legitimate_urls if r["success"]) > 0:
        legitimate_detection_rate = true_negatives / sum(1 for r in legitimate_urls if r["success"]) * 100
        print(f"Legitimate Detection Rate: {legitimate_detection_rate:.1f}%")
    dom_executed_count = sum(1 for r in results if r.get("dom_executed", False) and r["success"]) 
    dom_execution_rate = (dom_executed_count / successful * 100) if successful > 0 else 0
    print(f"\nDOM Analysis Execution:")
    print(f"  - URLs analyzed with DOM: {dom_executed_count}/{successful} ({dom_execution_rate:.1f}%)")
    print("\n" + "="*70)


def main():
    print("="*70)
    print("CONCURRENT PHISHING URL DETECTION TEST")
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)
    try:
        health_check = requests.get("http://localhost:8080/health", timeout=5)
        if health_check.status_code != 200:
            print("[!] API health check failed. Is the server running on port 8080?")
            return
        print("[+] API is running")
    except Exception as e:
        print(f"[!] Cannot connect to API: {e}")
        print("[!] Make sure the server is running: mvn spring-boot:run")
        return
    phishing_urls = fetch_phishing_urls(TEST_LIMIT)
    if not phishing_urls:
        print("[!] No phishing URLs fetched. Exiting.")
        return
    all_tests = [(i+1, url, True) for i, url in enumerate(phishing_urls)] + \
                [(len(phishing_urls)+i+1, url, False) for i, url in enumerate(LEGITIMATE_URLS)]
    total_tests = len(all_tests)
    print(f"\n[*] Starting concurrent tests ({total_tests} total URLs)...")
    print(f"    - {len(phishing_urls)} phishing URLs")
    print(f"    - {len(LEGITIMATE_URLS)} legitimate URLs")
    print(f"    - Concurrency: {CONCURRENT_WORKERS} parallel workers\n")
    results = []
    start_time = time.time()
    completed = 0
    with ThreadPoolExecutor(max_workers=CONCURRENT_WORKERS) as executor:
        future_to_test = {
            executor.submit(test_url, index, url, is_malicious): (index, url, is_malicious)
            for index, url, is_malicious in all_tests
        }
        for future in as_completed(future_to_test):
            result = future.result()
            results.append(result)
            completed += 1
            elapsed = time.time() - start_time
            print_concurrent_progress(completed, total_tests, elapsed)
    print()
    total_elapsed = time.time() - start_time
    print_results_table(results)
    print_statistics(results, total_elapsed)
    output_file = RESULTS_DIR / f"concurrent-test-results.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "total_tests": total_tests,
            "execution_time": total_elapsed,
            "concurrent_workers": CONCURRENT_WORKERS,
            "results": results
        }, f, indent=2)
    print(f"\nDetailed results saved to: {output_file}")


if __name__ == "__main__":
    main()
