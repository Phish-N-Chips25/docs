#!/usr/bin/env python3
"""
Test script to validate phishing detection against real-world URLs from OpenPhish.
Fetches recent phishing URLs and tests them against the local API with concurrent execution.
"""

import requests
import json
import time
from datetime import datetime
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent
RESULTS_DIR = BASE_DIR / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

# Configuration
API_ENDPOINT = "http://localhost:8080/evaluate"
OPENPHISH_FEED = "https://openphish.com/feed.txt"
TEST_LIMIT = 100  # Number of phishing URLs to test from OpenPhish
CONCURRENT_WORKERS = 10  # Number of concurrent requests
REQUEST_DELAY = 0.1  # Delay between requests (seconds) for sequential mode

# Legitimate URLs for false positive testing
LEGITIMATE_URLS = [
    "https://www.google.com",
    "https://www.facebook.com",
    "https://www.amazon.com",
    "https://www.microsoft.com",
    "https://www.github.com",
    "https://www.apple.com",
    "https://www.twitter.com",
    "https://www.linkedin.com",
    "https://www.wikipedia.org",
    "https://www.reddit.com",
    "https://www.youtube.com",
    "https://www.netflix.com",
    "https://www.paypal.com",
    "https://www.ebay.com",
    "https://www.stackoverflow.com"
]


def fetch_phishing_urls(limit=TEST_LIMIT):
    """Fetch recent phishing URLs from OpenPhish"""
    print(f"[*] Fetching {limit} phishing URLs from OpenPhish...")
    try:
        response = requests.get(OPENPHISH_FEED, timeout=10)
        response.raise_for_status()
        urls = response.text.strip().split('\n')[:limit]
        print(f"[+] Fetched {len(urls)} phishing URLs")
        return urls
    except Exception as e:
        print(f"[!] Error fetching URLs: {e}")
        return []


def test_url(url, expected_malicious=True):
    """Test a single URL against the API"""
    try:
        payload = {"url": url}
        response = requests.post(API_ENDPOINT, json=payload, timeout=60)

        if response.status_code == 200:
            result = response.json()
            status = result.get("status", "UNKNOWN")
            score = result.get("finalScore", 0)
            triggered_rules = result.get("totalRulesTriggered", 0)
            rules_list = result.get("rulesFired", [])

            # Check if DOM analysis was executed by looking for DOM rules
            dom_executed = any("DOM:" in rule.get("ruleName", "") for rule in rules_list)

            # Determine if detection was correct
            is_malicious = status in ["PHISHING", "PROBABLE_PHISHING", "SUSPICIOUS"]
            correct = is_malicious == expected_malicious

            return {
                "url": url,
                "status": status,
                "score": score,
                "triggered_rules": triggered_rules,
                "dom_executed": dom_executed,
                "expected_malicious": expected_malicious,
                "correct": correct,
                "success": True
            }
        else:
            return {
                "url": url,
                "status": "ERROR",
                "score": 0,
                "triggered_rules": 0,
                "dom_executed": False,
                "expected_malicious": expected_malicious,
                "correct": False,
                "success": False,
                "error": f"HTTP {response.status_code}"
            }
    except requests.exceptions.Timeout:
        return {
            "url": url,
            "status": "TIMEOUT",
            "score": 0,
            "triggered_rules": 0,
            "dom_executed": False,
            "expected_malicious": expected_malicious,
            "correct": False,
            "success": False,
            "error": "Request timeout"
        }
    except Exception as e:
        return {
            "url": url,
            "status": "ERROR",
            "score": 0,
            "triggered_rules": 0,
            "dom_executed": False,
            "expected_malicious": expected_malicious,
            "correct": False,
            "success": False,
            "error": str(e)
        }


def print_result(result, index, total):
    """Print a single test result"""
    status_icon = "✓" if result["correct"] else "✗"
    expected = "PHISHING" if result["expected_malicious"] else "LEGITIMATE"
    dom_status = "DOM: ✓" if result.get("dom_executed", False) else "DOM: ✗"

    print(f"\n[{index}/{total}] {status_icon} {expected}")
    print(f"  URL: {result['url'][:80]}{'...' if len(result['url']) > 80 else ''}")
    print(f"  Verdict: {result['status']} (score: {result['score']}, rules: {result['triggered_rules']}, {dom_status})")

    if not result["success"]:
        print(f"  Error: {result.get('error', 'Unknown')}")


def print_url_summary_table(results):
    """Print a summary table of all tested URLs"""
    print("\n" + "="*135)
    print("URL SUMMARY TABLE")
    print("="*135)

    # Header
    print(f"{'#':<4} {'Type':<12} {'Result':<8} {'Verdict':<20} {'Score':<6} {'DOM':<5} {'URL':<70}")
    print("-" * 135)

    for idx, r in enumerate(results, 1):
        expected_type = "PHISHING" if r["expected_malicious"] else "LEGITIMATE"
        result_icon = "✓" if r["correct"] else "✗"
        verdict = r["status"]
        score = r["score"]
        dom_icon = "✓" if r.get("dom_executed", False) else "✗"
        url = r["url"]

        # Truncate URL if too long
        if len(url) > 70:
            url = url[:67] + "..."

        print(f"{idx:<4} {expected_type:<12} {result_icon:<8} {verdict:<20} {score:<6} {dom_icon:<5} {url:<70}")

    print("="*135)


def print_statistics(results):
    """Print test statistics"""
    total = len(results)
    successful = sum(1 for r in results if r["success"])
    correct = sum(1 for r in results if r["correct"])

    # Break down by category
    phishing_urls = [r for r in results if r["expected_malicious"]]
    legitimate_urls = [r for r in results if not r["expected_malicious"]]

    true_positives = sum(1 for r in phishing_urls if r["correct"] and r["success"])
    false_negatives = sum(1 for r in phishing_urls if not r["correct"] and r["success"])
    true_negatives = sum(1 for r in legitimate_urls if r["correct"] and r["success"])
    false_positives = sum(1 for r in legitimate_urls if not r["correct"] and r["success"])

    # Status breakdown
    status_counts = defaultdict(int)
    for r in results:
        if r["success"]:
            status_counts[r["status"]] += 1

    print("\n" + "="*70)
    print("TEST STATISTICS")
    print("="*70)
    print(f"\nTotal tests: {total}")
    print(f"  - Phishing URLs tested: {len(phishing_urls)}")
    print(f"  - Legitimate URLs tested: {len(legitimate_urls)}")
    print(f"  - Successful requests: {successful}/{total} ({successful/total*100:.1f}%)")

    print(f"\nDetection Accuracy:")
    accuracy_pct = (correct/successful*100) if successful > 0 else 0.0
    print(f"  - Correct classifications: {correct}/{successful} ({accuracy_pct:.1f}%)")
    print(f"  - True Positives (phishing detected): {true_positives}")
    print(f"  - True Negatives (legitimate detected): {true_negatives}")
    print(f"  - False Positives (legitimate flagged): {false_positives}")
    print(f"  - False Negatives (phishing missed): {false_negatives}")

    if len(phishing_urls) > 0 and sum(1 for r in phishing_urls if r["success"]) > 0:
        phishing_detection_rate = true_positives / sum(1 for r in phishing_urls if r["success"]) * 100
        print(f"\nPhishing Detection Rate: {phishing_detection_rate:.1f}%")

    if len(legitimate_urls) > 0 and sum(1 for r in legitimate_urls if r["success"]) > 0:
        legitimate_detection_rate = true_negatives / sum(1 for r in legitimate_urls if r["success"]) * 100
        print(f"Legitimate Detection Rate: {legitimate_detection_rate:.1f}%")

    print(f"\nVerdict Distribution:")
    for status, count in sorted(status_counts.items()):
        print(f"  - {status}: {count}")

    # Average score by category
    avg_phishing_score = sum(r["score"] for r in phishing_urls if r["success"]) / max(1, sum(1 for r in phishing_urls if r["success"]))
    avg_legitimate_score = sum(r["score"] for r in legitimate_urls if r["success"]) / max(1, sum(1 for r in legitimate_urls if r["success"]))

    print(f"\nAverage Scores:")
    print(f"  - Phishing URLs: {avg_phishing_score:.1f}")
    print(f"  - Legitimate URLs: {avg_legitimate_score:.1f}")

    # DOM analysis statistics
    dom_executed_count = sum(1 for r in results if r.get("dom_executed", False) and r["success"])
    dom_execution_rate = (dom_executed_count / successful * 100) if successful > 0 else 0
    print(f"\nDOM Analysis Execution:")
    print(f"  - URLs analyzed with DOM: {dom_executed_count}/{successful} ({dom_execution_rate:.1f}%)")

    print("\n" + "="*70)


def main():
    """Main test execution"""
    print("="*70)
    print("PHISHING URL DETECTION TEST")
    print(f"Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*70)

    # Check if API is running
    try:
        health_check = requests.get("http://localhost:8080/health", timeout=5)
        if health_check.status_code != 200:
            print("[!] API health check failed. Is the server running on port 8080?")
            return
        print("[+] API is running")
    except Exception as e:
        print(f"[!] Cannot connect to API: {e}")
        print("[!] Make sure the server is running: mvn spring-boot:run")
        return

    # Fetch phishing URLs
    phishing_urls = fetch_phishing_urls(TEST_LIMIT)

    if not phishing_urls:
        print("[!] No phishing URLs fetched. Exiting.")
        return

    # Prepare test set
    all_tests = [(url, True) for url in phishing_urls] + [(url, False) for url in LEGITIMATE_URLS]
    total_tests = len(all_tests)

    print(f"\n[*] Starting CONCURRENT tests ({total_tests} total URLs)...")
    print(f"    - {len(phishing_urls)} phishing URLs")
    print(f"    - {len(LEGITIMATE_URLS)} legitimate URLs")
    print(f"    - Concurrent workers: {CONCURRENT_WORKERS}\n")

    results = []
    start_time = time.time()
    completed = 0

    # Use ThreadPoolExecutor for concurrent requests
    with ThreadPoolExecutor(max_workers=CONCURRENT_WORKERS) as executor:
        # Submit all tasks
        future_to_test = {
            executor.submit(test_url, url, is_malicious): (idx, url, is_malicious)
            for idx, (url, is_malicious) in enumerate(all_tests, 1)
        }

        # Process completed tasks as they finish
        for future in as_completed(future_to_test):
            idx, url, is_malicious = future_to_test[future]
            try:
                result = future.result()
                results.append((idx, result))
                completed += 1
                print_result(result, completed, total_tests)
            except Exception as e:
                print(f"[!] Exception processing {url}: {e}")

    # Sort results by original index to maintain order
    results.sort(key=lambda x: x[0])
    results = [r[1] for r in results]

    elapsed_time = time.time() - start_time

    # Print summary table of all URLs
    print_url_summary_table(results)

    # Print statistics
    print_statistics(results)
    print(f"\nTotal execution time: {elapsed_time:.2f} seconds")
    print(f"Average time per URL: {elapsed_time/total_tests:.2f} seconds")

    # Save detailed results to file
    output_file = RESULTS_DIR / f"test-results.json"
    with open(output_file, 'w') as f:
        json.dump({
            "timestamp": datetime.now().isoformat(),
            "total_tests": total_tests,
            "execution_time": elapsed_time,
            "results": results
        }, f, indent=2)

    print(f"\nDetailed results saved to: {output_file}")


if __name__ == "__main__":
    main()
