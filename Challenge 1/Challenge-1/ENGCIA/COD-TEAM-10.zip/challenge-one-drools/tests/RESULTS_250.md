# Batch Evaluation Results: 250 URLs

This document summarizes the 250-URL batch evaluation for the phishing detection engine and records the corrected metrics where `PROBABLE_PHISHING` is treated as phishing (positive class).

- Recalculated: 2025-11-02 03:35:59
- Source summary: `tests/results/batch_summary_250.txt`
- Results CSV: `tests/results/batch_results_250.csv` (original run)

---

## Sample and Run Summary

- Total URLs tested: 250
- Valid results: 249
- Errors/Timeouts: 1

> Note: Metrics below reflect the corrected binary mapping: `PHISHING` and `PROBABLE_PHISHING` are positive; `LEGITIMATE` and `SUSPICIOUS` are negative for the purposes of precision/recall.

## Prediction Distribution

- PHISHING: 97
- PROBABLE_PHISHING: 47
- LEGITIMATE: 56
- SUSPICIOUS: 49

## Confusion Matrix (Corrected)

|                   | Predicted PHISHING | Predicted LEGITIMATE |
| ----------------- | -----------------: | -------------------: |
| Actual PHISHING   |                 94 |                   30 |
| Actual LEGITIMATE |                 50 |                   75 |

## Performance Metrics (Corrected)

- Accuracy: 67.87%
- Precision: 65.28%
- Recall (Sensitivity): 75.81%
- F1 Score: 70.15%

## Detailed Counts

- True Positives (TP): 94 — Correctly identified phishing
- True Negatives (TN): 75 — Correctly identified legitimate
- False Positives (FP): 50 — Legitimate flagged as phishing
- False Negatives (FN): 30 — Phishing missed (scored < 100)

## Notes

- The correction aligns the evaluation with business logic: `PROBABLE_PHISHING` requires blocking/verification and therefore counts as detected phishing for binary metrics.
- False negatives correspond to URLs scoring below 100 (i.e., labeled `SUSPICIOUS` or `LEGITIMATE`).
- For deeper analysis of missed cases, see `tests/analyze_false_negatives.py` and the CSV in `tests/results/`.

## Files

- Results CSV: `tests/results/batch_results_250.csv`
- Summary TXT (corrected): `tests/results/batch_summary_250.txt`
