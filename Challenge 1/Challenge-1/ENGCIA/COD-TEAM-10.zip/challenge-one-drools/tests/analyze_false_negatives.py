#!/usr/bin/env python3
"""
Analyze true false negative phishing URLs to identify patterns we're missing.
Looks for the most recent batch_results_*.csv under Tests/results.
"""

import pandas as pd
from collections import Counter
import re
from urllib.parse import urlparse
from pathlib import Path
import glob
import sys

BASE_DIR = Path(__file__).resolve().parent
RESULTS_DIR = BASE_DIR / "results"
SAMPLE_NUM = 250

results_file= RESULTS_DIR / f"batch_results_{SAMPLE_NUM}_.csv"
if not results_file.exists():
    print(f"Error: Results file not found: {results_file}")
    sys.exit(1)

print(f"Analyzing: {results_file}\n")
df = pd.read_csv(results_file)

# True false negatives = actual phishing not flagged as PHISHING or PROBABLE_PHISHING
fn = df[(df['actual'] == 'phishing') & (~df['predicted'].isin(['PHISHING', 'PROBABLE_PHISHING']))]

print("=" * 80)
print(f"FALSE NEGATIVE ANALYSIS - {len(fn)} Phishing URLs Missed")
print("=" * 80)

# Score distribution
print("\nSCORE DISTRIBUTION:")
print(fn['score'].describe())
print(f"\nScore ranges:")
print(f"  0-50:   {len(fn[fn['score'] <= 50])} URLs")
print(f"  51-99:  {len(fn[(fn['score'] > 50) & (fn['score'] < 100)])} URLs")
print(f"  100+:   {len(fn[fn['score'] >= 100])} URLs (PROBABLE_PHISHING threshold)")

# Analyze URL patterns
print("\n" + "=" * 80)
print("URL PATTERN ANALYSIS")
print("=" * 80)

tlds = []
has_ip = []
has_suspicious_keywords = []
url_lengths = []
subdomain_counts = []
has_hyphen = []
hosting_platforms = []

suspicious_keywords = [
    'login', 'verify', 'account', 'secure', 'update', 'confirm',
    'paypal', 'apple', 'microsoft', 'amazon', 'bank', 'signin',
    'validate', 'suspended', 'locked', 'urgent', 'action'
]

hosting_patterns = {
    'appspot.com': 'Google App Engine',
    'github.io': 'GitHub Pages',
    'herokuapp.com': 'Heroku',
    'vercel.app': 'Vercel',
    'netlify.app': 'Netlify',
    'glitch.me': 'Glitch',
    'onrender.com': 'Render',
    'firebaseapp.com': 'Firebase',
    'azurewebsites.net': 'Azure',
    'cloudfront.net': 'CloudFront',
    'amazonaws.com': 'AWS',
    'weebly.com': 'Weebly',
    'wixsite.com': 'Wix',
    'blogspot.com': 'Blogger',
    'wordpress.com': 'WordPress',
    'webcindario.com': 'Free Host',
    '000webhostapp.com': 'Free Host',
    'atspace.cc': 'Free Host',
}

for url in fn['url']:
    try:
        parsed = urlparse(url)
        host = parsed.netloc.lower()
        
        # TLD
        parts = host.split('.')
        if len(parts) > 0:
            tlds.append(parts[-1])
        
        # IP check
        if re.match(r'^\d+\.\d+\.\d+\.\d+', host):
            has_ip.append(url)
        
        # Keywords
        url_lower = url.lower()
        found_keywords = [kw for kw in suspicious_keywords if kw in url_lower]
        if found_keywords:
            has_suspicious_keywords.append((url, found_keywords))
        
        # URL length
        url_lengths.append(len(url))
        
        # Subdomain count
        subdomain_counts.append(len(parts) - 2 if len(parts) > 2 else 0)
        
        # Hyphens in host
        if '-' in host:
            has_hyphen.append(url)
        
        # Hosting platform
        for pattern, platform in hosting_patterns.items():
            if pattern in host:
                hosting_platforms.append((url, platform))
                break
                
    except Exception:
        pass

# Print findings
print(f"\n1. TOP TLDs:")
tld_counts = Counter(tlds).most_common(10)
for tld, count in tld_counts:
    print(f"   .{tld}: {count} ({count/len(fn)*100:.1f}%)")

print(f"\n2. IP ADDRESSES AS HOST: {len(has_ip)} URLs")
if has_ip:
    for url in has_ip[:5]:
        print(f"   - {url}")

print(f"\n3. SUSPICIOUS KEYWORDS: {len(has_suspicious_keywords)} URLs")
keyword_freq = Counter()
for url, keywords in has_suspicious_keywords:
    for kw in keywords:
        keyword_freq[kw] += 1
print("   Top keywords:")
for kw, count in keyword_freq.most_common(10):
    print(f"   - '{kw}': {count} times")

print(f"\n4. URL LENGTH:")
print(f"   Average: {sum(url_lengths)/len(url_lengths):.0f} chars")
print(f"   Min: {min(url_lengths)}, Max: {max(url_lengths)}")
print(f"   URLs > 100 chars: {len([l for l in url_lengths if l > 100])}")

print(f"\n5. SUBDOMAIN DEPTH:")
subdomain_dist = Counter(subdomain_counts)
for depth in sorted(subdomain_dist.keys()):
    print(f"   {depth} subdomains: {subdomain_dist[depth]} URLs")

print(f"\n6. HYPHENS IN HOST: {len(has_hyphen)} URLs ({len(has_hyphen)/len(fn)*100:.1f}%)")

print(f"\n7. HOSTING PLATFORMS: {len(hosting_platforms)} URLs")
platform_counts = Counter([p for _, p in hosting_platforms])
for platform, count in platform_counts.most_common():
    print(f"   {platform}: {count}")

# Sample low-scoring URLs
print("\n" + "=" * 80)
print("LOWEST SCORING MISSED PHISHING URLs (Top 15)")
print("=" * 80)
low_score = fn.nsmallest(15, 'score')
for idx, row in low_score.iterrows():
    print(f"\nScore: {row['score']:3d} | Rules: {row['rules_fired']}")
    print(f"URL: {row['url']}")

print("\n" + "=" * 80)
print("HIGHEST SCORING MISSED PHISHING URLs (Top 10)")
print("=" * 80)
high_score = fn.nlargest(10, 'score')
for idx, row in high_score.iterrows():
    print(f"\nScore: {row['score']:3d} | Rules: {row['rules_fired']}")
    print(f"URL: {row['url']}")

print("\n" + "=" * 80)
print("SUMMARY & RECOMMENDATIONS")
print("=" * 80)
print(f"""
Key Findings:
1. {len(fn[fn['score'] < 100])} URLs scored below PROBABLE_PHISHING threshold (100)
2. Common TLDs that should trigger more suspicion: {', '.join([f'.{t}' for t, _ in tld_counts[:5]])}
3. {len(has_suspicious_keywords)} URLs contain phishing keywords but scored too low
4. {len(hosting_platforms)} URLs use free/cloud hosting platforms

Recommendations:
- Consider a conditional promotion: suspicious_path + (young_domain | free_host | external_form_action)
- Increase weights for suspicious keywords when combined with corroborating DNS/host signals
- Add/expand detection for common free hosting platforms
- Review DNS/RDAP scoring for young domains
- Strengthen suspicious path pattern detection
""")
