#!/usr/bin/env python3
"""
Batch evaluation script for phishing detection engine.
Tests stratified random URLs from the dataset and evaluates the API performance.

Outputs are now organized under Tests/results.
"""

import os
import pandas as pd
import requests
import json
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path

# Paths
BASE_DIR = Path(__file__).resolve().parent
RESULTS_DIR = BASE_DIR / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
WORKSPACE_ROOT = BASE_DIR.parent.parent  # repo root's parent (Challenge-One)

# Basic .env loader (no external dependency). Loads key=value pairs into os.environ.
def load_basic_dotenv(env_path: Path):
    try:
        if env_path.exists():
            for line in env_path.read_text(encoding='utf-8').splitlines():
                line = line.strip()
                if not line or line.startswith('#'):
                    continue
                if '=' in line:
                    key, val = line.split('=', 1)
                    key = key.strip()
                    val = val.strip().strip('"').strip("'")
                    os.environ.setdefault(key, val)
    except Exception:
        # Non-fatal; fall back to defaults
        pass

# Sample sizes
PHISHING_SAMPLES = 25
LEGITIMATE_SAMPLES = 25
TOTAL_SAMPLES = PHISHING_SAMPLES + LEGITIMATE_SAMPLES

# Configuration
API_URL = "http://localhost:8080/evaluate"

# Load DATASET_CSV_PATH from .env or environment, with sensible default
load_basic_dotenv(BASE_DIR.parent / '.env')  # challenge-one-drools/.env
DEFAULT_DATASET = str((WORKSPACE_ROOT / 'dataset_phishing.csv').resolve())
DATASET_PATH = os.getenv('DATASET_CSV_PATH', DEFAULT_DATASET)
RESULTS_FILE = str(RESULTS_DIR / f"batch_results_{TOTAL_SAMPLES}_.csv")
SUMMARY_FILE = str(RESULTS_DIR / f"batch_summary_{TOTAL_SAMPLES}_.txt")

def load_dataset():
    """Load the dataset and return stratified random samples."""
    print(f"Loading dataset from: {DATASET_PATH}")
    df = pd.read_csv(DATASET_PATH)
    
    print(f"Total rows in dataset: {len(df)}")
    print(f"Phishing URLs: {len(df[df['status'] == 'phishing'])}")
    print(f"Legitimate URLs: {len(df[df['status'] == 'legitimate'])}")
    
    # Separate by class
    phishing_df = df[df['status'] == 'phishing']
    legitimate_df = df[df['status'] == 'legitimate']
    
    # Random sample from each class
    phishing_sample = phishing_df.sample(n=PHISHING_SAMPLES, random_state=42)
    legitimate_sample = legitimate_df.sample(n=LEGITIMATE_SAMPLES, random_state=42)
    
    # Combine and shuffle
    combined = pd.concat([phishing_sample, legitimate_sample])
    combined = combined.sample(frac=1, random_state=42).reset_index(drop=True)
    
    print(f"\nSelected {len(combined)} URLs:")
    print(f"  - {len(phishing_sample)} phishing")
    print(f"  - {len(legitimate_sample)} legitimate")
    
    return combined

def evaluate_url(url, actual_label):
    """Send a single URL to the API and get the result."""
    try:
        payload = {"url": url}
        response = requests.post(API_URL, json=payload, timeout=30)
        
        if response.status_code != 200:
            return {
                "url": url,
                "actual": actual_label,
                "predicted": "ERROR",
                "score": -1,
                "rules_fired": 0,
                "total_rules_evaluated": None,
                "triggered_rules": None,
                "error": f"HTTP {response.status_code}"
            }
        
        result = response.json()
        predicted = result.get("status", "UNKNOWN")  # API returns "status"
        score = result.get("score", result.get("finalScore", 0))
        rules_triggered = result.get("totalRulesTriggered", result.get("triggeredRulesCount", 0))
        rules_evaluated = result.get("totalRulesEvaluated", None)

        # Capture triggered rules map (name -> {score, description, details}) if present
        triggered_rules = result.get("triggeredRules", None)
        # Store a compact JSON string for later analysis (None if not available)
        triggered_rules_str = None
        if isinstance(triggered_rules, dict):
            try:
                # Reduce payload to name -> score for CSV friendliness, but keep full JSON if needed
                compact = {name: (val.get("score") if isinstance(val, dict) else None) for name, val in triggered_rules.items()}
                triggered_rules_str = json.dumps(compact, ensure_ascii=False)
            except Exception:
                # Fallback to raw JSON string
                try:
                    triggered_rules_str = json.dumps(triggered_rules, ensure_ascii=False)
                except Exception:
                    triggered_rules_str = None
        
        return {
            "url": url,
            "actual": actual_label,
            "predicted": predicted,
            "score": score,
            "rules_fired": rules_triggered,
            "total_rules_evaluated": rules_evaluated,
            "triggered_rules": triggered_rules_str,
            "error": None
        }
        
    except requests.exceptions.Timeout:
        return {
            "url": url,
            "actual": actual_label,
            "predicted": "TIMEOUT",
            "score": -1,
            "rules_fired": 0,
            "total_rules_evaluated": None,
            "triggered_rules": None,
            "error": "Request timeout (30s)"
        }
    except requests.exceptions.ConnectionError:
        return {
            "url": url,
            "actual": actual_label,
            "predicted": "CONNECTION_ERROR",
            "score": -1,
            "rules_fired": 0,
            "total_rules_evaluated": None,
            "triggered_rules": None,
            "error": "Cannot connect to API (is it running?)"
        }
    except Exception as e:
        return {
            "url": url,
            "actual": actual_label,
            "predicted": "EXCEPTION",
            "score": -1,
            "rules_fired": 0,
            "total_rules_evaluated": None,
            "triggered_rules": None,
            "error": str(e)
        }

def calculate_metrics(results_df):
    """Calculate performance metrics from results."""
    # Filter out errors
    valid_results = results_df[~results_df['predicted'].isin(['ERROR', 'TIMEOUT', 'CONNECTION_ERROR', 'EXCEPTION'])]
    
    if len(valid_results) == 0:
        return None
    
    # Map labels to binary (phishing=1, legitimate/suspicious=0)
    # Note: PROBABLE_PHISHING also counts as positive since it requires blocking/verification
    valid_results['actual_binary'] = valid_results['actual'].apply(lambda x: 1 if x == 'phishing' else 0)
    valid_results['predicted_binary'] = valid_results['predicted'].apply(lambda x: 1 if x in ['PHISHING', 'PROBABLE_PHISHING'] else 0)
    
    # Calculate confusion matrix values
    tp = len(valid_results[(valid_results['actual_binary'] == 1) & (valid_results['predicted_binary'] == 1)])
    tn = len(valid_results[(valid_results['actual_binary'] == 0) & (valid_results['predicted_binary'] == 0)])
    fp = len(valid_results[(valid_results['actual_binary'] == 0) & (valid_results['predicted_binary'] == 1)])
    fn = len(valid_results[(valid_results['actual_binary'] == 1) & (valid_results['predicted_binary'] == 0)])
    
    total = len(valid_results)
    accuracy = (tp + tn) / total if total > 0 else 0
    precision = tp / (tp + fp) if (tp + fp) > 0 else 0
    recall = tp / (tp + fn) if (tp + fn) > 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
    
    return {
        'total_tested': len(results_df),
        'valid_results': len(valid_results),
        'errors': len(results_df) - len(valid_results),
        'tp': tp,
        'tn': tn,
        'fp': fp,
        'fn': fn,
        'accuracy': accuracy,
        'precision': precision,
        'recall': recall,
        'f1_score': f1
    }

def main():
    """Main execution function."""
    print("=" * 80)
    print("PHISHING DETECTION ENGINE - BATCH EVALUATION (250 URLs)")
    print("=" * 80)
    print()
    
    # Check API availability
    print("Checking API availability...")
    try:
        response = requests.get("http://localhost:8080/health", timeout=5)
        if response.status_code == 200:
            print("✓ API is running and responsive\n")
        else:
            print(f"✗ API returned unexpected status: {response.status_code}")
            print("Please ensure the Spring Boot service is running on port 8080")
            return
    except requests.exceptions.ConnectionError:
        print("✗ Cannot connect to API at http://localhost:8080")
        print("Please start the service: mvn spring-boot:run or java -jar target/*.jar")
        return
    except Exception as e:
        print(f"✗ Error checking API: {e}")
        return
    
    # Load dataset
    df = load_dataset()
    
    # Process URLs
    print("\n" + "=" * 80)
    print("PROCESSING URLs...")
    print("=" * 80)
    
    results = []
    start_time = time.time()
    
    for idx, row in df.iterrows():
        url = row['url']
        actual_label = row['status']
        
        # Progress indicator
        progress = (idx + 1) / len(df) * 100
        print(f"[{idx + 1}/{len(df)}] ({progress:.1f}%) Testing: {url[:80]}...", end='')
        
        result = evaluate_url(url, actual_label)
        results.append(result)
        
        # Show result
        if result['error']:
            print(f" ✗ {result['predicted']}")
        else:
            match_symbol = "✓" if (result['actual'] == 'phishing' and result['predicted'] in ['PHISHING', 'PROBABLE_PHISHING']) or \
                                   (result['actual'] == 'legitimate' and result['predicted'] in ['LEGITIMATE', 'SUSPICIOUS']) \
                           else "✗"
            print(f" {match_symbol} {result['predicted']} (score: {result['score']})")
        
        # Small delay to avoid overwhelming the API
        time.sleep(0.1)
    
    elapsed_time = time.time() - start_time
    
    # Save results to CSV
    results_df = pd.DataFrame(results)
    results_df.to_csv(RESULTS_FILE, index=False)
    print(f"\n✓ Results saved to: {RESULTS_FILE}")
    
    # Calculate metrics
    print("\n" + "=" * 80)
    print("PERFORMANCE METRICS")
    print("=" * 80)
    
    metrics = calculate_metrics(results_df)
    
    if metrics is None:
        print("✗ No valid results to analyze (all requests failed)")
        return
    
    # Print summary
    summary = f"""
BATCH EVALUATION SUMMARY
{'=' * 80}
Date: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Dataset: {DATASET_PATH}
API Endpoint: {API_URL}

SAMPLE DISTRIBUTION
{'=' * 80}
Total URLs Tested:        {metrics['total_tested']}
  - Phishing:             {PHISHING_SAMPLES}
  - Legitimate:           {LEGITIMATE_SAMPLES}
Valid Results:            {metrics['valid_results']}
Errors/Timeouts:          {metrics['errors']}

CONFUSION MATRIX
{'=' * 80}
                    Predicted PHISHING    Predicted LEGITIMATE
Actual PHISHING            {metrics['tp']:4d}                 {metrics['fn']:4d}
Actual LEGITIMATE          {metrics['fp']:4d}                 {metrics['tn']:4d}

PERFORMANCE METRICS
{'=' * 80}
Accuracy:                 {metrics['accuracy']:.2%}
Precision:                {metrics['precision']:.2%}
Recall (Sensitivity):     {metrics['recall']:.2%}
F1 Score:                 {metrics['f1_score']:.2%}

DETAILED BREAKDOWN
{'=' * 80}
True Positives (TP):      {metrics['tp']:4d}  (Correctly identified phishing)
True Negatives (TN):      {metrics['tn']:4d}  (Correctly identified legitimate)
False Positives (FP):     {metrics['fp']:4d}  (Legitimate flagged as phishing)
False Negatives (FN):     {metrics['fn']:4d}  (Phishing missed)

EXECUTION TIME
{'=' * 80}
Total Time:               {elapsed_time:.2f} seconds
Average per URL:          {elapsed_time / metrics['total_tested']:.2f} seconds

FILES GENERATED
{'=' * 80}
Results CSV:              {RESULTS_FILE}
Summary Report:           {SUMMARY_FILE}
"""
    
    print(summary)
    
    # Save summary to file
    with open(SUMMARY_FILE, 'w', encoding='utf-8') as f:
        f.write(summary)
    
    print(f"✓ Summary saved to: {SUMMARY_FILE}")
    
    # Show sample misclassifications (aligned to binary policy)
    print("\n" + "=" * 80)
    print("SAMPLE MISCLASSIFICATIONS")
    print("=" * 80)
    
    misclassified = results_df[
        ((results_df['actual'] == 'phishing') & (~results_df['predicted'].isin(['PHISHING', 'PROBABLE_PHISHING']))) |
        ((results_df['actual'] == 'legitimate') & (results_df['predicted'].isin(['PHISHING', 'PROBABLE_PHISHING'])))
    ]
    
    if len(misclassified) > 0:
        print(f"\nShowing first 10 of {len(misclassified)} misclassifications:")
        for idx, row in misclassified.head(10).iterrows():
            print(f"  - {row['url'][:70]}")
            print(f"    Actual: {row['actual']}, Predicted: {row['predicted']}, Score: {row['score']}")
    else:
        print("✓ No misclassifications!")
    
    print("\n" + "=" * 80)
    print("BATCH EVALUATION COMPLETE")
    print("=" * 80)

if __name__ == "__main__":
    main()
