#!/bin/bash
#
# Simple test script for phishing URL detection
# Fetches URLs from OpenPhish and tests them against the local API
#

API_URL="http://localhost:8080/evaluate"
LIMIT=10

echo "=============================================="
echo "Simple Phishing URL Detection Test"
echo "=============================================="

# Check if API is running
echo "[*] Checking if API is running..."
if ! curl -s http://localhost:8080/health > /dev/null 2>&1; then
    echo "[!] API is not running. Start it with: mvn spring-boot:run"
    exit 1
fi
echo "[+] API is running"

# Fetch phishing URLs
echo "[*] Fetching $LIMIT phishing URLs from OpenPhish..."
mapfile -t URLS < <(curl -s https://openphish.com/feed.txt | head -n "$LIMIT")

if [ ${#URLS[@]} -eq 0 ]; then
    echo "[!] Failed to fetch URLs"
    exit 1
fi

echo "[+] Fetched ${#URLS[@]} URLs"
echo ""

# Test each URL
count=0
for url in "${URLS[@]}"; do
    ((count++))
    echo "[$count/${#URLS[@]}] Testing: ${url:0:60}..."

    result=$(curl -s -X POST "$API_URL" \
        -H "Content-Type: application/json" \
        -d "{\"url\": \"$url\"}" \
        --max-time 30)

    if [ $? -eq 0 ]; then
        status=$(echo "$result" | grep -o '"status":"[^"]*"' | cut -d'"' -f4)
        score=$(echo "$result" | grep -o '"finalScore":[0-9]*' | cut -d':' -f2)
        echo "  → Verdict: $status (Score: $score)"
    else
        echo "  → Error: Request failed"
    fi
    echo ""

    # Small delay to avoid overwhelming the API
    sleep 0.5
done

echo "=============================================="
echo "Test complete!"
echo "=============================================="
