# Rule Weights Standardization and Configuration Guide

This single document consolidates and replaces the previous files:

- RULE_WEIGHTS_STANDARDIZATION.md
- CONFIGURATION.md

It provides both the standardized weighting recommendations and practical configuration/tuning guidance for the Drools-based phishing detection engine.

---

## 📊 Phishing Detection Rule Weights Standardization

Project: Challenge One - Drools Phishing Detection
Date: 2025-10-30
Scale: 0-100 points per rule
Total Rules: 36 rules across 4 categories

### 🎯 Executive Summary

This section provides standardized weight recommendations for all phishing detection rules in the Drools-based system. The current weights range inconsistently from 4 to 100 points, with some rules significantly over/under-weighted for their actual risk level.

Key changes include significant increases for DNS and DOM rules, calibrated thresholds, and top-priority updates for high-impact indicators (e.g., external form actions, very new domains, IP host, homograph/punycode).

### 📈 Severity Level Guidelines

| Severity Level | Point Range | Description                               | Examples                             |
| -------------- | ----------- | ----------------------------------------- | ------------------------------------ |
| Low            | 0-20        | Weak indicators, high false positive rate | External media, many hyphens         |
| Low-Medium     | 21-40       | Suspicious patterns, needs context        | Long URL, not whitelisted            |
| Medium-High    | 41-60       | Likely phishing tactics                   | Password fields, URL shorteners      |
| High           | 61-80       | Strong phishing indicators                | IP host, external form actions       |
| Critical       | 81-100      | Definitive threats, compound risks        | Very new domain, multiple indicators |

### 🔗 URL RULES (url-rules.drl)

- Total Rules: 11
- Current Avg: 28.6 → Recommended Avg: 41.8 (+46%)
- Top priority updates:
  - Likely homograph: 8 → 40 (+400%)
  - Host is IP address: 30 → 70 (+133%)
  - Domain age > 1 year: 5 → 0 (remove penalty)

### 🌐 DNS RULES (dns-rules.drl)

- Total Rules: 6
- Current Avg: 14.3 → Recommended Avg: 53.3 (+273%)
- Top priority updates:
  - No A/AAAA records: 20 → 80 (+300%)
  - Young domain (<30 days): 25 → 90 (+260%)
  - IDN punycode: 8 → 40 (+400%)

### 📄 DOM RULES (dom-rules.drl)

- Total Rules: 9
- Current Avg: 6.9 → Recommended Avg: 33.9 (+391%)
- Top priority updates:
  - External form actions: 12 → 70 (+483%)
  - Password field present: 10 → 50 (+400%)
  - Sensitive inputs: 10 → 50 (+400%)

### 🔄 REDIRECT CHAIN RULES (redirect-chain-rules.drl)

- Total Rules: 10
- Current Avg: 31.5 → Recommended Avg: 60.5 (+92%)
- Top priority updates:
  - Multiple indicators: 50 → 100 (+100%)
  - Shortener + redirects: 25 → 55 (+120%)
  - Very excessive redirects: 40 → 70 (+75%)

### 🎯 Score Threshold Recommendations

Current thresholds are replaced by calibrated thresholds:

```
PHISHING:           ≥ 150    (Multiple strong indicators)
PROBABLE_PHISHING:  100-149  (High confidence phishing)
SUSPICIOUS:         60-99    (Concerning patterns)
LEGITIMATE:         0-59     (Low risk)
```

Rationale: Realistic phishing scenarios trigger a handful of high-value rules (200-400 typical). These thresholds separate risk bands cleanly and support nuanced scoring.

---

## ✅ Implemented engine weights (source of truth)

These are the weights currently used by the engine at runtime. Source: `src/main/resources/application.yml` (bound by `RuleWeightsConfig`). If you change values there and rebuild, the rules will use the new weights without modifying the DRL files.

### URL weights

| Key                  | Weight | Notes                                  |
| -------------------- | -----: | -------------------------------------- |
| at_character         |     30 | '@' in URL (may hide real destination) |
| ip_host              |     70 | Host is an IP address                  |
| homograph            |     40 | IDN/punycode homograph                 |
| many_hyphens_digits  |     20 | Excessive hyphens/digits (obfuscation) |
| very_long_url        |     25 | Length > 75 with corroborating signals |
| excessive_subdomains |     35 | 3+ subdomains                          |
| domain_very_new      |     90 | Domain age < 3 years                   |
| domain_suspended     |     95 | Suspended/hold/redemption              |
| domain_expiring_soon |     60 | Expires in < 90 days                   |
| suspicious_path      |     55 | Suspicious path patterns               |
| obfuscated_params    |     35 | Obfuscated or heavily encoded params   |
| suspicious_subdomain |     50 | Statistical anomalies in subdomain     |

### DNS weights

| Key                | Weight | Notes                      |
| ------------------ | -----: | -------------------------- |
| no_a_records       |     80 | Domain doesn't resolve     |
| very_low_ttl       |     45 | TTL < 60s (fast-flux)      |
| no_mx_and_spf      |     30 | Missing both MX and SPF    |
| idn_punycode       |     40 | Uses IDN/punycode          |
| long_cname_chain   |     35 | 3+ CNAME hops              |
| young_domain       |     90 | Domain age < 30 days       |
| cname_loop         |     50 | Circular CNAME             |
| single_name_server |     40 | Only one NS                |
| no_reverse_dns     |     35 | No PTR for A/AAAA          |
| no_email_auth      |     55 | Missing SPF+DMARC+DKIM     |
| partial_email_auth |     20 | Only one of SPF/DMARC/DKIM |
| slow_dns_response  |     25 | DNS query > 2s             |

### Redirect-chain weights

| Key                            | Weight | Notes                                     |
| ------------------------------ | -----: | ----------------------------------------- |
| excessive_redirects            |     45 | > 3 redirects                             |
| very_excessive_redirects       |     70 | > 5 redirects                             |
| untrusted_redirect             |     55 | Through untrusted domains                 |
| open_redirect                  |     65 | Open redirect detected                    |
| obfuscated_redirect            |     60 | Obfuscated URLs in chain                  |
| broken_chain                   |     40 | Loop/error in chain                       |
| url_shortener                  |     45 | Uses shortener                            |
| shortener_with_redirects       |     55 | Shortener + multiple redirects            |
| shortener_with_open_redirect   |     85 | Shortener + open redirect                 |
| multiple_suspicious_indicators |    100 | Compound issues in chain                  |
| trusted_final_destination      |    -40 | Final destination trusted (reduces score) |
| final_dest_very_new            |     90 | Final destination < 180 days              |
| final_dest_less_than_year      |     50 | Final destination 180-365 days            |
| final_dest_over_year           |      0 | No bonus for age > 1 year                 |
| tls_error                      |     90 | TLS/SSL certificate error                 |

### DOM weights

| Key                    | Weight | Notes                         |
| ---------------------- | -----: | ----------------------------- |
| password_field         |     50 | Password input present        |
| sensitive_input_fields |     50 | Credit card, SSN, etc.        |
| external_form_actions  |     70 | Form posts to external domain |
| external_or_null_links |     15 | External/broken links         |
| external_media         |     10 | External images/videos        |
| high_link_ratio        |     25 | High ratio of anchors         |
| high_dependency_ratio  |     20 | Many third-party requests     |
| high_dom_entropy       |     30 | Complex/random DOM            |
| title_obfuscated       |     35 | Suspicious page title         |
| meta_refresh_redirect  |     80 | Meta refresh redirect         |
| javascript_redirect    |     70 | JavaScript-based redirect     |

### Classification thresholds (implemented)

| Class             | Boundary |
| ----------------- | -------- |
| PHISHING          | ≥ 150    |
| PROBABLE_PHISHING | 100-149  |
| SUSPICIOUS        | 60-99    |
| LEGITIMATE        | 0-59     |

---

### 💡 Advanced Recommendations (Implementation Notes)

- Implement negative scores for trust signals (e.g., domain age > 5yrs, whitelisting)
- Use rule exclusivity groups for domain age and redirect counts (highest-only)
- Drools `salience` to prioritize mutually exclusive rules and halt lower-priority ones
- Consider context-aware multipliers for dangerous combinations (e.g., external form + password field)

---

## ⚙️ Configuration & Tuning Guide

This section captures the practical configuration notes from the previous CONFIGURATION.md.

### Configuration source: application.yml (current)

Current location: `src/main/resources/application.yml`

The engine binds weights from `application.yml` into `RuleWeightsConfig`, and the DRL rules consume them via `weightsConfig.get*Weight(...)`. You can also externalize this to a dedicated `rule-weights.yml` (for example, as a separate profile or mounted file in production). If you add `rule-weights.yml`, keep this document as the single source of truth and mirror the same keys.

### Recent Improvements (2025-11-01)

We evaluated a blacklist-based "free hosting provider" rule but chose not to maintain host blacklists. Instead, the engine relies on statistical subdomain signals (`suspicious_subdomain`), path patterns, and redirect-chain analysis. No provider blacklist rule is currently active in the DRL.

### How to Adjust Weights

1. Edit `src/main/resources/application.yml` (or a dedicated `rule-weights.yml` introduced) and, if any value is still hardcoded, mirror it in the DRL until fully externalized
2. Rebuild the project (Drools compiles rules at build time)
3. Validate with the batch tests under `tests/` and analyze results in `tests/results/`
4. Iterate using the standardized recommendations above

---

## 📚 References & Research (abridged)

- Google Safe Browsing API scoring methodology
- APWG guidelines; NIST CSF - Phishing Detection
- PhishTank/PhishStats datasets; Alexa Top sites
- IEEE/ACM/USENIX papers on phishing detection features and DNS analysis

---

## 📌 Status

This document replaces the prior separate docs. Please update any links to point here.

---

## 📈 Calibration notes from the 250-URL evaluation

Source: `tests/RESULTS_250.md` (balanced 125 phishing + 125 legitimate)

- Confusion matrix (corrected mapping where PROBABLE_PHISHING counts as phishing):
  - TP 94, TN 75, FP 50, FN 30
- Metrics: Accuracy 67.87%, Precision 65.28%, Recall 75.81%, F1 70.15%

Observations and light-touch tuning ideas:

- Precision is moderate (FP=50). Before changing thresholds, review top FP drivers by aggregating per-rule contributions from `tests/results/batch_results_250.csv`. Typical FP contributors to inspect: `suspicious_path` (55), `url_shortener` (45), and redirect-chain flags; consider requiring corroboration for some of these in specific contexts.
- Recall is decent (75.81%) with FN=30. Review missed cases for signals absent in URL/DNS: consider DOM-heavy cues (`password_field`, `sensitive_input_fields`, redirects via `meta_refresh_redirect`/`javascript_redirect`). If patterns emerge, modestly increase related DOM weights or add combination rules.
- Thresholds (150/100/60) appear reasonable for separation; many borderline cases land in SUSPICIOUS (49). Keep thresholds stable while you focus on reducing noisy FP signals.
- Trust offset `trusted_final_destination = -40` is active; if you confirm many FP have strong, reputable final hosts, consider a slightly larger reduction (e.g., -50/-60) together with a safeguard to avoid masking true phish with trusted CDNs.

Next steps:

- Run a quick per-rule impact analysis: sum contributions per rule over FP and FN subsets to rank over- and under-weighted signals.
- Based on rankings, trial small 5-10 point adjustments on 1-3 suspect rules and re-evaluate with the same 250 URLs to quantify delta.
