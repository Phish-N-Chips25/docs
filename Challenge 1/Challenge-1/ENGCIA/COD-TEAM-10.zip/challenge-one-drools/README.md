# Challenge One (Phish’n’Chips)

A rules-based system for phishing URL detection using expert reasoning. Combines structural URL analysis, WHOIS/TLS checks, blacklist lookups, and heuristic scoring to classify URLs as phishing, probable phishing, or benign. Implemented with **Drools** and exposed via a minimal **Spring Boot** REST API.


## Quick start

### Prerequisites

* **Java 17** (LTS)
* **Maven 3.6+**
* Ports: defaults to `8080`

### API Configuration

The system uses external APIs for enhanced detection. Create a `.env` file in the project root (alongside `pom.xml`). You can also specify paths used by test tooling here:

```bash
# Required for domain age analysis (WHOIS lookups)
WHOIS_API_KEY=your_whoisxmlapi_key_here

# Optional: Path to the labeled dataset used by batch tests (Link:https://www.kaggle.com/datasets/shashwatwork/web-page-phishing-detection-dataset?resource=download)
# If omitted, batch tests default to ../../dataset_phishing.csv relative to Tests/
# Use absolute paths on Windows
DATASET_CSV_PATH=C:\\Users\\<you>\\Desktop\\Challenge-One\\dataset_phishing.csv

# Optional: Other API keys
# API_KEY=your_other_api_key_here
```

**Getting a WHOIS API Key:**
1. Sign up at [WhoisXMLAPI](https://whoisxmlapi.com/)
2. Get your API key from the dashboard (free tier available with 500 requests/month)
3. Add it to your `.env` file as `WHOIS_API_KEY`

Notes:
- The system will continue to work without a valid WHOIS API key, but domain age detection will be unavailable (domain age will be reported as -1).
- Batch scripts under `tests/` read `DATASET_CSV_PATH` from the environment/.env. If not set, they fall back to `../../dataset_phishing.csv` (the workspace-level file).

### Build & run

```bash
# from repo root
mvn clean package
mvn spring-boot:run
# or: java -jar target/*.jar
```

### Endpoints

* **Healthcheck**

  ```
  GET http://localhost:8080/health
  → 200 OK, body: OK
  ```

* **Evaluate evidences**

  ```
  POST http://localhost:8080/evaluate
  Content-Type: application/json

  {
    "hasAtChar": "yes",
    "hostIsIp": "no",
    "hasHomograph": "no",
    "manyHyphensOrDigits": "no",
    "urlLength": 85,
    "subdomainCount": 3
  }
  ```

  **Response**

    * `200 OK` with a JSON `Conclusion` produced by the rules, e.g.

      ```json
      { "value": "PROBABLE_PHISHING" }
      ```
    * `204 No Content` if the rules produced no `Conclusion`.


## Project structure

```
src/main/java/org/phishnchips
├─ PhishingApplication.java            # Spring Boot entrypoint
├─ config/
│  └─ DroolsConfig.java                # KIE container bean
├─ controller/
│  └─ PhishingController.java          # /health, /evaluate
├─ service/
│  └─ PhishingService.java             # runs Drools, returns Conclusion
├─ domain/
│  └─ model/
│     ├─ Evidences.java
│     ├─ Conclusion.java
│     ├─ Hypothesis.java
│     └─ Measurement.java
└─ logging/
   └─ RequestIdFilter.java             # per-request correlation id (MDC)
```

```
src/main/resources
├─ application.yml                      # logging levels & pattern
├─ META-INF/kmodule.xml                 # Drools kbase/ksession config (ksession-rules)
└─ org/phishnchips/rules.drl            # rules
```


## Tech stack

* **Spring Boot 2.7.x** (Java 8 compatible)
* **Drools 7.44.0.Final**
* **Playwright** for DOM analysis
* **Maven**
* Logging: **Logback** (console) with per-request correlation id


## How it works (very short)

1. The REST controller accepts an `Evidences` JSON.
2. `PhishingService` creates a new **KieSession** from a singleton **KieContainer**.
3. It inserts the `Evidences`, calls `fireAllRules()`, then reads any `Conclusion` facts created by the rules.
4. The first (or strongest, if you later add ranking) `Conclusion` is returned as JSON.

> Session name used: **`ksession-rules`** (configured in `kmodule.xml`).


## Updating/adding rules

* Edit `src/main/resources/org/phishnchips/rules.drl`.
* **Imports must match your Java packages**, e.g.:

  ```java
  import org.phishnchips.domain.model.Evidences;
  import org.phishnchips.domain.model.Conclusion;
  ```
* Rebuild to recompile rules: `mvn clean package`.

If you ever see **“Rules fired: 0”** after a refactor, double-check:

* DRL imports point to the correct packages
* `kmodule.xml` kbase `packages` includes your DRL location
* Session name in service matches `kmodule.xml` (`ksession-rules`)


## Testing

### Automated Testing with Real Phishing URLs

We maintain test scripts under `tests/`, with results saved to `tests/results/`.

**Concurrent Test Script (recommended - fastest):**
```bash
# Install requests library if needed
pip install requests  # or: pip3 install requests

# Run concurrent tests (fetches 100 phishing URLs + 15 legitimate URLs)
python tests/test-concurrent.py
```
- Uses 10 parallel workers for concurrent execution
- Processes 100+ URLs in ~30-40 seconds
- Tracks DOM analysis execution
- Saves detailed results to `tests/results/concurrent-test-results.json`

**Sequential Test Script (detailed output):**
```bash
# Run sequential tests (fetches 100 phishing URLs + 15 legitimate URLs)
python tests/test-phishing-urls.py
```
- Shows detailed progress for each URL tested
- Provides comprehensive statistics
- Saves results to `test-results.json`

**Bash Script (simple - minimal output):**
```bash
# Run simple test (fetches 10 phishing URLs)
./test-simple.sh
```

All scripts:
- Fetch recent phishing URLs from [OpenPhish](https://openphish.com/)
- Test legitimate URLs (Google, Facebook, Amazon, etc.) for false positives
- Display detection accuracy, true/false positives, and DOM analysis execution rates
- Require the API to be running on `localhost:8080`

### Manual Testing Examples

**Test with a URL:**
```bash
curl -s -X POST http://localhost:8080/evaluate \
  -H 'Content-Type: application/json' \
  -d '{"url": "https://example.com"}' | jq .
```

**Test with pre-computed evidences:**
```bash
curl -s -X POST http://localhost:8080/evaluate \
  -H 'Content-Type: application/json' \
  -H 'X-Request-Id: demo-001' \
  -d '{
        "hasAtChar":"yes",
        "hostIsIp":"no",
        "hasHomograph":"no",
        "manyHyphensOrDigits":"no",
        "urlLength":85,
        "subdomainCount":3
      }' | jq .
```

### Code layout guidelines

* Keep web concerns in `controller`, engine orchestration in `service`, and domain objects in `domain/model`.
* Rules are pure Drools and live in `resources/org/phishnchips`.


## License

MIT (or fill in your preferred license).

### Documentation: Rule Weights and Tuning

See `WEIGHTS_AND_TUNING.md` for the consolidated rule weights standardization and configuration guide (supersedes `RULE_WEIGHTS_STANDARDIZATION.md` and `CONFIGURATION.md`).
```
