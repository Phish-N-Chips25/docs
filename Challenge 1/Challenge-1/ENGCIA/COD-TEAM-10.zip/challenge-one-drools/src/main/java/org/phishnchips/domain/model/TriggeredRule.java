package org.phishnchips.domain.model;

import java.util.List;

public class TriggeredRule {
    private final int score;
    private final String description;
    private final List<RuleDetail> details;

    public TriggeredRule(int score, String description, List<RuleDetail> details) {
        this.score = score;
        this.description = description;
        this.details = details;
    }

    public int getScore() {
        return score;
    }

    public String getDescription() {
        return description;
    }

    public List<RuleDetail> getDetails() {
        return details;
    }
}
