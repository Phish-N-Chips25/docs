package org.phishnchips.service;

import org.phishnchips.domain.model.Evidences;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.*;
import java.util.*;
import java.util.regex.Pattern;
import java.io.IOException;

@Service
public class RedirectChainService {

    // Configuration constants
    private static final int MAX_REDIRECT_THRESHOLD = 3; // Suspicious if more than 3 redirects
    private static final int MAX_REDIRECT_LIMIT = 10; // Hard limit to prevent infinite loops
    private static final int CONNECT_TIMEOUT = 5000; // 5 seconds
    private static final int READ_TIMEOUT = 5000; // 5 seconds

    // Patterns for detection
    private static final Pattern IPV4 = Pattern.compile(
            "^((25[0-5]|2[0-4]\\d|[01]?\\d\\d?)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d\\d?)$");
    private static final Pattern MANY_HYPHENS_OR_DIGITS = Pattern.compile("[-\\d]{6,}");

    // Open redirect patterns (common parameters used for redirects)
    private static final Pattern OPEN_REDIRECT_PARAMS = Pattern.compile(
            "[?&](url|redirect|redir|next|target|dest|destination|return|returnto|returnurl|continue|goto|link|out)=",
            Pattern.CASE_INSENSITIVE);

    // URL obfuscation patterns
    private static final Pattern OBFUSCATION_PATTERNS = Pattern.compile(
            "(%[0-9a-f]{2}){3,}|" + // Multiple URL encoding
                    "(\\\\x[0-9a-f]{2}){3,}|" + // Hex encoding
                    "javascript:|data:|" + // Dangerous schemes
                    "(/\\.\\./|/\\./)", // Path traversal (removed multiple slashes check to avoid false positives with
                                        // https://)
            Pattern.CASE_INSENSITIVE);

    // Heuristic thresholds
    private static final int TRUST_FINAL_DEST_AGE_DAYS = 1095; // consider long-lived domains as more trustworthy

    private final ShortnerDetectorService shortnerDetectorService;
    private final String whoisApiKey;

    public RedirectChainService(ShortnerDetectorService shortnerDetectorService,
            @Value("${whois.api.key:}") String whoisApiKey) {
        this.shortnerDetectorService = shortnerDetectorService;
        this.whoisApiKey = whoisApiKey;
    }

    public void enrich(Evidences ev) {
        if (ev == null || ev.getUrl() == null)
            return;

        final String url = ev.getUrl();

        // Basic URL analysis (original functionality)
        performBasicUrlAnalysis(ev, url);

        // HTTP redirect chain analysis (new functionality)
        performRedirectChainAnalysis(ev, url);
    }

    /**
     * Performs basic URL lexical analysis
     */
    private void performBasicUrlAnalysis(Evidences ev, String url) {
        ev.setUrlLength(url.length());
        ev.setHasAtChar(url.contains("@"));

        String host = extractHost(url);
        if (host == null)
            return;

        // Normalize (remove www.)
        if (host.startsWith("www."))
            host = host.substring(4);

        // Check if host is IP address
        ev.setIsIpHost(IPV4.matcher(host).matches());

        // Count subdomains
        int labels = host.split("\\.").length;
        ev.setSubdomainCount(Math.max(labels - 2, 0));

        // Detect many hyphens or digits
        boolean many = MANY_HYPHENS_OR_DIGITS.matcher(host + "/" + safePath(url)).find();
        ev.setManyHyphensOrDigits(many);

        // Homograph detection (IDN/punycode)
        String ascii = IDN.toASCII(host);
        ev.setHasHomograph(host.startsWith("xn--") || !host.equalsIgnoreCase(ascii));
    }

    /**
     * Performs comprehensive HTTP redirect chain analysis
     */
    private void performRedirectChainAnalysis(Evidences ev, String url) {
        List<String> redirectChain = new ArrayList<>();
        redirectChain.add(url);

        boolean chainBroken = false;
        boolean hasUntrustedRedirect = false;
        boolean hasOpenRedirect = false;
        boolean hasObfuscatedRedirect = false;
        int redirectCount = 0;

        String currentUrl = url;
        Set<String> visitedUrls = new HashSet<>();
        visitedUrls.add(normalizeUrl(currentUrl));

        try {
            // Check if URL uses shortener
            boolean isShortener = shortnerDetectorService.isShortener(url);
            ev.setUsesUrlShortener(isShortener ? Boolean.TRUE : Boolean.FALSE);

            // Trace redirect chain
            while (redirectCount < MAX_REDIRECT_LIMIT) {
                System.out.println("[RedirectChainService] Following redirect from: " + currentUrl);
                String nextUrl = followSingleRedirect(currentUrl);
                System.out.println("[RedirectChainService] Next URL: " + nextUrl);

                if (nextUrl == null) {
                    // No more redirects
                    System.out.println("[RedirectChainService] No more redirects detected");
                    break;
                }

                // Check for redirect loop before adding
                String normalizedNext = normalizeUrl(nextUrl);
                System.out.println("[RedirectChainService] Normalized URL: " + normalizedNext);
                System.out.println("[RedirectChainService] Visited URLs: " + visitedUrls);
                if (visitedUrls.contains(normalizedNext)) {
                    // URL normalizes to same as previous - this is the end of the chain, not a
                    // broken loop
                    System.out.println(
                            "[RedirectChainService] Normalized URL already visited (likely trailing slash difference): "
                                    + normalizedNext);
                    break;
                }

                redirectCount++;
                redirectChain.add(nextUrl);
                visitedUrls.add(normalizedNext);

                // Analyze redirect for suspicious patterns
                // Only flag as untrusted if redirecting to a DIFFERENT domain that's not in the
                // trusted list
                String currentRootDomain = getRootDomain(currentUrl);
                String nextRootDomain = getRootDomain(nextUrl);

                if (currentRootDomain != null && nextRootDomain != null &&
                        !currentRootDomain.equals(nextRootDomain) &&
                        !isBrandSimilar(currentRootDomain, nextRootDomain)) {
                    hasUntrustedRedirect = true;
                    System.out.println("[RedirectChainService] Untrusted cross-domain redirect detected: " +
                            currentRootDomain + " -> " + nextRootDomain);
                }

                if (hasOpenRedirectPattern(currentUrl)) {
                    hasOpenRedirect = true;
                }

                if (hasUrlObfuscation(nextUrl)) {
                    System.out.println("[RedirectChainService] Obfuscation detected in: " + nextUrl);
                    hasObfuscatedRedirect = true;
                }

                currentUrl = nextUrl;
            }

            // Check if we hit the hard limit (possible infinite loop)
            if (redirectCount >= MAX_REDIRECT_LIMIT) {
                chainBroken = true;
            }

        } catch (Exception e) {
            // If analysis fails, mark chain as broken
            chainBroken = true;
            System.err.println("Redirect chain analysis failed for " + url + ": " + e.getMessage());
        }

        // Check if final destination (last URL in chain) is trusted
        String finalDestination = redirectChain.isEmpty() ? url : redirectChain.get(redirectChain.size() - 1);
        boolean finalDestinationTrusted = false;

        // Get domain age of final destination (only if different from original URL)
        Integer finalDestinationDomainAge = null;
        if (redirectCount > 0 && !finalDestination.equalsIgnoreCase(url)) {
            try {
                // Extract just the domain from the final destination URL
                String finalDestinationDomain = extractHost(finalDestination);
                if (finalDestinationDomain != null) {
                    // Remove www. prefix if present
                    if (finalDestinationDomain.startsWith("www.")) {
                        finalDestinationDomain = finalDestinationDomain.substring(4);
                    }
                    System.out.println("[RedirectChainService] Checking domain age for: " + finalDestinationDomain);
                    finalDestinationDomainAge = UrlAnalysisService.getDomainAgeInDays(finalDestinationDomain,
                            whoisApiKey);
                    if (finalDestinationDomainAge == -1) {
                        finalDestinationDomainAge = null; // Set to null if WHOIS lookup failed
                    }
                    System.out.println("[RedirectChainService] Final destination domain age: "
                            + finalDestinationDomainAge + " days");
                    // Heuristic trust: long-lived final destination
                    if (finalDestinationDomainAge != null && finalDestinationDomainAge >= TRUST_FINAL_DEST_AGE_DAYS) {
                        finalDestinationTrusted = true;
                    }
                }
            } catch (Exception e) {
                System.err.println("Failed to get domain age for final destination: " + e.getMessage());
                e.printStackTrace();
            }
        }

        // Set evidence fields (using Boolean.TRUE/FALSE for proper Drools rule
        // matching)
        ev.setRedirectChainLength(redirectCount);
        ev.setRedirectChain(redirectChain);
        ev.setHasExcessiveRedirects(redirectCount > MAX_REDIRECT_THRESHOLD ? Boolean.TRUE : Boolean.FALSE);
        ev.setHasUntrustedRedirect(hasUntrustedRedirect ? Boolean.TRUE : Boolean.FALSE);
        ev.setHasOpenRedirect(hasOpenRedirect ? Boolean.TRUE : Boolean.FALSE);
        ev.setHasObfuscatedRedirect(hasObfuscatedRedirect ? Boolean.TRUE : Boolean.FALSE);
        ev.setRedirectChainBroken(chainBroken ? Boolean.TRUE : Boolean.FALSE);
        ev.setFinalDestinationTrusted(finalDestinationTrusted ? Boolean.TRUE : Boolean.FALSE);
        ev.setFinalDestinationDomainAgeDays(finalDestinationDomainAge);

        // Debug logging
        System.out.println("[RedirectChainService] Analysis complete for: " + url);
        System.out.println("  - Redirect count: " + redirectCount);
        System.out.println("  - Uses shortener: " + ev.getUsesUrlShortener());
        System.out.println("  - Excessive redirects: " + ev.getHasExcessiveRedirects());
        System.out.println("  - Untrusted redirect: " + ev.getHasUntrustedRedirect());
        System.out.println("  - Open redirect: " + ev.getHasOpenRedirect());
        System.out.println("  - Obfuscated: " + ev.getHasObfuscatedRedirect());
        System.out.println("  - Chain broken: " + ev.getRedirectChainBroken());
        System.out.println("  - Final destination trusted: " + ev.getFinalDestinationTrusted());
        System.out.println("  - Final destination domain age (days): " + ev.getFinalDestinationDomainAgeDays());
        System.out.println("  - Redirect chain: " + redirectChain);
    }

    /**
     * Follows a single HTTP redirect and returns the next URL
     */
    private String followSingleRedirect(String urlString) {
        HttpURLConnection connection = null;
        try {
            URL url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();

            // Configure connection
            connection.setInstanceFollowRedirects(false); // Manual redirect handling
            connection.setConnectTimeout(CONNECT_TIMEOUT);
            connection.setReadTimeout(READ_TIMEOUT);
            connection.setRequestMethod("GET"); // Use GET (some shorteners reject HEAD)

            // Set realistic user agent
            connection.setRequestProperty("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");

            int responseCode = connection.getResponseCode();
            System.out.println("[RedirectChainService] HTTP Response Code for " + urlString + ": " + responseCode);

            // Check if it's a redirect (3xx status codes)
            if (responseCode >= 300 && responseCode < 400) {
                String location = connection.getHeaderField("Location");
                if (location != null && !location.isEmpty()) {
                    // Handle relative URLs
                    if (location.startsWith("/")) {
                        URL base = new URL(urlString);
                        location = base.getProtocol() + "://" + base.getHost() +
                                (base.getPort() > 0 ? ":" + base.getPort() : "") + location;
                    } else if (!location.startsWith("http://") && !location.startsWith("https://")) {
                        // Relative path without leading slash
                        URL base = new URL(urlString);
                        String basePath = base.getPath();
                        int lastSlash = basePath.lastIndexOf('/');
                        String parentPath = lastSlash > 0 ? basePath.substring(0, lastSlash) : "";
                        location = base.getProtocol() + "://" + base.getHost() +
                                (base.getPort() > 0 ? ":" + base.getPort() : "") +
                                parentPath + "/" + location;
                    }
                    return location;
                }
            }

            return null; // No redirect

        } catch (MalformedURLException e) {
            System.err.println("Malformed URL: " + urlString);
            return null;
        } catch (IOException e) {
            // Network error or timeout
            return null;
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    /**
     * Brand similarity heuristic between two root domains
     * Treats domains as similar if their SLDs match after removing hyphens/digits,
     * or have edit distance <= 1 (e.g., coolmath-games.com -> coolmathgames.com)
     */
    private boolean isBrandSimilar(String rootA, String rootB) {
        if (rootA == null || rootB == null)
            return false;
        String sldA = getSecondLevelLabel(rootA);
        String sldB = getSecondLevelLabel(rootB);
        if (sldA == null || sldB == null)
            return false;

        String normA = sldA.toLowerCase().replaceAll("[0-9-]", "");
        String normB = sldB.toLowerCase().replaceAll("[0-9-]", "");
        if (normA.equals(normB))
            return true;
        return levenshteinDistance(normA, normB) <= 1;
    }

    private String getSecondLevelLabel(String host) {
        try {
            String[] parts = host.split("\\.");
            if (parts.length < 2)
                return null;
            return parts[parts.length - 2];
        } catch (Exception e) {
            return null;
        }
    }

    private int levenshteinDistance(String a, String b) {
        int n = a.length(), m = b.length();
        int[][] dp = new int[n + 1][m + 1];
        for (int i = 0; i <= n; i++)
            dp[i][0] = i;
        for (int j = 0; j <= m; j++)
            dp[0][j] = j;
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                dp[i][j] = Math.min(
                        Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1),
                        dp[i - 1][j - 1] + cost);
            }
        }
        return dp[n][m];
    }

    /**
     * Detects open redirect patterns in URL parameters
     */
    private boolean hasOpenRedirectPattern(String url) {
        return OPEN_REDIRECT_PARAMS.matcher(url).find();
    }

    /**
     * Detects URL obfuscation techniques
     */
    private boolean hasUrlObfuscation(String url) {
        return OBFUSCATION_PATTERNS.matcher(url).find();
    }

    /**
     * Normalizes URL for comparison (lowercase, remove trailing slash, remove
     * fragment)
     */
    private String normalizeUrl(String url) {
        try {
            URI uri = new URI(url);
            String normalized = uri.getScheme() + "://" +
                    uri.getHost().toLowerCase() +
                    (uri.getPort() > 0 ? ":" + uri.getPort() : "") +
                    (uri.getPath() != null ? uri.getPath() : "") +
                    (uri.getQuery() != null ? "?" + uri.getQuery() : "");

            // Remove trailing slash
            if (normalized.endsWith("/")) {
                normalized = normalized.substring(0, normalized.length() - 1);
            }

            return normalized;
        } catch (Exception e) {
            return url.toLowerCase();
        }
    }

    /**
     * Extracts host from URL
     */
    private String extractHost(String url) {
        try {
            return new URI(url).getHost();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Extracts the root domain from a URL (normalized, without www)
     * For example: www.example.com -> example.com, subdomain.example.com ->
     * example.com
     */
    private String getRootDomain(String url) {
        String host = extractHost(url);
        if (host == null)
            return null;

        // Normalize to lowercase and remove www. prefix
        host = host.toLowerCase();
        if (host.startsWith("www.")) {
            host = host.substring(4);
        }

        return host;
    }

    /**
     * Safely extracts path from URL
     */
    private String safePath(String url) {
        try {
            return new URI(url).getRawPath();
        } catch (Exception e) {
            return "";
        }
    }
}
