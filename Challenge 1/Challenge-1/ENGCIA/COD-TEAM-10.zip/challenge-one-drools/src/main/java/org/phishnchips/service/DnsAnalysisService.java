package org.phishnchips.service;

import org.phishnchips.domain.model.Evidences;
import org.springframework.stereotype.Service;

// dnsjava
import org.xbill.DNS.CNAMERecord;
import org.xbill.DNS.Lookup;
import org.xbill.DNS.Name;
import org.xbill.DNS.Record;
import org.xbill.DNS.TXTRecord;
import org.xbill.DNS.Type;
import org.xbill.DNS.ARecord;
import org.xbill.DNS.AAAARecord;

import java.net.InetAddress;
import java.util.HashSet;
import java.util.Set;

@Service
public class DnsAnalysisService {
    public void enrich(Evidences ev) {
        String host = extractHost(ev.getUrl());
        if (host == null)
            return;

        long startTime = System.currentTimeMillis();

        try {
            int count = 0;
            Record[] a = new Lookup(host, Type.A).run();
            if (a != null)
                count += a.length;
            Record[] aaaa = new Lookup(host, Type.AAAA).run();
            if (aaaa != null)
                count += aaaa.length;
            ev.setDnsARecordCount(count);

            // Measure DNS response time
            long endTime = System.currentTimeMillis();
            ev.setDnsResponseTimeMs((int) (endTime - startTime));

            // Short-circuit: if no A/AAAA records, skip further DNS lookups
            if (count == 0) {
                ev.setDnsHasMX(null);
                ev.setDnsHasSPF(null);
                ev.setDnsMinTTL(null);
                ev.setDnsMaxTTL(null);
                ev.setCnameChainLength(0);
                ev.setHasCnameLoop(false);
                ev.setNameServerCount(null);
                ev.setHasValidReverseDns(null);
                ev.setHasDmarc(null);
                ev.setHasDkim(null);
                ev.setIdn(host.startsWith("xn--"));
                ev.setDomainAgeDays(null);
                return;
            }

            Record[] mx = new Lookup(host, Type.MX).run();
            ev.setDnsHasMX(mx != null && mx.length > 0);

            boolean spf = false;
            Record[] txt = new Lookup(host, Type.TXT).run();
            if (txt != null) {
                for (Record r : txt) {
                    if (r instanceof TXTRecord) {
                        TXTRecord tr = (TXTRecord) r;
                        for (Object o : tr.getStrings()) {
                            String s = (o == null) ? null : o.toString();
                            if (s != null && s.toLowerCase().contains("v=spf1")) {
                                spf = true;
                                break;
                            }
                        }
                    }
                    if (spf)
                        break;
                }
            }
            ev.setDnsHasSPF(spf);

            // TTLs from A/AAAA
            Integer minT = null, maxT = null;
            for (Record r : (a == null ? new Record[0] : a)) {
                int ttl = (int) r.getTTL();
                minT = (minT == null) ? ttl : Math.min(minT, ttl);
                maxT = (maxT == null) ? ttl : Math.max(maxT, ttl);
            }
            for (Record r : (aaaa == null ? new Record[0] : aaaa)) {
                int ttl = (int) r.getTTL();
                minT = (minT == null) ? ttl : Math.min(minT, ttl);
                maxT = (maxT == null) ? ttl : Math.max(maxT, ttl);
            }
            ev.setDnsMinTTL(minT);
            ev.setDnsMaxTTL(maxT);

            // IDN quick flag
            ev.setIdn(host.startsWith("xn--"));

            // CNAME chain analysis with loop detection
            int hops = 0;
            boolean loopDetected = false;
            Set<String> seenNames = new HashSet<>();
            Name cur = Name.fromString(host + ".");
            seenNames.add(cur.toString().toLowerCase());

            while (true) {
                Record[] c = new Lookup(cur, Type.CNAME).run();
                if (c == null || c.length == 0)
                    break;
                hops++;
                cur = ((CNAMERecord) c[0]).getTarget();

                // Check for loop
                String curName = cur.toString().toLowerCase();
                if (seenNames.contains(curName)) {
                    loopDetected = true;
                    break;
                }
                seenNames.add(curName);

                if (hops > 10)
                    break;
            }
            ev.setCnameChainLength(hops);
            ev.setHasCnameLoop(loopDetected);

            // Name server count
            Record[] nsRecords = new Lookup(host, Type.NS).run();
            ev.setNameServerCount(nsRecords != null ? nsRecords.length : 0);

            // Reverse DNS validation (check A record IPs have PTR records)
            ev.setHasValidReverseDns(checkReverseDns(a, aaaa));

            // DMARC check (_dmarc.domain.com TXT record)
            ev.setHasDmarc(checkDmarc(host));

            // DKIM check (common selectors: default, google, selector1, selector2)
            ev.setHasDkim(checkDkim(host));

            // domainAgeDays: leave null unless enriched by WHOIS/RDAP
            ev.setDomainAgeDays(null);

        } catch (Exception ignored) {
        }
    }

    private boolean checkReverseDns(Record[] a, Record[] aaaa) {
        try {
            // Check if at least one A/AAAA record has a valid PTR
            if (a != null) {
                for (Record r : a) {
                    if (r instanceof ARecord) {
                        InetAddress addr = ((ARecord) r).getAddress();
                        Name reverseName = org.xbill.DNS.ReverseMap.fromAddress(addr);
                        Record[] ptr = new Lookup(reverseName, Type.PTR).run();
                        if (ptr != null && ptr.length > 0) {
                            return true; // At least one valid PTR found
                        }
                    }
                }
            }

            if (aaaa != null) {
                for (Record r : aaaa) {
                    if (r instanceof AAAARecord) {
                        InetAddress addr = ((AAAARecord) r).getAddress();
                        Name reverseName = org.xbill.DNS.ReverseMap.fromAddress(addr);
                        Record[] ptr = new Lookup(reverseName, Type.PTR).run();
                        if (ptr != null && ptr.length > 0) {
                            return true;
                        }
                    }
                }
            }

            return false; // No valid PTR records found
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkDmarc(String host) {
        try {
            String dmarcHost = "_dmarc." + host;
            Record[] txt = new Lookup(dmarcHost, Type.TXT).run();
            if (txt != null) {
                for (Record r : txt) {
                    if (r instanceof TXTRecord) {
                        TXTRecord tr = (TXTRecord) r;
                        for (Object o : tr.getStrings()) {
                            String s = (o == null) ? null : o.toString();
                            if (s != null && s.toLowerCase().startsWith("v=dmarc1")) {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private boolean checkDkim(String host) {
        try {
            // Common DKIM selectors used by major email providers and services
            String[] selectors = { "default", "google", "selector1", "selector2", "k1", "dkim" };

            for (String selector : selectors) {
                String dkimHost = selector + "._domainkey." + host;
                Record[] txt = new Lookup(dkimHost, Type.TXT).run();
                if (txt != null && txt.length > 0) {
                    // Check if it's actually a DKIM record (contains v=DKIM1 or k=)
                    for (Record r : txt) {
                        if (r instanceof TXTRecord) {
                            TXTRecord tr = (TXTRecord) r;
                            for (Object o : tr.getStrings()) {
                                String s = (o == null) ? null : o.toString();
                                if (s != null && (s.contains("v=DKIM1") || s.contains("k=") || s.contains("p="))) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
            return false;
        } catch (Exception e) {
            return false;
        }
    }

    private String extractHost(String url) {
        try {
            String h = new java.net.URI(url).getHost();
            if (h == null)
                return null;
            return h.startsWith("www.") ? h.substring(4) : h;
        } catch (Exception e) {
            return null;
        }
    }
}
