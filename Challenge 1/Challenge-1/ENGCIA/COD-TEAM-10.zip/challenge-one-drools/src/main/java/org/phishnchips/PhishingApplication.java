package org.phishnchips;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhishingApplication {
    public static void main(String[] args) {
        SpringApplication.run(PhishingApplication.class, args);
    }
}
