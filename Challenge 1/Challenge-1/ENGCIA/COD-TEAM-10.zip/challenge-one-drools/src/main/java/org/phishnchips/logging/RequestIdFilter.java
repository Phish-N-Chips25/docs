package org.phishnchips.logging;

import org.slf4j.MDC;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.UUID;

@Component
@Order(Ordered.HIGHEST_PRECEDENCE)
public class RequestIdFilter implements Filter {
    private static final String REQ_ID = "reqId";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        String fromHeader = null;
        if (request instanceof HttpServletRequest) {
            fromHeader = ((HttpServletRequest) request).getHeader("X-Request-Id");
        }
        String reqId = (fromHeader != null && !fromHeader.isEmpty())
                ? fromHeader
                : UUID.randomUUID().toString().substring(0, 8);
        try {
            MDC.put(REQ_ID, reqId);
            chain.doFilter(request, response);
        } finally {
            MDC.remove(REQ_ID);
        }
    }
}
