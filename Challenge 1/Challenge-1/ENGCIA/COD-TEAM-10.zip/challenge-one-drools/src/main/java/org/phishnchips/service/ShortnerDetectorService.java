package org.phishnchips.service;

import org.springframework.stereotype.Service;

import java.net.URI;

@Service
public class ShortnerDetectorService {

    /**
     * Detects URL shorteners using statistical heuristics instead of blacklists.
     * 
     * URL shorteners typically have these characteristics:
     * 1. Very short domain names (1-7 characters excluding TLD)
     * 2. Short TLDs (2-3 characters)
     * 3. Very short paths (2-10 characters)
     * 4. No query parameters (clean short URLs)
     * 5. Often use single-label domains (no subdomains)
     * 
     * Examples: bit.ly/abc123, t.co/xyz, 3.ly/uh4, u.to/NgUvGA, x.co/abc
     */
    public boolean isShortener(String url) {
        try {
            URI uri = new URI(url);
            String host = uri.getHost();
            String path = uri.getPath();
            String query = uri.getQuery();

            if (host == null)
                return false;

            // Remove www. prefix for analysis
            if (host.startsWith("www.")) {
                host = host.substring(4);
            }

            // Split into domain parts
            String[] hostParts = host.split("\\.");
            if (hostParts.length < 2)
                return false; // Need at least domain + TLD

            // Extract domain name (second-to-last part)
            String domainName = hostParts[hostParts.length - 2];

            // Check if it's a single-label domain (no subdomains)
            boolean isSingleLabel = hostParts.length == 2;

            // Heuristic 1: Very short domain (1-5 chars) - changed to include single-char
            // domains like 3.ly, x.co, t.co
            boolean hasShortDomain = domainName.length() >= 1 && domainName.length() <= 5;

            // Heuristic 2: Short path (typical shortener pattern)
            // Path should be present, non-root, and short (2-10 characters excluding /)
            boolean hasShortPath = false;
            if (path != null && !path.isEmpty() && !path.equals("/")) {
                String cleanPath = path.startsWith("/") ? path.substring(1) : path;
                // Remove trailing slash if present
                if (cleanPath.endsWith("/")) {
                    cleanPath = cleanPath.substring(0, cleanPath.length() - 1);
                }
                // Check if path is short and doesn't contain slashes (single segment)
                hasShortPath = cleanPath.length() >= 2 &&
                        cleanPath.length() <= 10 &&
                        !cleanPath.contains("/");
            }

            // Heuristic 3: No query parameters (clean URLs)
            boolean hasNoQuery = (query == null || query.isEmpty());

            // Heuristic 4: Alphanumeric-only path (common in shortener IDs)
            boolean hasAlphanumericPath = false;
            if (path != null && !path.isEmpty() && !path.equals("/")) {
                String cleanPath = path.replaceFirst("^/", "").replaceFirst("/$", "");
                hasAlphanumericPath = cleanPath.matches("^[a-zA-Z0-9_-]+$");
            }

            // Decision logic: Combine heuristics
            // Strong indicators: short domain + short path + no query + single label
            if (isSingleLabel && hasShortDomain && hasShortPath && hasNoQuery) {
                return true;
            }

            // Alternative: very short domain (1-5 chars) + alphanumeric short path -
            // changed to include single-char domains
            if (isSingleLabel && domainName.length() >= 1 && domainName.length() <= 5 &&
                    hasShortPath && hasAlphanumericPath) {
                return true;
            }

            return false;

        } catch (Exception e) {
            return false;
        }
    }
}
