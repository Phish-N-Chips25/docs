package org.phishnchips.domain.model;

import java.util.Map;

public class Conclusion {
    private String status;
    private int score;
    private Map<String, TriggeredRule> triggeredRules;
    private int totalRulesTriggered;
    private int totalRulesEvaluated;

    public Conclusion(String status, int score, Map<String, TriggeredRule> triggeredRules) {
        this.status = status;
        this.score = score;
        this.triggeredRules = triggeredRules;
        this.totalRulesTriggered = triggeredRules != null ? triggeredRules.size() : 0;
        this.totalRulesEvaluated = 0;
    }

    public Conclusion(String status, int score, Map<String, TriggeredRule> triggeredRules, int totalRulesTriggered, int totalRulesEvaluated) {
        this.status = status;
        this.score = score;
        this.triggeredRules = triggeredRules;
        this.totalRulesTriggered = totalRulesTriggered;
        this.totalRulesEvaluated = totalRulesEvaluated;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getScore() {
        return score;
    }

    public void setScore(int score) {
        this.score = score;
    }

    public Map<String, TriggeredRule> getTriggeredRules() {
        return triggeredRules;
    }

    public void setTriggeredRules(Map<String, TriggeredRule> triggeredRules) {
        this.triggeredRules = triggeredRules;
    }

    public int getTotalRulesTriggered() {
        return totalRulesTriggered;
    }

    public void setTotalRulesTriggered(int totalRulesTriggered) {
        this.totalRulesTriggered = totalRulesTriggered;
    }

    public int getTotalRulesEvaluated() {
        return totalRulesEvaluated;
    }

    public void setTotalRulesEvaluated(int totalRulesEvaluated) {
        this.totalRulesEvaluated = totalRulesEvaluated;
    }
}
