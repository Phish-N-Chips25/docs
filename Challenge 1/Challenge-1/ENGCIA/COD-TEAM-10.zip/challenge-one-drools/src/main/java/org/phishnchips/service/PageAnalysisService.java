package org.phishnchips.service;

import com.microsoft.playwright.*;
import com.microsoft.playwright.options.WaitUntilState;
import org.phishnchips.domain.model.Evidences;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class PageAnalysisService {

    // Performance guardrails for very large pages
    private static final int MAX_ITEM_SAMPLES = 300; // cap how many items we collect per category

    private Playwright playwright;
    private Browser browser;

    @PostConstruct
    public void init() {
        System.out.println("[PageAnalysisService] Initializing persistent browser...");
        playwright = Playwright.create();

        // Launch browser with stealth options to avoid detection
        boolean headless = Boolean.parseBoolean(System.getProperty("pageanalysis.headless", "true"));
        String channel = System.getProperty("pageanalysis.channel", ""); // e.g. "chrome" to use installed Chrome

        BrowserType.LaunchOptions launchOptions = new BrowserType.LaunchOptions()
                .setHeadless(headless)
                .setArgs(java.util.Arrays.asList(
                        "--disable-blink-features=AutomationControlled", // Remove automation flag
                        "--disable-dev-shm-usage",
                        "--no-sandbox",
                        "--disable-setuid-sandbox",
                        "--disable-web-security",
                        "--disable-features=IsolateOrigins,site-per-process"));

        // Prefer using a real Chrome channel if provided
        if (channel != null && !channel.isBlank()) {
            try {
                launchOptions.setChannel(channel);
                System.out.println("[PageAnalysisService] Attempting to launch Chromium with channel='" + channel
                        + "' headless=" + headless);
                browser = playwright.chromium().launch(launchOptions);
            } catch (Exception ex) {
                System.err.println(
                        "[PageAnalysisService] Failed to launch with channel '" + channel + "': " + ex.getMessage());
            }
        }

        if (browser == null) {
            // Fallback to default Chromium
            System.out.println("[PageAnalysisService] Launching default Chromium headless=" + headless);
            browser = playwright.chromium().launch(launchOptions);
        }

        System.out.println(
                "[PageAnalysisService] Browser ready for reuse (stealth mode enabled, headless=" + headless + ")");
    }

    @PreDestroy
    public void cleanup() {
        System.out.println("[PageAnalysisService] Shutting down browser...");
        if (browser != null) {
            browser.close();
        }
        if (playwright != null) {
            playwright.close();
        }
    }

    public void analyzePage(Evidences evidences) {
        String url = evidences.getUrl();
        if (url == null || url.isEmpty()) {
            return;
        }

        System.out.println("[PageAnalysisService] Analyzing URL: " + url);
        BrowserContext context = null;
        Page page = null;
        try {
            // Create a new browser context with realistic fingerprint
            // SECURITY: Fresh context with no cookies, cache, or user data
            Browser.NewContextOptions contextOptions = new Browser.NewContextOptions()
                    .setUserAgent(
                            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")
                    .setViewportSize(1920, 1080)
                    .setLocale("en-US")
                    .setTimezoneId("America/New_York")
                    .setAcceptDownloads(false) // BLOCK all downloads to prevent malware
                    .setExtraHTTPHeaders(java.util.Map.of(
                            "Accept-Language", "en-US,en;q=0.9",
                            "Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8"));

            context = browser.newContext(contextOptions);

            // SECURITY: Block any download attempts (redundant safeguard)
            context.onPage(p -> {
                p.onDownload(download -> {
                    System.out
                            .println("[PageAnalysisService] BLOCKED download attempt: " + download.suggestedFilename());
                    download.cancel();
                });
            });

            // Mask common automation fingerprints before any script runs
            context.addInitScript("" +
                    "Object.defineProperty(navigator, 'webdriver', {get: () => undefined});" +
                    "window.chrome = window.chrome || { runtime: {} };" +
                    "Object.defineProperty(navigator, 'languages', {get: () => ['en-US','en']});" +
                    "Object.defineProperty(navigator, 'plugins', {get: () => [1,2,3,4,5]});" +
                    "Object.defineProperty(navigator, 'platform', {get: () => 'Win32'});");

            // Create a new page from the configured context
            page = context.newPage();

            // SECURITY: Additional download blocking at page level
            page.onDownload(download -> {
                System.out.println(
                        "[PageAnalysisService] BLOCKED download at page level: " + download.suggestedFilename());
                download.cancel();
            });

            // Set aggressive timeouts to prevent hanging
            page.setDefaultTimeout(3000); // 3 seconds for all operations

            System.out.println("[PageAnalysisService] Navigating to page...");
            page.navigate(url, new Page.NavigateOptions()
                    .setTimeout(5000) // 5 second navigation timeout
                    .setWaitUntil(WaitUntilState.DOMCONTENTLOADED)); // Don't wait for all resources

            // If navigation yielded a Chrome error page (common with anti-bot), try a
            // fallback with real Chrome non-headless
            if (page.url() != null && page.url().startsWith("chrome-error://")) {
                System.out.println(
                        "[PageAnalysisService] Chrome error page loaded; retrying with non-headless Chrome channel if available...");
                try {
                    page.close();
                    context.close();

                    // Launch a temporary non-headless Chrome for this single analysis
                    BrowserType.LaunchOptions fallbackLaunch = new BrowserType.LaunchOptions()
                            .setHeadless(false)
                            .setArgs(java.util.Arrays.asList(
                                    "--disable-blink-features=AutomationControlled",
                                    "--disable-dev-shm-usage",
                                    "--no-sandbox",
                                    "--disable-setuid-sandbox"));
                    // Prefer Chrome channel if present
                    try {
                        fallbackLaunch.setChannel("chrome");
                    } catch (Throwable ignored) {
                    }

                    Browser fallbackBrowser = playwright.chromium().launch(fallbackLaunch);
                    Browser.NewContextOptions fallbackCtxOpts = new Browser.NewContextOptions()
                            .setUserAgent(
                                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")
                            .setViewportSize(1920, 1080)
                            .setLocale("en-US")
                            .setTimezoneId("America/New_York")
                            .setAcceptDownloads(false); // BLOCK downloads in fallback browser too
                    BrowserContext fbCtx = fallbackBrowser.newContext(fallbackCtxOpts);

                    // SECURITY: Block downloads in fallback context
                    fbCtx.onPage(p -> {
                        p.onDownload(download -> {
                            System.out.println("[PageAnalysisService] BLOCKED download in fallback browser: "
                                    + download.suggestedFilename());
                            download.cancel();
                        });
                    });

                    fbCtx.addInitScript("Object.defineProperty(navigator, 'webdriver', {get: () => undefined});");
                    Page fbPage = fbCtx.newPage();

                    // SECURITY: Block downloads at fallback page level
                    fbPage.onDownload(download -> {
                        System.out.println("[PageAnalysisService] BLOCKED download at fallback page level: "
                                + download.suggestedFilename());
                        download.cancel();
                    });

                    fbPage.setDefaultTimeout(5000);
                    fbPage.navigate(url, new Page.NavigateOptions()
                            .setTimeout(8000)
                            .setWaitUntil(WaitUntilState.DOMCONTENTLOADED));

                    // Swap to use the fallback page/context for the rest of analysis
                    context = fbCtx;
                    page = fbPage;

                    // We don't keep the temporary browser beyond this analysis; it will be closed
                    // in finally by context.close()
                } catch (Exception retryEx) {
                    System.err.println("[PageAnalysisService] Fallback navigation failed: " + retryEx.getMessage());
                }
            }

            // CRITICAL: Detect client-side redirects (meta refresh + JavaScript)
            detectClientSideRedirects(page, evidences);

            // C1.A: Sensitive Input Fields Detection
            evidences.setSensitiveFieldsFound(getSensitiveInputFields(page));

            // C1.B: Data Exfiltration Analysis
            evidences.setExternalFormActions(getExternalFormActions(page, url));

            // C2.A: Link Features (Null/Foreign Links)
            evidences.setExternalOrNullLinks(getExternalOrNullLinks(page, url));

            // C2.B: Dependent Request Ratio (Images/Media)
            evidences.setExternalMedia(getExternalMedia(page, url));

            // C3.B: DOM Entropy (Complexity Check)
            evidences.setDomEntropy(calculateDomEntropy(page));

            // C4.B: Page Title Obfuscation
            evidences.setTitleObfuscated(checkTitleObfuscated(page));

            System.out.println("[PageAnalysisService] Analysis complete");

        } catch (PlaywrightException e) {
            System.err.println("[PageAnalysisService] Could not analyze page: " + e.getMessage());

            // CRITICAL: Detect TLS/SSL certificate errors (common in phishing sites)
            if (e.getMessage() != null && (e.getMessage().contains("ERR_CERT_") ||
                    e.getMessage().contains("SSL") ||
                    e.getMessage().contains("TLS") ||
                    e.getMessage().contains("certificate"))) {
                System.out.println("[PageAnalysisService] TLS/SSL certificate error detected - PHISHING INDICATOR");
                evidences.setHasTlsError(true);
            }
        } catch (Exception e) {
            System.err.println("[PageAnalysisService] Unexpected error: " + e.getMessage());
        } finally {
            if (page != null) {
                page.close();
            }
            if (context != null) {
                context.close();
            }
        }
    }

    private List<String> getSensitiveInputFields(Page page) {
        String sensitiveFieldsSelector = "input[type='password'], input[type='email'], input[name='username'], input[name='login'], "
                +
                "input[type='tel'], input[name='card'], input[name='cvv'], input[name='expiry'], input[name='billing'], "
                +
                "input[name='ssn'], input[name='social'], input[name='dob'], input[name='address'], " +
                "input[name='account'], input[name='routing'], input[name='pin'], " +
                "input[autocomplete='password'], input[autocomplete='credit-card']";
        return page.locator(sensitiveFieldsSelector).all().stream()
                .map(locator -> "type=" + locator.getAttribute("type") + ", name=" + locator.getAttribute("name"))
                .collect(Collectors.toList());
    }

    private List<String> getExternalFormActions(Page page, String pageUrl) {
        List<String> externalActions = new ArrayList<>();
        Locator forms = page.locator("form");
        for (int i = 0; i < forms.count(); i++) {
            String action = forms.nth(i).getAttribute("action");
            if (action != null && !action.trim().isEmpty() && isExternalDomain(action, pageUrl)) {
                externalActions.add(action);
            }
        }
        return externalActions;
    }

    private List<String> getExternalOrNullLinks(Page page, String pageUrl) {
        // For performance, extract and filter in a single JS evaluation.
        try {
            String pageHost = new URI(pageUrl).getHost();
            String pageRoot = getRootDomain(pageHost);

            @SuppressWarnings("unchecked")
            Map<String, Object> result = (Map<String, Object>) page.evaluate(
                    "([pageRoot, maxSample]) => {\n" +
                            "  function rootDomain(h){ if(!h) return null; const p=h.split('.'); return p.length>1 ? p[p.length-2]+'.'+p[p.length-1] : h; }\n"
                            +
                            "  function brandSimilar(rootA, rootB) { if(!rootA || !rootB) return false; const pA=rootA.split('.'); const pB=rootB.split('.'); if(pA.length<2||pB.length<2) return false; const sldA=pA[pA.length-2].replace(/[^a-z]/gi,'').toLowerCase(); const sldB=pB[pB.length-2].replace(/[^a-z]/gi,'').toLowerCase(); return sldA===sldB; }\n"
                            +
                            "  const out = [];\n" +
                            "  let total = 0;\n" +
                            "  const nodes = document.querySelectorAll('a, img, link');\n" +
                            "  for (let i=0;i<nodes.length;i++){\n" +
                            "    const n = nodes[i];\n" +
                            "    let v = n.getAttribute('href') || n.getAttribute('src');\n" +
                            "    if (!v || !v.trim() || v.startsWith('#')) {\n" +
                            "      total++;\n" +
                            "      if (out.length < maxSample) out.push('null_link');\n" +
                            "      continue;\n" +
                            "    }\n" +
                            "    let abs;\n" +
                            "    try { abs = new URL(v, document.baseURI); } catch(e) {\n" +
                            "      // invalid URL, count as null-ish\n" +
                            "      total++; if (out.length < maxSample) out.push('null_link'); continue;\n" +
                            "    }\n" +
                            "    const linkRoot = rootDomain(abs.host);\n" +
                            "    if (linkRoot && linkRoot !== pageRoot && !brandSimilar(linkRoot, pageRoot)) {\n"
                            +
                            "      total++;\n" +
                            "      if (out.length < maxSample) out.push(abs.href);\n" +
                            "    }\n" +
                            "  }\n" +
                            "  return { total, items: out };\n" +
                            "}",
                    Arrays.asList(pageRoot, MAX_ITEM_SAMPLES));

            // We only need to return the sampled items for details; rules only check size>0
            @SuppressWarnings("unchecked")
            List<String> items = (List<String>) result.getOrDefault("items", Collections.emptyList());

            // If we truncated, prepend a hint entry
            Number total = (Number) result.getOrDefault("total", items.size());
            if (total.intValue() > items.size()) {
                List<String> withNote = new ArrayList<>();
                withNote.add("TRUNCATED total=" + total.intValue());
                withNote.addAll(items);
                return withNote;
            }
            return items;
        } catch (Exception ex) {
            // Fallback to the previous (slower) method if JS evaluation fails
            List<String> links = new ArrayList<>();
            Locator linkLocators = page.locator("a, img, link");
            int count = Math.min(linkLocators.count(), MAX_ITEM_SAMPLES);
            for (int i = 0; i < count; i++) {
                ElementHandle element = linkLocators.nth(i).elementHandle();
                String href = element.getAttribute("href");
                if (href == null) {
                    href = element.getAttribute("src");
                }
                if (href == null || href.trim().isEmpty() || href.startsWith("#")) {
                    links.add("null_link");
                } else if (isExternalDomain(href, pageUrl)) {
                    links.add(href);
                }
            }
            return links;
        }
    }

    private List<String> getExternalMedia(Page page, String pageUrl) {
        try {
            String pageHost = new URI(pageUrl).getHost();
            String pageRoot = getRootDomain(pageHost);

            @SuppressWarnings("unchecked")
            List<String> items = (List<String>) page.evaluate(
                    "([pageRoot, maxSample]) => {\n" +
                            "  function rootDomain(h){ if(!h) return null; const p=h.split('.'); return p.length>1 ? p[p.length-2]+'.'+p[p.length-1] : h; }\n"
                            +
                            "  function brandSimilar(rootA, rootB) { if(!rootA || !rootB) return false; const pA=rootA.split('.'); const pB=rootB.split('.'); if(pA.length<2||pB.length<2) return false; const sldA=pA[pA.length-2].replace(/[^a-z]/gi,'').toLowerCase(); const sldB=pB[pB.length-2].replace(/[^a-z]/gi,'').toLowerCase(); return sldA===sldB; }\n"
                            +
                            "  const out = [];\n" +
                            "  const nodes = document.querySelectorAll('img, video, audio, source');\n" +
                            "  for (let i=0;i<nodes.length && out.length<maxSample;i++){\n" +
                            "    const n = nodes[i];\n" +
                            "    const v = n.getAttribute('src');\n" +
                            "    if (!v) continue;\n" +
                            "    let abs; try { abs = new URL(v, document.baseURI); } catch(e) { continue; }\n" +
                            "    const linkRoot = rootDomain(abs.host);\n" +
                            "    if (linkRoot && linkRoot !== pageRoot && !brandSimilar(linkRoot, pageRoot)) { out.push(abs.href); }\n"
                            +
                            "  }\n" +
                            "  return out;\n" +
                            "}",
                    Arrays.asList(pageRoot, MAX_ITEM_SAMPLES));
            return items;
        } catch (Exception ex) {
            // Fallback (sampled)
            List<String> media = new ArrayList<>();
            Locator mediaLocators = page.locator("img, video, audio, source");
            int count = Math.min(mediaLocators.count(), MAX_ITEM_SAMPLES);
            for (int i = 0; i < count; i++) {
                String src = mediaLocators.nth(i).getAttribute("src");
                if (src != null && isExternalDomain(src, pageUrl)) {
                    media.add(src);
                }
            }
            return media;
        }
    }

    private double calculateDomEntropy(Page page) {
        String textContent = page.textContent("body");
        if (textContent == null || textContent.trim().isEmpty()) {
            return 0;
        }
        Map<Character, Integer> frequencyMap = new HashMap<>();
        for (char c : textContent.toCharArray()) {
            frequencyMap.put(c, frequencyMap.getOrDefault(c, 0) + 1);
        }

        double entropy = 0.0;
        int textLength = textContent.length();
        for (int freq : frequencyMap.values()) {
            double probability = (double) freq / textLength;
            entropy -= probability * (Math.log(probability) / Math.log(2));
        }
        System.out.println("DOM entropy: " + entropy);
        return entropy;
    }

    private boolean checkTitleObfuscated(Page page) {
        String title = page.title();
        if (title == null || title.trim().isEmpty()) {
            return true;
        }
        // Check for random alphanumeric strings (e.g., more than 50% numbers)
        long digitCount = title.chars().filter(Character::isDigit).count();
        if ((double) digitCount / title.length() > 0.5) {
            System.out.println("Title appears obfuscated (high digit count): " + title);
            return true;
        }
        // Check for very short or very long titles
        if (title.length() < 5 || title.length() > 100) {
            System.out.println("Title appears obfuscated (unusual length): " + title);
            return true;
        }
        // Check for lack of spaces, suggesting a random string
        if (!title.contains(" ")) {
            System.out.println("Title appears obfuscated (no spaces): " + title);
            return true;
        }
        return false;
    }

    private boolean isExternalDomain(String link, String pageUrl) {
        try {
            URI linkUri = new URI(link);
            if (!linkUri.isAbsolute()) {
                return false; // Relative link
            }
            String linkHost = linkUri.getHost();
            String pageHost = new URI(pageUrl).getHost();

            String linkRootDomain = getRootDomain(linkHost);
            String pageRootDomain = getRootDomain(pageHost);

            // Same root domain = not external
            if (linkRootDomain != null && linkRootDomain.equals(pageRootDomain)) {
                return false;
            }

            // Heuristic: treat as internal if brand keys (hyphen/digit-insensitive SLDs)
            // are equal or off by one edit.
            if (brandKeysEqual(linkRootDomain, pageRootDomain)) {
                return false;
            }

            return true; // Different domain and not a known related domain
        } catch (URISyntaxException e) {
            return false; // Invalid URI
        }
    }

    private String getRootDomain(String host) {
        if (host == null) {
            return null;
        }
        String[] parts = host.split("\\.");
        if (parts.length > 1) {
            // Simple heuristic: return the last two parts (e.g., "facebook.com" from
            // "www.facebook.com")
            return parts[parts.length - 2] + "." + parts[parts.length - 1];
        }
        return host;
    }

    /**
     * Detects client-side redirects (meta refresh and JavaScript redirects)
     * that are invisible to HTTP-level analysis
     */
    private void detectClientSideRedirects(Page page, Evidences evidences) {
        // Guard: Only run once per evidences object
        if (evidences.getHasMetaRefresh() != null || evidences.getHasJavaScriptRedirect() != null) {
            System.out.println("[PageAnalysisService] Client-side redirect detection already performed, skipping");
            return;
        }

        System.out.println("[PageAnalysisService] Starting client-side redirect detection...");
        try {
            // Debug: Log page title and URL to verify we loaded correctly
            String pageTitle = page.title();
            String currentUrl = page.url();
            System.out.println("[PageAnalysisService] Loaded page - Title: '" + pageTitle + "', URL: " + currentUrl);

            // Debug: Get page HTML snippet to see what we're analyzing
            String htmlSnippet = (String) page.evaluate(
                    "() => { " +
                            "  const head = document.head ? document.head.innerHTML.substring(0, 500) : 'NO HEAD'; " +
                            "  return head; " +
                            "}");
            System.out.println("[PageAnalysisService] HTML head snippet: " + htmlSnippet);

            // 1. Check for <meta http-equiv="refresh"> redirects
            String metaRefreshContent = (String) page.evaluate(
                    "() => { " +
                            "  const meta = document.querySelector('meta[http-equiv=\"refresh\" i]'); " +
                            "  return meta ? meta.getAttribute('content') : null; " +
                            "}");

            System.out.println("[PageAnalysisService] Meta refresh check result: " + metaRefreshContent);

            if (metaRefreshContent != null && !metaRefreshContent.isEmpty()) {
                System.out.println("[PageAnalysisService] Meta refresh detected: " + metaRefreshContent);
                evidences.setHasMetaRefresh(true);
                evidences.setMetaRefreshContent(metaRefreshContent);
            } else {
                System.out.println("[PageAnalysisService] No meta refresh found");
            }

            // 2. Check for JavaScript redirects in inline scripts
            // Look for IMMEDIATE redirects (common phishing pattern), not just any use of
            // window.location
            Boolean hasJsRedirect = (Boolean) page.evaluate(
                    "() => { " +
                            "  const scripts = Array.from(document.querySelectorAll('script')); " +
                            "  const scriptText = scripts.map(s => s.textContent).join('\\n'); " +
                            "  const immediateRedirectPatterns = [" +
                            "    /(window|document)\\.location\\s*=\\s*['\\\"]http/i, " +
                            "    /(window|document)\\.location\\.replace\\(['\\\"]http/i, " +
                            "    /(window|document)\\.location\\.href\\s*=\\s*['\\\"]http/i, " +
                            "    /setTimeout\\s*\\(\\s*(function)?\\s*\\{?\\s*(window|document)\\.location/i " +
                            "  ]; " +
                            "  return immediateRedirectPatterns.some(pattern => pattern.test(scriptText)); " +
                            "}");

            System.out.println("[PageAnalysisService] JavaScript redirect check result: " + hasJsRedirect);

            if (Boolean.TRUE.equals(hasJsRedirect)) {
                System.out.println("[PageAnalysisService] JavaScript redirect detected in page scripts");
                evidences.setHasJavaScriptRedirect(true);
            } else {
                System.out.println("[PageAnalysisService] No JavaScript redirect found");
            }

            // 3. Extract redirect target URL if present in meta refresh
            if (metaRefreshContent != null) {
                String redirectUrl = extractRedirectUrlFromMetaRefresh(metaRefreshContent);
                if (redirectUrl != null) {
                    evidences.setClientSideRedirectTarget(redirectUrl);
                    System.out.println("[PageAnalysisService] Redirect target: " + redirectUrl);
                }
            }

        } catch (Exception e) {
            System.err.println("[PageAnalysisService] Error detecting client-side redirects: " + e.getMessage());
            e.printStackTrace();
        }
        System.out.println("[PageAnalysisService] Client-side redirect detection complete");
    }

    /**
     * Extracts the URL from a meta refresh content attribute
     * Format: "0; url=http://example.com" or "5;URL=http://example.com"
     */
    private String extractRedirectUrlFromMetaRefresh(String content) {
        if (content == null || content.isEmpty()) {
            return null;
        }

        // Look for url= or URL= (case-insensitive)
        int urlIndex = content.toLowerCase().indexOf("url=");
        if (urlIndex != -1) {
            String url = content.substring(urlIndex + 4).trim();
            // Remove quotes if present
            if (url.startsWith("'") || url.startsWith("\"")) {
                url = url.substring(1);
            }
            if (url.endsWith("'") || url.endsWith("\"")) {
                url = url.substring(0, url.length() - 1);
            }
            return url.trim();
        }

        return null;
    }

    private boolean brandKeysEqual(String rootA, String rootB) {
        if (rootA == null || rootB == null)
            return false;
        String[] a = rootA.split("\\.");
        String[] b = rootB.split("\\.");
        if (a.length < 2 || b.length < 2)
            return false;
        String sldA = a[a.length - 2].toLowerCase().replaceAll("[0-9-]", "");
        String sldB = b[b.length - 2].toLowerCase().replaceAll("[0-9-]", "");
        if (sldA.equals(sldB))
            return true;
        return levenshteinDistance(sldA, sldB) <= 1;
    }

    private int levenshteinDistance(String a, String b) {
        int n = a.length(), m = b.length();
        int[][] dp = new int[n + 1][m + 1];
        for (int i = 0; i <= n; i++)
            dp[i][0] = i;
        for (int j = 0; j <= m; j++)
            dp[0][j] = j;
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= m; j++) {
                int cost = a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1;
                dp[i][j] = Math.min(
                        Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1),
                        dp[i - 1][j - 1] + cost);
            }
        }
        return dp[n][m];
    }
}
