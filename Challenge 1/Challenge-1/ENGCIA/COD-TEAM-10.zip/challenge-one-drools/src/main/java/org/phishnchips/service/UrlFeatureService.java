package org.phishnchips.service;

import org.phishnchips.domain.model.Evidences;
import org.springframework.stereotype.Service;

import java.net.IDN;
import java.net.URL;

@Service
public class UrlFeatureService {

    // Removed static TLD blacklist in favor of heuristic and RDAP-based signals

    // Pattern retained in RedirectChainService where it's actually used

    public void enrich(Evidences ev) {
        if (ev == null || ev.getUrl() == null)
            return;

        final String url = ev.getUrl();
        ev.setUrlLength(url.length());

        // Check for '@' character anywhere in URL as potential obfuscation
        // Phishing patterns include:
        // 1. Authority: http://trusted.com@evil.com/ (hides real domain)
        // 2. Path: http://evil.com/login@paypal.com/ (visual deception)
        // 3. Subdomain: http://@paypal.com.evil.com/ (visual confusion)
        // We need to catch ALL these cases, so check entire URL
        ev.setHasAtChar(url.contains("@"));

        String host = null;
        String tmpUrl = url;
        if (!tmpUrl.matches("^[a-zA-Z][a-zA-Z0-9+.-]*://.*$")) {
            tmpUrl = "http://" + tmpUrl;
        }

        try {
            host = new URL(tmpUrl).getHost();
        } catch (Exception ignored) {
        }
        if (host == null)
            return;

        // normalize
        if (host.startsWith("www."))
            host = host.substring(4);

        // subdomain count (simple heuristic)
        int labels = host.split("\\.").length;
        ev.setSubdomainCount(Math.max(labels - 2, 0)); // Guard against negatives

        // Hyphens count (host only). Hyphens in article slugs are common and should not
        // be penalized.
        ev.setHyphensCount(countHyphens(host));

        // naive homograph flag: IDN punycode present
        String ascii = IDN.toASCII(host);
        ev.setHasHomograph(host.startsWith("xn--") || !host.equalsIgnoreCase(ascii));

        // NEW: Extract TLD
        String tld = extractTld(host);
        ev.setTld(tld);
        // Do not use static TLD blacklists; rely on RDAP-derived age/status and other
        // heuristics

        // NEW: Domain length (without TLD)
        String domainWithoutTld = extractDomainWithoutTld(host);
        ev.setDomainLength(domainWithoutTld != null ? domainWithoutTld.length() : 0);

        // NEW: Numeric ratio in domain
        double numericRatio = calculateNumericRatio(host);
        ev.setNumericRatio(numericRatio);
    }

    public static int countHyphens(String str) {
        if (str == null)
            return 0;

        int count = 0;
        for (char c : str.toCharArray()) {
            if (isHyphen(c)) {
                count++;
            }
        }
        return count;
    }

    // Função auxiliar para verificar se é hífen
    private static boolean isHyphen(char c) {
        return c == '-';
    }

    /**
     * Extract TLD from hostname (e.g., "example.com" -> "com", "example.co.uk" ->
     * "uk")
     */
    private String extractTld(String host) {
        if (host == null || host.isEmpty())
            return null;
        String[] parts = host.split("\\.");
        if (parts.length > 0) {
            return parts[parts.length - 1];
        }
        return null;
    }

    /**
     * Extract domain name without TLD (e.g., "sub.example.com" -> "sub.example")
     */
    private String extractDomainWithoutTld(String host) {
        if (host == null || host.isEmpty())
            return null;
        int lastDot = host.lastIndexOf('.');
        if (lastDot > 0) {
            return host.substring(0, lastDot);
        }
        return host;
    }

    /**
     * Calculate ratio of numeric characters in hostname (0.0 to 1.0)
     */
    private double calculateNumericRatio(String host) {
        if (host == null || host.isEmpty())
            return 0.0;

        int digitCount = 0;
        int totalChars = 0;

        for (char c : host.toCharArray()) {
            // Only count alphanumeric characters (exclude dots, hyphens)
            if (Character.isLetterOrDigit(c)) {
                totalChars++;
                if (Character.isDigit(c)) {
                    digitCount++;
                }
            }
        }

        return totalChars > 0 ? (double) digitCount / totalChars : 0.0;
    }
}
