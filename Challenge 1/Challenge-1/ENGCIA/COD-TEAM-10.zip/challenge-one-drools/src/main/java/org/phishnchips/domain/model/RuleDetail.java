package org.phishnchips.domain.model;

public class RuleDetail {
    private final String finding;
    private final String value;

    public RuleDetail(String finding, String value) {
        this.finding = finding;
        this.value = value;
    }

    public String getFinding() {
        return finding;
    }

    public String getValue() {
        return value;
    }
}

