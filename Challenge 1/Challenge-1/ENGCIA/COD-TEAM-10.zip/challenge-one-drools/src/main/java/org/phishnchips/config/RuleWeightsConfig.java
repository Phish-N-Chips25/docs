package org.phishnchips.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuration class that loads rule weights from rule-weights.yml
 * Allows dynamic configuration of phishing detection scoring without
 * recompiling rules.
 */
@Configuration
@ConfigurationProperties(prefix = "")
public class RuleWeightsConfig {

    private Map<String, Integer> url = new HashMap<>();
    private Map<String, Integer> dns = new HashMap<>();
    private Map<String, Integer> redirect = new HashMap<>();
    private Map<String, Integer> dom = new HashMap<>();
    private Map<String, Integer> thresholds = new HashMap<>();

    // URL weights
    public Map<String, Integer> getUrl() {
        return url;
    }

    public void setUrl(Map<String, Integer> url) {
        this.url = url;
    }

    public int getUrlWeight(String key) {
        Integer value = url.get(key);
        if (value == null) {
            throw new IllegalStateException("Missing URL weight configuration for key: " + key);
        }
        return value;
    }

    // DNS weights
    public Map<String, Integer> getDns() {
        return dns;
    }

    public void setDns(Map<String, Integer> dns) {
        this.dns = dns;
    }

    public int getDnsWeight(String key) {
        Integer value = dns.get(key);
        if (value == null) {
            throw new IllegalStateException("Missing DNS weight configuration for key: " + key);
        }
        return value;
    }

    // Redirect weights
    public Map<String, Integer> getRedirect() {
        return redirect;
    }

    public void setRedirect(Map<String, Integer> redirect) {
        this.redirect = redirect;
    }

    public int getRedirectWeight(String key) {
        Integer value = redirect.get(key);
        if (value == null) {
            throw new IllegalStateException("Missing Redirect weight configuration for key: " + key);
        }
        return value;
    }

    // DOM weights
    public Map<String, Integer> getDom() {
        return dom;
    }

    public void setDom(Map<String, Integer> dom) {
        this.dom = dom;
    }

    public int getDomWeight(String key) {
        Integer value = dom.get(key);
        if (value == null) {
            throw new IllegalStateException("Missing DOM weight configuration for key: " + key);
        }
        return value;
    }

    // Thresholds
    public Map<String, Integer> getThresholds() {
        return thresholds;
    }

    public void setThresholds(Map<String, Integer> thresholds) {
        this.thresholds = thresholds;
    }

    public int getThreshold(String key) {
        Integer value = thresholds.get(key);
        if (value == null) {
            throw new IllegalStateException("Missing threshold configuration for key: " + key);
        }
        return value;
    }
}
