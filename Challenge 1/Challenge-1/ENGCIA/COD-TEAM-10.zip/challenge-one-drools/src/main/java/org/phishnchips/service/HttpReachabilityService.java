package org.phishnchips.service;

import org.phishnchips.domain.model.Evidences;
import org.springframework.stereotype.Service;

import javax.net.ssl.SSLHandshakeException;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.net.UnknownHostException;

@Service
public class HttpReachabilityService {

    private static final int CONNECT_TIMEOUT = 5000; // 5 seconds
    private static final int READ_TIMEOUT = 5000;    // 5 seconds

    public void enrich(Evidences ev) {
        if (ev == null || ev.getUrl() == null) return;

        final String urlString = ev.getUrl();

        // Check if URL uses HTTPS
        ev.setUsesHttps(urlString.toLowerCase().startsWith("https://"));

        // Perform reachability check
        HttpURLConnection connection = null;
        try {
            URL url = new URL(urlString);
            connection = (HttpURLConnection) url.openConnection();

            // Configure connection
            connection.setInstanceFollowRedirects(false);  // Don't follow redirects
            connection.setConnectTimeout(CONNECT_TIMEOUT);
            connection.setReadTimeout(READ_TIMEOUT);
            connection.setRequestMethod("HEAD");

            // Set realistic user agent
            connection.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36");

            int responseCode = connection.getResponseCode();
            ev.setHttpStatusCode(responseCode);
            ev.setIsReachable(true);
            ev.setHasTlsError(false);

            // Categorize response
            if (responseCode >= 200 && responseCode < 300) {
                ev.setReachabilityReason("success");
            } else if (responseCode >= 300 && responseCode < 400) {
                ev.setReachabilityReason("redirect");
            } else if (responseCode >= 400 && responseCode < 500) {
                ev.setReachabilityReason("client_error");
            } else if (responseCode >= 500 && responseCode < 600) {
                ev.setReachabilityReason("server_error");
            } else {
                ev.setReachabilityReason("http_error");
            }

        } catch (SSLHandshakeException sslEx) {
            // TLS/SSL certificate validation failed
            ev.setIsReachable(false);
            ev.setHasTlsError(true);
            ev.setReachabilityReason("tls_error");
            System.err.println("TLS/SSL error for " + urlString + ": " + sslEx.getMessage());

        } catch (UnknownHostException | SocketTimeoutException netEx) {
            // Network failure (DNS resolution failed or timeout)
            ev.setIsReachable(false);
            ev.setHasTlsError(false);
            ev.setReachabilityReason("network_failure");
            System.err.println("Network error for " + urlString + ": " + netEx.getMessage());

        } catch (IOException ioEx) {
            // Generic connection failure
            ev.setIsReachable(false);
            ev.setHasTlsError(false);
            ev.setReachabilityReason("network_failure");
            System.err.println("Connection error for " + urlString + ": " + ioEx.getMessage());

        } catch (Exception ex) {
            // Unexpected error
            ev.setIsReachable(false);
            ev.setHasTlsError(false);
            ev.setReachabilityReason("unknown_error");
            System.err.println("Unexpected error checking reachability for " + urlString + ": " + ex.getMessage());

        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }
}
