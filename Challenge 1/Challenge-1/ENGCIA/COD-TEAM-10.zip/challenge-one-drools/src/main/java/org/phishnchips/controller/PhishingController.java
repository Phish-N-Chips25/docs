package org.phishnchips.controller;

import org.phishnchips.domain.model.Conclusion;
import org.phishnchips.domain.model.Evidences;
import org.phishnchips.service.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "*")
public class PhishingController {

    private final PhishingService phishingService;
    private final DnsAnalysisService dnsAnalysisService;
    private final UrlAnalysisService urlAnalysisService;
    private final UrlFeatureService urlFeatureService;
    private final RedirectChainService redirectChainService;
    private final PageAnalysisService pageAnalysisService;

    public PhishingController(PhishingService phishingService,
            DnsAnalysisService dnsAnalysisService,
            UrlAnalysisService urlAnalysisService,
            RedirectChainService redirectChainService,
            UrlFeatureService urlFeatureService,
            PageAnalysisService pageAnalysisService) {
        this.urlFeatureService = urlFeatureService;
        this.phishingService = phishingService;
        this.dnsAnalysisService = dnsAnalysisService;
        this.urlAnalysisService = urlAnalysisService;
        this.redirectChainService = redirectChainService;
        this.pageAnalysisService = pageAnalysisService;
    }

    @GetMapping("/health")
    public String health() {
        return "OK";
    }

    @PostMapping("/evaluate")
    public ResponseEntity<Conclusion> evaluate(@RequestBody Evidences evidences) {
        // PHASE 1: Fast operations (URL parsing, lexical analysis)
        urlAnalysisService.analyzeUrl(evidences);
        urlFeatureService.enrich(evidences);

        // PHASE 2: Medium-speed operations (DNS lookups)
        dnsAnalysisService.enrich(evidences);
        System.out.printf("[DNS] a=%s mx=%s spf=%s minTTL=%s maxTTL=%s age=%s idn=%s cnameHops=%s%n",
                evidences.getDnsARecordCount(),
                evidences.getDnsHasMX(),
                evidences.getDnsHasSPF(),
                evidences.getDnsMinTTL(),
                evidences.getDnsMaxTTL(),
                evidences.getDomainAgeDays(),
                evidences.getIdn(),
                evidences.getCnameChainLength());

        // PHASE 3: Slower operations (HTTP redirect chain - makes requests)
        redirectChainService.enrich(evidences);
        System.out.printf(
                "[REDIRECT] chain=%s excessive=%s untrusted=%s openRedirect=%s obfuscated=%s shortener=%s finalDestTrusted=%s finalDestAge=%s%n",
                evidences.getRedirectChainLength(),
                evidences.getHasExcessiveRedirects(),
                evidences.getHasUntrustedRedirect(),
                evidences.getHasOpenRedirect(),
                evidences.getHasObfuscatedRedirect(),
                evidences.getUsesUrlShortener(),
                evidences.getFinalDestinationTrusted(),
                evidences.getFinalDestinationDomainAgeDays());

        // PHASE 4: DOM analysis with Playwright (stealth mode, anti-bot evasion)
        // ALWAYS run - sophisticated phishing sites can appear legitimate in URL/DNS
        // checks
        System.out.println("[DOM] Running Playwright analysis with stealth mode");
        pageAnalysisService.analyzePage(evidences);

        // Log DOM analysis results
        System.out.printf(
                "[DOM] sensitiveFields=%d externalForms=%d externalLinks=%d externalMedia=%d entropy=%.2f titleObfuscated=%s%n",
                evidences.getSensitiveFieldsFound().size(),
                evidences.getExternalFormActions().size(),
                evidences.getExternalOrNullLinks().size(),
                evidences.getExternalMedia().size(),
                evidences.getDomEntropy(),
                evidences.isTitleObfuscated());

        // PHASE 5: Final evaluation with Drools rules
        Conclusion result = phishingService.evaluate(evidences);
        return (result == null) ? ResponseEntity.noContent().build() : ResponseEntity.ok(result);
    }

}
