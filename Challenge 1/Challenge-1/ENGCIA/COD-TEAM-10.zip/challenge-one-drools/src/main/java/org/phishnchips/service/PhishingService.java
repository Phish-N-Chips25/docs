package org.phishnchips.service;

import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.phishnchips.config.RuleWeightsConfig;
import org.phishnchips.domain.model.Conclusion;
import org.phishnchips.domain.model.Evidences;
import org.phishnchips.domain.model.ScoreCard;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Value;

@Service
public class PhishingService {
    private static final Logger log = LoggerFactory.getLogger(PhishingService.class);
    private static final String SESSION_NAME = "ksession-rules"; // keep in one place

    // This is API key is just a placeholder for demonstration purposes.
    private final KieContainer kieContainer;
    private final RuleWeightsConfig weightsConfig;

    public PhishingService(@Value("${api.key}") String apiKey, KieContainer kieContainer, RuleWeightsConfig weightsConfig) {
        // apiKey parameter kept for future authentication implementation
        this.kieContainer = kieContainer;
        this.weightsConfig = weightsConfig;
    }

    public Conclusion evaluate(Evidences evidences) {
        KieSession kSession = kieContainer.newKieSession(SESSION_NAME);
        int sessionId = System.identityHashCode(kSession);
        log.debug("Created KieSession [{}]", sessionId);
        try {
            log.debug("Inserting evidences: {}", evidences);
            ScoreCard scoreCard = new ScoreCard();

            // Make config available to Drools rules as a global variable
            kSession.setGlobal("weightsConfig", weightsConfig);

            kSession.insert(evidences);
            kSession.insert(scoreCard);

            // Get total number of rules in the knowledge base
            int totalRulesEvaluated = kSession.getKieBase().getKiePackages().stream()
                    .mapToInt(pkg -> pkg.getRules().size())
                    .sum();

            // Fire all rules and get the count of rules that were triggered
            int rulesFired = kSession.fireAllRules();
            log.debug("Rules fired: {} out of {}", rulesFired, totalRulesEvaluated);

            int finalScore = scoreCard.getScore();
            String status;

            // Use configured thresholds
            int phishingThreshold = weightsConfig.getThreshold("phishing");
            int probablePhishingThreshold = weightsConfig.getThreshold("probable_phishing");
            int suspiciousThreshold = weightsConfig.getThreshold("suspicious");

            if (finalScore >= phishingThreshold) {
                status = "PHISHING";
            } else if (finalScore >= probablePhishingThreshold) {
                status = "PROBABLE_PHISHING";
            } else if (finalScore >= suspiciousThreshold) {
                status = "SUSPICIOUS";
            } else {
                status = "LEGITIMATE";
            }

            // Get the number of rules that contributed to the score
            int totalRulesTriggered = scoreCard.getTriggeredRules().size();

            Conclusion result = new Conclusion(status, finalScore, scoreCard.getTriggeredRules(), totalRulesTriggered, totalRulesEvaluated);

            log.info("Conclusion produced: {} - {} rules triggered out of {} evaluated", result.getStatus(), totalRulesTriggered, totalRulesEvaluated);
            return result;
        } finally {
            kSession.dispose();
            log.debug("Disposed KieSession [{}]", sessionId);
        }
    }
}
