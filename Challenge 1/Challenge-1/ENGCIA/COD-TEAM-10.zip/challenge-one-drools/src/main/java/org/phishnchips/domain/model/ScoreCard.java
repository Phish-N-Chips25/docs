package org.phishnchips.domain.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ScoreCard {
    private int score = 0;
    private final Map<String, TriggeredRule> triggeredRules = new HashMap<>();

    public int getScore() {
        return score;
    }

    public void addScore(int points, String ruleName, String description, List<RuleDetail> details) {
        this.score += points;
        this.triggeredRules.put(ruleName, new TriggeredRule(points, description, details));
    }

    public Map<String, TriggeredRule> getTriggeredRules() {
        return triggeredRules;
    }
}
