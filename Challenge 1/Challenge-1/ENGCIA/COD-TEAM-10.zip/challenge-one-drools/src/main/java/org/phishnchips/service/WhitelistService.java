package org.phishnchips.service;

import org.phishnchips.domain.model.Evidences;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Service
public class WhitelistService {

    // Trusted domains (allowlist) - matches Prolog engine whitelist
    private static final Set<String> WHITELISTED_DOMAINS = new HashSet<>(Arrays.asList(
        "isep.ipp.pt", "youtube.com"
    ));

    // Trusted IP ranges (example: internal/private IPs, localhost)
    private static final Set<String> WHITELISTED_IPS = new HashSet<>(Arrays.asList(
        "127.0.0.1", "::1", "localhost"
    ));

    public void enrich(Evidences ev) {
        if (ev == null || ev.getUrl() == null) return;

        String url = ev.getUrl();
        
        try {
            URI uri = new URI(url);
            String host = uri.getHost();
            
            if (host == null) {
                return;
            }

            // Normalize host (lowercase, remove www.)
            host = host.toLowerCase();
            if (host.startsWith("www.")) {
                host = host.substring(4);
            }

            // Check if IP is whitelisted
            if (ev.getIsIpHost() && WHITELISTED_IPS.contains(host)) {
                ev.setisWhiteListedIpHost(true);
                return;
            }

            // Check if domain or any parent domain is whitelisted
            ev.setIsWhiteListedDomain(isDomainWhitelisted(host));

        } catch (Exception e) {
            // If URL parsing fails, assume not whitelisted
            ev.setIsWhiteListedDomain(false);
            ev.setisWhiteListedIpHost(false);
        }
    }

    /**
     * Check if a domain or any of its parent domains is in the whitelist
     * e.g., "maps.google.com" matches "google.com"
     */
    private boolean isDomainWhitelisted(String host) {
        // Check exact match
        if (WHITELISTED_DOMAINS.contains(host)) {
            return true;
        }

        // Check if it's a subdomain of any whitelisted domain
        for (String whitelistedDomain : WHITELISTED_DOMAINS) {
            if (host.endsWith("." + whitelistedDomain)) {
                return true;
            }
        }

        return false;
    }
}
