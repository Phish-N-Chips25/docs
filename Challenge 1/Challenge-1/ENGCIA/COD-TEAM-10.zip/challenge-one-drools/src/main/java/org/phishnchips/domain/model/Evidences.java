package org.phishnchips.domain.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.util.ArrayList;
import java.util.List;

/**
 * Unified fact carrying URL/lexical features (set by UrlFeatureService)
 * DNS features (set by DnsAnalysisService)
 * and DOM features (set by PageAnalysisService)
 */
public class Evidences {

    // ------------------------------------------------------------
    // Core input
    // ------------------------------------------------------------
    private String url;

    // ------------------------------------------------------------
    // URL / Lexical features
    // ------------------------------------------------------------
    private boolean hasAtChar;
    private boolean isIpHost;
    private boolean hasHomograph;
    private int hyphensCount;
    private boolean isWhiteListedDomain;
    private boolean isWhiteListedIpHost;
    private int urlLength;
    private int subdomainCount;
    private int domainAgeInDays;
    private boolean isDomainRegistered;
    private boolean manyHyphensOrDigits;

    // New fields for Prolog parity
    private String tld; // Top-level domain (e.g., "xyz", "com")
    private int domainLength; // Length of domain name (without TLD)
    private double numericRatio; // Ratio of numeric characters in domain (0.0-1.0)

    // ------------------------------------------------------------
    // DNS features
    // ------------------------------------------------------------
    private Integer dnsARecordCount; // total A+AAAA records (null if lookup failed)
    private Boolean dnsHasMX; // MX record present
    private Boolean dnsHasSPF; // TXT record contains "v=spf1"
    private Integer dnsMinTTL; // min TTL (seconds) among A/AAAA (null if unknown)
    private Integer dnsMaxTTL; // max TTL (seconds) among A/AAAA (null if unknown)
    private Integer domainAgeDays; // WHOIS-derived age (null if unknown)
    private Boolean idn; // punycode/IDN host (possible homograph)
    private Integer cnameChainLength; // number of CNAME hops (null if unknown)
    private Boolean hasCnameLoop; // true if CNAME chain contains a loop (circular reference)
    private Integer nameServerCount; // number of authoritative NS records (null if unknown)
    private Boolean hasValidReverseDns; // true if A record IPs have matching PTR records
    private Boolean hasDmarc; // true if DMARC policy exists (_dmarc TXT record)
    private Boolean hasDkim; // true if common DKIM selector records exist
    private Integer dnsResponseTimeMs; // average DNS query response time in milliseconds (null if unknown)

    // RDAP-derived domain registration info
    private Boolean domainSuspended; // true if domain status indicates suspension/hold/redemption
    private Integer daysUntilExpiration; // days until domain expires (null if unknown, negative if already expired)

    // ------------------------------------------------------------
    // HTTP Redirect Chain features
    // ------------------------------------------------------------
    private Integer redirectChainLength; // number of HTTP redirects (null if unknown)
    private Boolean hasExcessiveRedirects; // true if redirect count exceeds threshold
    private Boolean hasUntrustedRedirect; // true if any redirect passes through untrusted domain
    private Boolean hasOpenRedirect; // true if open redirect pattern detected
    private Boolean hasObfuscatedRedirect; // true if URL obfuscation detected in chain
    private Boolean redirectChainBroken; // true if redirect chain analysis failed
    private Boolean usesUrlShortener; // true if URL shortener detected
    private Boolean finalDestinationTrusted; // true if final destination (last in chain) is a trusted domain
    private Integer finalDestinationDomainAgeDays; // WHOIS-derived age of final destination domain (null if unknown)
    private List<String> redirectChain = new ArrayList<>(); // full redirect chain

    // ------------------------------------------------------------
    // HTTP Transport / Reachability features
    // ------------------------------------------------------------
    private Boolean usesHttps; // true if URL uses HTTPS, false if HTTP
    private Boolean isReachable; // true if URL is reachable, false otherwise
    private Integer httpStatusCode; // HTTP status code (200, 404, 500, etc.)
    private String reachabilityReason; // Reason: success, network_failure, client_error, server_error, redirect
    private Boolean hasTlsError; // true if TLS/SSL certificate validation failed

    // ------------------------------------------------------------
    // DOM features
    // ------------------------------------------------------------
    private boolean hasPasswordField;
    private int sensitiveInputFieldsCount;
    private int dataExfiltrationScore;
    private double linkFeaturesRatio;
    private double dependentRequestRatio;
    private double domEntropy;
    private boolean titleObfuscated;

    private List<String> sensitiveFieldsFound = new ArrayList<>();
    private List<String> externalFormActions = new ArrayList<>();
    private List<String> externalOrNullLinks = new ArrayList<>();
    private List<String> externalMedia = new ArrayList<>();

    // ------------------------------------------------------------
    // Client-side redirect detection (meta refresh + JavaScript)
    // ------------------------------------------------------------
    private Boolean hasMetaRefresh; // true if <meta http-equiv="refresh"> detected
    private String metaRefreshContent; // content attribute of meta refresh tag
    private Boolean hasJavaScriptRedirect; // true if window.location/document.location detected
    private String clientSideRedirectTarget; // extracted redirect target URL

    // ------------------------------------------------------------
    // URL Path Analysis (suspicious patterns)
    // ------------------------------------------------------------
    private Boolean hasSuspiciousPath; // true if path contains suspicious patterns
    private String suspiciousPathPattern; // which pattern matched
    private Boolean hasObfuscatedParams; // true if URL parameters are obfuscated/encoded

    // ------------------------------------------------------------
    // Subdomain/Host Analysis (statistical, non-blacklist)
    // ------------------------------------------------------------
    private Boolean hasSuspiciousSubdomain; // true if subdomain structure looks anomalous
    private String suspiciousSubdomainPattern; // reason/pattern label

    // ------------------------------------------------------------
    // Constructors
    // ------------------------------------------------------------
    public Evidences() {
    }

    public Evidences(boolean hasAtChar,
            boolean isIpHost,
            boolean hasHomograph,
            int hyphensCount,
            int urlLength,
            int subdomainCount) {
        this.hasAtChar = hasAtChar;
        this.isIpHost = isIpHost;
        this.hasHomograph = hasHomograph;
        this.hyphensCount = hyphensCount;
        this.urlLength = urlLength;
        this.subdomainCount = subdomainCount;
    }

    public Evidences(String url) {
        this.url = url;

        this.hasAtChar = false;
        this.isIpHost = false;
        this.isDomainRegistered = false;
        this.hasHomograph = false;
        this.hyphensCount = 0;
        this.hasPasswordField = false;
        this.titleObfuscated = false;
        this.isWhiteListedDomain = false;
        this.isWhiteListedIpHost = false;
        this.manyHyphensOrDigits = false;

        this.urlLength = 0;
        this.subdomainCount = 0;
        this.sensitiveInputFieldsCount = 0;
        this.dataExfiltrationScore = 0;
        this.linkFeaturesRatio = 0.0;
        this.dependentRequestRatio = 0.0;
        this.domEntropy = 0.0;
        this.domainAgeInDays = 0;

        this.sensitiveFieldsFound = new java.util.ArrayList<>();
        this.externalFormActions = new java.util.ArrayList<>();
        this.externalOrNullLinks = new java.util.ArrayList<>();
        this.externalMedia = new java.util.ArrayList<>();
    }

    // ------------------------------------------------------------
    // Getters / Setters — Core
    // ------------------------------------------------------------
    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    // ------------------------------------------------------------
    // Getters / Setters — URL Lexical
    // ------------------------------------------------------------
    @JsonProperty("hasAtChar")
    public boolean isHasAtChar() {
        return hasAtChar;
    }

    public void setHasAtChar(boolean hasAtChar) {
        this.hasAtChar = hasAtChar;
    }

    @JsonProperty("isIpHost")
    public boolean getIsIpHost() {
        return isIpHost;
    }

    public void setIsIpHost(boolean isIpHost) {
        this.isIpHost = isIpHost;
    }

    @JsonProperty("hasHomograph")
    public boolean isHasHomograph() {
        return hasHomograph;
    }

    public void setHasHomograph(boolean hasHomograph) {
        this.hasHomograph = hasHomograph;
    }

    public int getHyphensCount() {
        return hyphensCount;
    }

    public void setHyphensCount(int hyphensCount) {
        this.hyphensCount = hyphensCount;
    }

    @JsonProperty("manyHyphensOrDigits")
    public boolean getManyHyphensOrDigits() {
        return manyHyphensOrDigits;
    }

    public void setManyHyphensOrDigits(boolean manyHyphensOrDigits) {
        this.manyHyphensOrDigits = manyHyphensOrDigits;
    }

    public int getDomainAgeInDays() {
        return domainAgeInDays;
    }

    public void setDomainAgeInDays(int domainAgeInDays) {
        this.domainAgeInDays = domainAgeInDays;
    }

    public int getUrlLength() {
        return urlLength;
    }

    public void setUrlLength(int urlLength) {
        this.urlLength = urlLength;
    }

    public int getSubdomainCount() {
        return subdomainCount;
    }

    public void setSubdomainCount(int subdomainCount) {
        this.subdomainCount = subdomainCount;
    }

    public boolean getIsDomainIsDomainRegistered() {
        return isDomainRegistered;
    }

    public void setIsDomainIsDomainRegistered(boolean isDomainRegistered) {
        this.isDomainRegistered = isDomainRegistered;
    }

    public boolean getIsWhiteListedDomain() {
        return isWhiteListedDomain;
    }

    public void setIsWhiteListedDomain(boolean isWhiteListedDomain) {
        this.isWhiteListedDomain = isWhiteListedDomain;
    }

    public boolean getisWhiteListedIpHost() {
        return isWhiteListedIpHost;
    }

    public void setisWhiteListedIpHost(boolean isWhiteListedIpHost) {
        this.isWhiteListedIpHost = isWhiteListedIpHost;
    }

    // ------------------------------------------------------------
    // Getters / Setters — New URL Lexical fields
    // ------------------------------------------------------------
    public String getTld() {
        return tld;
    }

    public void setTld(String tld) {
        this.tld = tld;
    }

    public int getDomainLength() {
        return domainLength;
    }

    public void setDomainLength(int domainLength) {
        this.domainLength = domainLength;
    }

    public double getNumericRatio() {
        return numericRatio;
    }

    public void setNumericRatio(double numericRatio) {
        this.numericRatio = numericRatio;
    }

    // hasSuspiciousTld removed — replaced by RDAP-based signals (age/status)
    // ------------------------------------------------------------
    // Getters / Setters — DNS
    // ------------------------------------------------------------

    public Integer getDnsARecordCount() {
        return dnsARecordCount;
    }

    public void setDnsARecordCount(Integer dnsARecordCount) {
        this.dnsARecordCount = dnsARecordCount;
    }

    public Boolean getDnsHasMX() {
        return dnsHasMX;
    }

    public void setDnsHasMX(Boolean dnsHasMX) {
        this.dnsHasMX = dnsHasMX;
    }

    public Boolean getDnsHasSPF() {
        return dnsHasSPF;
    }

    public void setDnsHasSPF(Boolean dnsHasSPF) {
        this.dnsHasSPF = dnsHasSPF;
    }

    public Integer getDnsMinTTL() {
        return dnsMinTTL;
    }

    public void setDnsMinTTL(Integer dnsMinTTL) {
        this.dnsMinTTL = dnsMinTTL;
    }

    public Integer getDnsMaxTTL() {
        return dnsMaxTTL;
    }

    public void setDnsMaxTTL(Integer dnsMaxTTL) {
        this.dnsMaxTTL = dnsMaxTTL;
    }

    public Integer getDomainAgeDays() {
        return domainAgeDays;
    }

    public void setDomainAgeDays(Integer domainAgeDays) {
        this.domainAgeDays = domainAgeDays;
    }

    public Boolean getIdn() { // <-- rename to getIdn()
        return idn;
    }

    public void setIdn(Boolean idn) {
        this.idn = idn;
    }

    public Integer getCnameChainLength() {
        return cnameChainLength;
    }

    public void setCnameChainLength(Integer cnameChainLength) {
        this.cnameChainLength = cnameChainLength;
    }

    // ------------------------------------------------------------
    // Getters / Setters — HTTP Transport / Reachability
    // ------------------------------------------------------------
    public Boolean getUsesHttps() {
        return usesHttps;
    }

    public void setUsesHttps(Boolean usesHttps) {
        this.usesHttps = usesHttps;
    }

    public Boolean getIsReachable() {
        return isReachable;
    }

    public void setIsReachable(Boolean isReachable) {
        this.isReachable = isReachable;
    }

    public Integer getHttpStatusCode() {
        return httpStatusCode;
    }

    public void setHttpStatusCode(Integer httpStatusCode) {
        this.httpStatusCode = httpStatusCode;
    }

    public String getReachabilityReason() {
        return reachabilityReason;
    }

    public void setReachabilityReason(String reachabilityReason) {
        this.reachabilityReason = reachabilityReason;
    }

    public Boolean getHasTlsError() {
        return hasTlsError;
    }

    public void setHasTlsError(Boolean hasTlsError) {
        this.hasTlsError = hasTlsError;
    }

    // ------------------------------------------------------------
    // Getters / Setters — HTTP Redirect Chain
    // ------------------------------------------------------------

    public Integer getRedirectChainLength() {
        return redirectChainLength;
    }

    public void setRedirectChainLength(Integer redirectChainLength) {
        this.redirectChainLength = redirectChainLength;
    }

    public Boolean getHasExcessiveRedirects() {
        return hasExcessiveRedirects;
    }

    public void setHasExcessiveRedirects(Boolean hasExcessiveRedirects) {
        this.hasExcessiveRedirects = hasExcessiveRedirects;
    }

    public Boolean getHasUntrustedRedirect() {
        return hasUntrustedRedirect;
    }

    public void setHasUntrustedRedirect(Boolean hasUntrustedRedirect) {
        this.hasUntrustedRedirect = hasUntrustedRedirect;
    }

    public Boolean getHasOpenRedirect() {
        return hasOpenRedirect;
    }

    public void setHasOpenRedirect(Boolean hasOpenRedirect) {
        this.hasOpenRedirect = hasOpenRedirect;
    }

    public Boolean getHasObfuscatedRedirect() {
        return hasObfuscatedRedirect;
    }

    public void setHasObfuscatedRedirect(Boolean hasObfuscatedRedirect) {
        this.hasObfuscatedRedirect = hasObfuscatedRedirect;
    }

    public Boolean getRedirectChainBroken() {
        return redirectChainBroken;
    }

    public void setRedirectChainBroken(Boolean redirectChainBroken) {
        this.redirectChainBroken = redirectChainBroken;
    }

    public Boolean getUsesUrlShortener() {
        return usesUrlShortener;
    }

    public void setUsesUrlShortener(Boolean usesUrlShortener) {
        this.usesUrlShortener = usesUrlShortener;
    }

    public Boolean getFinalDestinationTrusted() {
        return finalDestinationTrusted;
    }

    public void setFinalDestinationTrusted(Boolean finalDestinationTrusted) {
        this.finalDestinationTrusted = finalDestinationTrusted;
    }

    public Integer getFinalDestinationDomainAgeDays() {
        return finalDestinationDomainAgeDays;
    }

    public void setFinalDestinationDomainAgeDays(Integer finalDestinationDomainAgeDays) {
        this.finalDestinationDomainAgeDays = finalDestinationDomainAgeDays;
    }

    public List<String> getRedirectChain() {
        return redirectChain;
    }

    public void setRedirectChain(List<String> redirectChain) {
        this.redirectChain = redirectChain;
    }

    // ------------------------------------------------------------
    // Getters / Setters — DOM
    // ------------------------------------------------------------
    @JsonProperty("hasPasswordField")
    public boolean isHasPasswordField() {
        return hasPasswordField;
    }

    public void setHasPasswordField(boolean hasPasswordField) {
        this.hasPasswordField = hasPasswordField;
    }

    @JsonProperty("titleObfuscated")
    public boolean isTitleObfuscated() {
        return titleObfuscated;
    }

    public void setTitleObfuscated(boolean titleObfuscated) {
        this.titleObfuscated = titleObfuscated;
    }

    public int getSensitiveInputFieldsCount() {
        return sensitiveInputFieldsCount;
    }

    public void setSensitiveInputFieldsCount(int sensitiveInputFieldsCount) {
        this.sensitiveInputFieldsCount = sensitiveInputFieldsCount;
    }

    public int getDataExfiltrationScore() {
        return dataExfiltrationScore;
    }

    public void setDataExfiltrationScore(int dataExfiltrationScore) {
        this.dataExfiltrationScore = dataExfiltrationScore;
    }

    public double getLinkFeaturesRatio() {
        return linkFeaturesRatio;
    }

    public void setLinkFeaturesRatio(double linkFeaturesRatio) {
        this.linkFeaturesRatio = linkFeaturesRatio;
    }

    public double getDependentRequestRatio() {
        return dependentRequestRatio;
    }

    public void setDependentRequestRatio(double dependentRequestRatio) {
        this.dependentRequestRatio = dependentRequestRatio;
    }

    public double getDomEntropy() {
        return domEntropy;
    }

    public void setDomEntropy(double domEntropy) {
        this.domEntropy = domEntropy;
    }

    public List<String> getSensitiveFieldsFound() {
        return sensitiveFieldsFound;
    }

    public void setSensitiveFieldsFound(List<String> sensitiveFieldsFound) {
        this.sensitiveFieldsFound = sensitiveFieldsFound;
    }

    public List<String> getExternalFormActions() {
        return externalFormActions;
    }

    public void setExternalFormActions(List<String> externalFormActions) {
        this.externalFormActions = externalFormActions;
    }

    public List<String> getExternalOrNullLinks() {
        return externalOrNullLinks;
    }

    public void setExternalOrNullLinks(List<String> externalOrNullLinks) {
        this.externalOrNullLinks = externalOrNullLinks;
    }

    public List<String> getExternalMedia() {
        return externalMedia;
    }

    public void setExternalMedia(List<String> externalMedia) {
        this.externalMedia = externalMedia;
    }

    // ------------------------------------------------------------
    // Getters / Setters — Client-side redirects
    // ------------------------------------------------------------
    public Boolean getHasMetaRefresh() {
        return hasMetaRefresh;
    }

    public void setHasMetaRefresh(Boolean hasMetaRefresh) {
        this.hasMetaRefresh = hasMetaRefresh;
    }

    public String getMetaRefreshContent() {
        return metaRefreshContent;
    }

    public void setMetaRefreshContent(String metaRefreshContent) {
        this.metaRefreshContent = metaRefreshContent;
    }

    public Boolean getHasJavaScriptRedirect() {
        return hasJavaScriptRedirect;
    }

    public void setHasJavaScriptRedirect(Boolean hasJavaScriptRedirect) {
        this.hasJavaScriptRedirect = hasJavaScriptRedirect;
    }

    public String getClientSideRedirectTarget() {
        return clientSideRedirectTarget;
    }

    public void setClientSideRedirectTarget(String clientSideRedirectTarget) {
        this.clientSideRedirectTarget = clientSideRedirectTarget;
    }

    // Path analysis getters/setters
    public Boolean getHasSuspiciousPath() {
        return hasSuspiciousPath;
    }

    public void setHasSuspiciousPath(Boolean hasSuspiciousPath) {
        this.hasSuspiciousPath = hasSuspiciousPath;
    }

    public String getSuspiciousPathPattern() {
        return suspiciousPathPattern;
    }

    public void setSuspiciousPathPattern(String suspiciousPathPattern) {
        this.suspiciousPathPattern = suspiciousPathPattern;
    }

    public Boolean getHasObfuscatedParams() {
        return hasObfuscatedParams;
    }

    public void setHasObfuscatedParams(Boolean hasObfuscatedParams) {
        this.hasObfuscatedParams = hasObfuscatedParams;
    }

    // Subdomain analysis getters/setters
    public Boolean getHasSuspiciousSubdomain() {
        return hasSuspiciousSubdomain;
    }

    public void setHasSuspiciousSubdomain(Boolean hasSuspiciousSubdomain) {
        this.hasSuspiciousSubdomain = hasSuspiciousSubdomain;
    }

    public String getSuspiciousSubdomainPattern() {
        return suspiciousSubdomainPattern;
    }

    public void setSuspiciousSubdomainPattern(String suspiciousSubdomainPattern) {
        this.suspiciousSubdomainPattern = suspiciousSubdomainPattern;
    }

    // RDAP domain registration getters/setters
    public Boolean getDomainSuspended() {
        return domainSuspended;
    }

    public void setDomainSuspended(Boolean domainSuspended) {
        this.domainSuspended = domainSuspended;
    }

    public Integer getDaysUntilExpiration() {
        return daysUntilExpiration;
    }

    public void setDaysUntilExpiration(Integer daysUntilExpiration) {
        this.daysUntilExpiration = daysUntilExpiration;
    }

    // New DNS analysis getters/setters
    public Boolean getHasCnameLoop() {
        return hasCnameLoop;
    }

    public void setHasCnameLoop(Boolean hasCnameLoop) {
        this.hasCnameLoop = hasCnameLoop;
    }

    public Integer getNameServerCount() {
        return nameServerCount;
    }

    public void setNameServerCount(Integer nameServerCount) {
        this.nameServerCount = nameServerCount;
    }

    public Boolean getHasValidReverseDns() {
        return hasValidReverseDns;
    }

    public void setHasValidReverseDns(Boolean hasValidReverseDns) {
        this.hasValidReverseDns = hasValidReverseDns;
    }

    public Boolean getHasDmarc() {
        return hasDmarc;
    }

    public void setHasDmarc(Boolean hasDmarc) {
        this.hasDmarc = hasDmarc;
    }

    public Boolean getHasDkim() {
        return hasDkim;
    }

    public void setHasDkim(Boolean hasDkim) {
        this.hasDkim = hasDkim;
    }

    public Integer getDnsResponseTimeMs() {
        return dnsResponseTimeMs;
    }

    public void setDnsResponseTimeMs(Integer dnsResponseTimeMs) {
        this.dnsResponseTimeMs = dnsResponseTimeMs;
    }

}
