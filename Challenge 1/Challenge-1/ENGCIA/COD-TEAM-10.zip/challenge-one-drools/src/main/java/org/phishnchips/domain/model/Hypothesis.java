package org.phishnchips.domain.model;

public class Hypothesis {
    private String description;

    public Hypothesis(String description) {
        super();
        this.description = description;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
