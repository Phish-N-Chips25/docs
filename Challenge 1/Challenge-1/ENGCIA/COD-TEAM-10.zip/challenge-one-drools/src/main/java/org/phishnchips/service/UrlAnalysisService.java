package org.phishnchips.service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.phishnchips.domain.model.Evidences;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.util.regex.Pattern;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.regex.Matcher;

@Service
public class UrlAnalysisService {

    private final String whoisApiKey;

    private static final Pattern IPV4_EXACT = Pattern.compile(
            "^(?:25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)"
                    + "(?:\\.(?:25[0-5]|2[0-4]\\d|1\\d{2}|[1-9]?\\d)){3}$");

    public UrlAnalysisService(@Value("${whois.api.key:}") String whoisApiKey) {
        this.whoisApiKey = whoisApiKey;
    }

    public void analyzeUrl(Evidences evidences) {
        String url = evidences.getUrl();
        if (url == null || url.isEmpty()) {
            return;
        }

        System.out.println("Analyzing URL structure: " + url);

        evidences.setIsIpHost(isIpAddress(url));

        if (!evidences.getIsIpHost()) {
            // Domain age only applies to domain hosts
            // Extract domain from URL before calling RDAP/WHOIS
            String domain = extractDomain(url);
            enrichDomainInfoFromRDAP(domain, evidences, whoisApiKey);

            System.out.println("[URL Analysis] isIpHost=" + evidences.getIsIpHost()
                    + " domainAgeInDays=" + evidences.getDomainAgeInDays()
                    + " domainSuspended=" + evidences.getDomainSuspended()
                    + " daysUntilExpiration=" + evidences.getDaysUntilExpiration()
                    + " isWhiteListedDomain=" + evidences.getIsWhiteListedDomain()
                    + " isWhiteListedIpHost=" + evidences.getisWhiteListedIpHost());
        } else {
            // Mark as not-applicable for IP hosts so rules won't consider domain age
            evidences.setDomainAgeInDays(-1);
            System.out.println("[URL Analysis] IP host detected; skipping domain age lookup");
        }

        // ALWAYS analyze subdomain and path patterns, even for whitelisted domains
        // (phishing can be hosted on Google Sites, etc.)
        analyzeSubdomainPatterns(evidences, url);
        analyzePathPatterns(evidences, url);
    }

    /**
     * Enriches Evidences with domain registration information from RDAP (free) or
     * WhoisXML API (fallback).
     * Extracts: domain age, suspension status, expiration date.
     * 
     * @param domain      The domain to check
     * @param evidences   The Evidences object to populate
     * @param whoisApiKey WhoisXML API key for fallback
     */
    private void enrichDomainInfoFromRDAP(String domain, Evidences evidences, String whoisApiKey) {
        String rootDomain = extractRootDomain(domain);

        // Try RDAP first (free, extracts age + status + expiration)
        if (getDomainInfoFromRDAP(rootDomain, evidences)) {
            return; // Success via RDAP
        }

        // Fallback to WhoisXML API (only gets age)
        System.out.println("[Domain Info] RDAP did not return data, trying WhoisXML API fallback for: " + rootDomain);
        int age = getDomainAgeFromWhoisXML(rootDomain, whoisApiKey);
        evidences.setDomainAgeInDays(age);
    }

    /**
     * Extracts domain registration info from RDAP and populates Evidences.
     * Returns true if successful, false otherwise.
     * 
     * @param domain    The root domain to check
     * @param evidences The Evidences object to populate
     * @return true if RDAP data was successfully retrieved
     */
    private static boolean getDomainInfoFromRDAP(String domain, Evidences evidences) {
        try {
            String urlStr = "https://rdap.org/domain/" + domain;

            URL url = new URL(urlStr);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);

            int responseCode = con.getResponseCode();

            if (responseCode == 404) {
                System.out.println(
                        "[RDAP] Domain not found (404): " + domain + " - likely unregistered or doesn't exist");
                evidences.setDomainAgeInDays(-1);
                return false;
            } else if (responseCode != 200) {
                System.out.println("[RDAP] HTTP " + responseCode + " for domain: " + domain);
                evidences.setDomainAgeInDays(-1);
                return false;
            }

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();

            String json = response.toString();
            boolean foundData = false;

            // 1. Extract registration date (domain age)
            java.util.regex.Pattern regPattern = java.util.regex.Pattern.compile(
                    "\"eventAction\"\\s*:\\s*\"registration\"[^}]*\"eventDate\"\\s*:\\s*\"([^\"]+)\"");
            Matcher regMatcher = regPattern.matcher(json);

            if (regMatcher.find()) {
                String dateStr = regMatcher.group(1);
                String datePart = dateStr.substring(0, 10);
                LocalDate registrationDate = LocalDate.parse(datePart);
                LocalDate now = LocalDate.now();
                long days = ChronoUnit.DAYS.between(registrationDate, now);

                evidences.setDomainAgeInDays((int) days);
                System.out.println("[RDAP] Domain " + domain + " registered " + days + " days ago (" + datePart + ")");
                foundData = true;
            }

            // 2. Extract expiration date
            java.util.regex.Pattern expPattern = java.util.regex.Pattern.compile(
                    "\"eventAction\"\\s*:\\s*\"expiration\"[^}]*\"eventDate\"\\s*:\\s*\"([^\"]+)\"");
            Matcher expMatcher = expPattern.matcher(json);

            if (expMatcher.find()) {
                String dateStr = expMatcher.group(1);
                String datePart = dateStr.substring(0, 10);
                LocalDate expirationDate = LocalDate.parse(datePart);
                LocalDate now = LocalDate.now();
                long daysUntilExp = ChronoUnit.DAYS.between(now, expirationDate);

                evidences.setDaysUntilExpiration((int) daysUntilExp);
                System.out.println(
                        "[RDAP] Domain " + domain + " expires in " + daysUntilExp + " days (" + datePart + ")");
                foundData = true;
            }

            // 3. Extract domain status
            java.util.regex.Pattern statusPattern = java.util.regex.Pattern.compile(
                    "\"status\"\\s*:\\s*\\[([^\\]]+)\\]");
            Matcher statusMatcher = statusPattern.matcher(json);

            if (statusMatcher.find()) {
                String statuses = statusMatcher.group(1).toLowerCase();
                boolean suspended = statuses.contains("hold") ||
                        statuses.contains("redemption") ||
                        statuses.contains("pending delete") ||
                        statuses.contains("suspended");

                evidences.setDomainSuspended(suspended);
                if (suspended) {
                    System.out.println("[RDAP] Domain " + domain + " has suspicious status: " + statuses);
                }
                foundData = true;
            } else {
                evidences.setDomainSuspended(false);
            }

            if (!foundData) {
                System.out.println("[RDAP] No registration data found for domain: " + domain);
                evidences.setDomainAgeInDays(-1);
                return false;
            }

            return true;

        } catch (Exception e) {
            System.out.println("[RDAP] Error for domain " + domain + ": " + e.getMessage());
            evidences.setDomainAgeInDays(-1);
            return false;
        }
    }

    /**
     * Gets domain age in days using RDAP (free, no API key required) with WhoisXML
     * API fallback.
     * 
     * @param domain The domain to check (e.g., "example.com" or "www.example.com")
     * @param apiKey WhoisXML API key for fallback (can be null/empty if only using
     *               RDAP)
     * @return Domain age in days, or -1 if unavailable
     */
    public static int getDomainAgeInDays(String domain, String apiKey) {
        // Extract root domain (RDAP doesn't work with subdomains like www.example.com)
        String rootDomain = extractRootDomain(domain);

        // Try RDAP first (free, no API key needed)
        int rdapAge = getDomainAgeFromRDAP(rootDomain);
        if (rdapAge != -1) {
            return rdapAge;
        }

        // Fallback to WhoisXML API if RDAP fails
        System.out
                .println("[Domain Age] RDAP did not return age data, trying WhoisXML API fallback for: " + rootDomain);
        return getDomainAgeFromWhoisXML(rootDomain, apiKey);
    }

    /**
     * Extracts the root domain from a full domain name, removing any subdomains.
     * Examples:
     * - www.example.com -> example.com
     * - quantgbo.lviv.ua -> lviv.ua
     * - imported-beneficial-magnesium.glitch.me -> glitch.me
     * - sub.domain.example.co.uk -> example.co.uk
     * 
     * @param domain The full domain (may include subdomains)
     * @return The root domain (SLD + TLD)
     */
    private static String extractRootDomain(String domain) {
        if (domain == null || domain.isEmpty()) {
            return domain;
        }

        String normalized = domain.toLowerCase();
        String[] parts = normalized.split("\\.");

        // If only 1 part (like "localhost") or 2 parts (like "example.com"), return
        // as-is
        if (parts.length <= 2) {
            return normalized;
        }

        // Check for common two-part TLDs (co.uk, com.br, etc.)
        String lastPart = parts[parts.length - 1];
        String secondLastPart = parts[parts.length - 2];

        // Common second-level TLDs
        boolean isTwoPartTld = ((lastPart.equals("uk")
                && (secondLastPart.equals("co") || secondLastPart.equals("ac") || secondLastPart.equals("gov"))) ||
                (lastPart.equals("br") && secondLastPart.equals("com")) ||
                (lastPart.equals("au") && (secondLastPart.equals("com") || secondLastPart.equals("gov")
                        || secondLastPart.equals("edu")))
                ||
                (lastPart.equals("jp") && (secondLastPart.equals("co") || secondLastPart.equals("ac"))) ||
                (lastPart.equals("nz") && (secondLastPart.equals("co") || secondLastPart.equals("ac"))) ||
                (lastPart.equals("za") && (secondLastPart.equals("co") || secondLastPart.equals("ac"))));

        if (isTwoPartTld && parts.length >= 3) {
            // Return last 3 parts (SLD + two-part TLD)
            // Example: sub.example.co.uk -> example.co.uk
            return parts[parts.length - 3] + "." + parts[parts.length - 2] + "." + parts[parts.length - 1];
        } else {
            // Return last 2 parts (SLD + TLD)
            // Example: sub.example.com -> example.com
            return parts[parts.length - 2] + "." + parts[parts.length - 1];
        }
    }

    /**
     * Gets domain age using RDAP (Registration Data Access Protocol).
     * RDAP is the modern successor to WHOIS - free, standardized, JSON-based.
     * 
     * @param domain The domain to check
     * @return Domain age in days, or -1 if unavailable
     */
    private static int getDomainAgeFromRDAP(String domain) {
        try {
            // RDAP bootstrap service automatically routes to correct registry
            String urlStr = "https://rdap.org/domain/" + domain;

            URL url = new URL(urlStr);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);

            int responseCode = con.getResponseCode();

            if (responseCode == 404) {
                System.out.println(
                        "[RDAP] Domain not found (404): " + domain + " - likely unregistered or doesn't exist");
                return -1;
            } else if (responseCode != 200) {
                System.out.println("[RDAP] HTTP " + responseCode + " for domain: " + domain);
                return -1;
            }

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();

            // Parse JSON for registration date
            String json = response.toString();

            // Look for "events" array with "registration" action
            // Example: {"eventAction":"registration","eventDate":"2015-03-12T18:44:32Z"}
            java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(
                    "\"eventAction\"\\s*:\\s*\"registration\"[^}]*\"eventDate\"\\s*:\\s*\"([^\"]+)\"");
            Matcher matcher = pattern.matcher(json);

            if (matcher.find()) {
                String dateStr = matcher.group(1);
                // Extract just the date portion (YYYY-MM-DD) from ISO 8601 format
                String datePart = dateStr.substring(0, 10);
                LocalDate registrationDate = LocalDate.parse(datePart);
                LocalDate now = LocalDate.now();
                long days = ChronoUnit.DAYS.between(registrationDate, now);

                System.out.println("[RDAP] Domain " + domain + " registered " + days + " days ago (" + datePart + ")");
                return (int) days;
            } else {
                System.out.println("[RDAP] No registration event found for domain: " + domain);
                return -1;
            }

        } catch (Exception e) {
            System.out.println("[RDAP] Error for domain " + domain + ": " + e.getMessage());
            return -1;
        }
    }

    /**
     * Gets domain age using WhoisXML API (requires API key and quota).
     * This is the fallback method when RDAP fails.
     * 
     * @param domain The domain to check
     * @param apiKey WhoisXML API key
     * @return Domain age in days, or -1 if unavailable
     */
    private static int getDomainAgeFromWhoisXML(String domain, String apiKey) {
        try {
            if (apiKey == null || apiKey.isBlank()) {
                System.err.println("[WHOIS API] Skipping lookup - API key not configured (set WHOIS_API_KEY env var)");
                return -1;
            }
            String urlStr = "https://www.whoisxmlapi.com/whoisserver/WhoisService?"
                    + "apiKey=" + apiKey
                    + "&domainName=" + domain
                    + "&outputFormat=JSON";

            URL url = new URL(urlStr);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("GET");

            int responseCode = con.getResponseCode();

            // Handle API errors gracefully
            if (responseCode == 401) {
                System.err.println(
                        "[WHOIS API] 401 Unauthorized - API key may be expired or invalid for domain: " + domain);
                return -1;
            } else if (responseCode == 403) {
                System.err.println("[WHOIS API] 403 Forbidden - Access denied for domain: " + domain);
                return -1;
            } else if (responseCode == 429) {
                System.err.println("[WHOIS API] 429 Too Many Requests - Rate limit exceeded for domain: " + domain);
                return -1;
            } else if (responseCode != 200) {
                System.err.println("[WHOIS API] HTTP " + responseCode + " error for domain: " + domain);
                return -1;
            }

            BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;
            while ((line = in.readLine()) != null) {
                response.append(line);
            }
            in.close();

            JsonObject json = JsonParser.parseString(response.toString()).getAsJsonObject();
            JsonObject whoisRecord = json.getAsJsonObject("WhoisRecord");

            if (whoisRecord == null || !whoisRecord.has("registryData")) {
                System.out.println("[WHOIS API] No WHOIS data found for domain: " + domain);
                return -1;
            }

            JsonObject registryData = whoisRecord.getAsJsonObject("registryData");

            boolean isActive = true;
            if (registryData.has("status")) {
                String status = registryData.get("status").getAsString().toLowerCase();

                if (status.contains("redemption") || status.contains("pendingdelete") || status.contains("expired")) {
                    isActive = false;
                }
            }

            if (!isActive) {
                return -1;
            }

            if (!registryData.has("createdDate")) {
                return -1;
            }

            String createdDateStr = registryData.get("createdDate").getAsString();
            Date creationDate = null;

            String[] dateFormats = {
                    "yyyy-MM-dd'T'HH:mm:ss'Z'", // padrão ISO
                    "yyyy-MM-dd HH:mm:ss", // sem o 'T'
                    "dd/MM/yyyy HH:mm:ss", // formato europeu
                    "yyyy/MM/dd HH:mm:ss", // formato alternativo
                    "yyyy-MM-dd" // só a data
            };

            for (String format : dateFormats) {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat(format);
                    sdf.setLenient(false);
                    creationDate = sdf.parse(createdDateStr);
                    break;
                } catch (ParseException ignored) {
                }
            }

            assert creationDate != null;
            long diffMs = new Date().getTime() - creationDate.getTime();

            return (int) (diffMs / (1000 * 60 * 60 * 24));

        } catch (Exception e) {
            // WHOIS API unavailable or invalid key - silently return unknown age
            System.out.println("[WHOIS] API unavailable for domain: " + domain + " (continuing without age data)");
            return -1;
        }
    }

    private boolean isIpAddress(String urlString) {
        try {
            URL url = new URL(urlString);
            String host = url.getHost();

            if (host.startsWith("[") && host.endsWith("]")) {
                host = host.substring(1, host.length() - 1);
            }

            return IPV4_EXACT.matcher(host).matches();

        } catch (MalformedURLException e) {
            return false;
        }
    }

    /**
     * Extracts just the domain name from a full URL.
     * E.g., "http://example.com/path" -> "example.com"
     */
    private String extractDomain(String urlString) {
        try {
            URL url = new URL(urlString);
            return url.getHost();
        } catch (MalformedURLException e) {
            // If parsing fails, return the original string
            return urlString;
        }
    }

    /**
     * Analyzes URL path and parameters for suspicious patterns using statistical
     * heuristics
     * Uses entropy, segment analysis, and structural anomalies
     */
    private void analyzePathPatterns(Evidences evidences, String urlString) {
        try {
            URL url = new URL(urlString);
            String path = url.getPath();
            String query = url.getQuery();

            if (path == null || path.isEmpty() || path.equals("/")) {
                return;
            }

            // Calculate entropy of full path
            double pathEntropy = calculateEntropy(path);

            // Segment analysis
            String[] segments = path.split("/");
            int nonEmptySegments = 0;
            int totalLength = 0;
            int alphaOnly = 0;
            int numericOnly = 0;
            int mixed = 0;

            for (String seg : segments) {
                if (seg != null && !seg.trim().isEmpty()) {
                    nonEmptySegments++;
                    totalLength += seg.length();

                    if (seg.matches("[a-zA-Z]+"))
                        alphaOnly++;
                    else if (seg.matches("\\d+"))
                        numericOnly++;
                    else if (seg.matches(".*[a-zA-Z].*") && seg.matches(".*\\d.*"))
                        mixed++;
                }
            }

            double avgLength = nonEmptySegments > 0 ? (double) totalLength / nonEmptySegments : 0;

            // STATISTICAL ANOMALY 1: High entropy (randomness/obfuscation)
            // BUT: Exclude legitimate hyphenated slugs (e.g., /user-name/article-title)
            // High entropy alone is insufficient; require EITHER:
            // - Very high entropy (>4.3) indicating true randomness, OR
            // - Moderate entropy (3.8-4.3) + structural indicators (short tokens, numeric
            // mix, no alpha-only)
            boolean highEntropyWithStructuralAnomaly = false;
            if (pathEntropy > 4.3) {
                // Clearly random/obfuscated path
                highEntropyWithStructuralAnomaly = true;
            } else if (pathEntropy > 3.8) {
                // Moderate entropy - check for structural anomalies to avoid false positives
                // Legitimate paths like /user-name/article-title have high entropy but good
                // structure
                // (longer average tokens, some alpha-only segments)
                if (avgLength < 6 || (alphaOnly == 0 && nonEmptySegments >= 2)) {
                    // Short average segment length OR no pure-alpha segments = likely obfuscated
                    highEntropyWithStructuralAnomaly = true;
                }
            }

            if (highEntropyWithStructuralAnomaly) {
                evidences.setHasSuspiciousPath(Boolean.TRUE);
                evidences.setSuspiciousPathPattern(String.format("high_entropy_%.2f", pathEntropy));
                System.out.printf(
                        "[Path] High entropy + structural anomaly detected: %.2f (avgLen=%.1f, alphaOnly=%d)%n",
                        pathEntropy, avgLength, alphaOnly);
            }
            // STATISTICAL ANOMALY 2: Path with very short segments (minimal semantic value)
            // Normal: /products/ (avg 8), /contact/ (avg 7)
            // Suspicious: /img/rank/ (avg 3.5), /a/b/c/ (avg 1)
            else if (nonEmptySegments >= 2 && avgLength < 5) {
                evidences.setHasSuspiciousPath(Boolean.TRUE);
                evidences
                        .setSuspiciousPathPattern(
                                String.format("short_segments_d%d_avg%.1f", nonEmptySegments, avgLength));
                System.out.printf("[Path] Anomaly: depth=%d, avg length=%.1f%n", nonEmptySegments, avgLength);
            }
            // STATISTICAL ANOMALY 3: All segments are mixed alphanumeric (no semantic names)
            else if (nonEmptySegments >= 2 && mixed >= 2 && alphaOnly == 0) {
                evidences.setHasSuspiciousPath(Boolean.TRUE);
                evidences.setSuspiciousPathPattern("all_mixed_alphanumeric");
                System.out.printf("[Path] All segments mixed alphanumeric%n");
            }
            // STATISTICAL ANOMALY 4: Multiple numeric-only segments (unusual)
            else if (numericOnly >= 2 && alphaOnly == 0) {
                evidences.setHasSuspiciousPath(Boolean.TRUE);
                evidences.setSuspiciousPathPattern("multiple_numeric_only");
                System.out.printf("[Path] Multiple numeric-only segments%n");
            }

            // QUERY PARAMETER STATISTICAL ANALYSIS
            if (query != null && !query.isEmpty()) {
                // Calculate query string entropy
                double queryEntropy = calculateEntropy(query);

                // PARAMETER ANOMALY 1: High entropy in query string (obfuscation/random tokens)
                if (queryEntropy > 3.8) {
                    evidences.setHasObfuscatedParams(Boolean.TRUE);
                    System.out.printf("[Query] High entropy detected: %.2f%n", queryEntropy);
                }
                // PARAMETER ANOMALY 2: Abnormally long query string (>200 chars)
                else if (query.length() > 200) {
                    evidences.setHasObfuscatedParams(Boolean.TRUE);
                    System.out.println("[Query] Abnormally long: " + query.length() + " chars");
                }
                // PARAMETER ANOMALY 3: Multiple URL encoding layers (e.g., %25 = encoded %)
                else if (query.matches(".*%[0-9A-Fa-f]{2}.*%[0-9A-Fa-f]{2}.*%[0-9A-Fa-f]{2}.*")) {
                    evidences.setHasObfuscatedParams(Boolean.TRUE);
                    System.out.println("[Query] Multiple URL encoding detected");
                }
                // PARAMETER ANOMALY 4: Analyze individual parameter values
                else {
                    String[] params = query.split("&");
                    for (String param : params) {
                        String[] parts = param.split("=", 2);
                        String value = parts.length == 2 ? parts[1] : parts[0]; // Handle bare params (no =)

                        // Very long single parameter value (>50 chars)
                        if (value.length() > 50) {
                            double valueEntropy = calculateEntropy(value);

                            // High entropy long value = obfuscation
                            if (valueEntropy > 3.5) {
                                evidences.setHasObfuscatedParams(Boolean.TRUE);
                                System.out.printf("[Query] High entropy parameter value: %.2f (length=%d)%n",
                                        valueEntropy, value.length());
                                break;
                            }

                            // Mixed alphanumeric without clear pattern
                            if (value.matches(".*[a-zA-Z].*") && value.matches(".*\\d.*") &&
                                    !value.matches(".*[\\s_\\-].*")) { // No separators
                                evidences.setHasObfuscatedParams(Boolean.TRUE);
                                System.out.println("[Query] Mixed alphanumeric parameter (no separators)");
                                break;
                            }
                        }
                    }
                }
            }

            if (evidences.getHasSuspiciousPath() == null) {
                evidences.setHasSuspiciousPath(Boolean.FALSE);
            }
            if (evidences.getHasObfuscatedParams() == null) {
                evidences.setHasObfuscatedParams(Boolean.FALSE);
            }

        } catch (MalformedURLException e) {
            // If URL parsing fails, mark as false
            evidences.setHasSuspiciousPath(Boolean.FALSE);
            evidences.setHasObfuscatedParams(Boolean.FALSE);
        }
    }

    /**
     * Analyze host/subdomain structure using statistical heuristics (no blacklists)
     * Flags anomalous subdomains such as:
     * - high entropy labels (random-looking)
     * - long chains of hyphenated tokens (e.g., profile-viewer-socialmedia)
     * - high numeric ratio mixed with letters
     */
    private void analyzeSubdomainPatterns(Evidences evidences, String urlString) {
        try {
            URL url = new URL(urlString);
            String host = url.getHost();
            if (host == null || host.isEmpty()) {
                return;
            }

            String normalizedHost = host.toLowerCase();
            if (normalizedHost.startsWith("www.")) {
                normalizedHost = normalizedHost.substring(4);
            }

            String[] labels = normalizedHost.split("\\.");
            if (labels.length == 0)
                return;

            // Compute entropy for the full host and for the subdomain part if present
            double hostEntropy = calculateEntropy(normalizedHost);

            // Extract subdomain part (all labels except last two), if available
            String subdomainPart = "";
            if (labels.length >= 3) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < labels.length - 2; i++) {
                    if (i > 0)
                        sb.append('.');
                    sb.append(labels[i]);
                }
                subdomainPart = sb.toString();
            }

            // Heuristic A: High entropy host (likely randomized)
            if (hostEntropy > 3.8) {
                evidences.setHasSuspiciousSubdomain(Boolean.TRUE);
                evidences.setSuspiciousSubdomainPattern(String.format("high_entropy_host_%.2f", hostEntropy));
                System.out.printf("[Subdomain] High entropy host: %.2f (%s)%n", hostEntropy, normalizedHost);
                return;
            }

            // If no subdomain part, nothing else to analyze here
            if (subdomainPart.isEmpty()) {
                evidences.setHasSuspiciousSubdomain(Boolean.FALSE);
                return;
            }

            // Tokenize subdomain on hyphens and dots (keep hyphen analysis focused on subdomain)
            String[] hyphenTokens = subdomainPart.split("-");
            int tokenCount = 0;
            int totalTokenLen = 0;
            // Track distribution characteristics if needed in the future
            for (String t : hyphenTokens) {
                if (t == null || t.isBlank())
                    continue;
                tokenCount++;
                totalTokenLen += t.length();
                // Presence-only checks handled later by numeric ratio
            }
            double avgTokenLen = tokenCount > 0 ? (double) totalTokenLen / tokenCount : 0.0;

            // Heuristic B: Long chain of short hyphenated tokens (marketing-looking subdomain chains)
            if (tokenCount >= 3 && avgTokenLen > 2.0 && avgTokenLen <= 8.0) {
                evidences.setHasSuspiciousSubdomain(Boolean.TRUE);
                evidences.setSuspiciousSubdomainPattern(
                        String.format("hyphen_chain_n%d_avg%.1f", tokenCount, avgTokenLen));
                System.out.printf("[Subdomain] Hyphen chain anomaly: tokens=%d avg=%.1f (%s)%n", tokenCount,
                        avgTokenLen, subdomainPart);
                return;
            }

            // Heuristic C: High numeric ratio in subdomain mixed with letters
            int alphaNumChars = 0;
            int digitChars = 0;
            for (char c : subdomainPart.toCharArray()) {
                if (Character.isLetterOrDigit(c)) {
                    alphaNumChars++;
                    if (Character.isDigit(c))
                        digitChars++;
                }
            }
            double numericRatio = alphaNumChars > 0 ? (double) digitChars / alphaNumChars : 0.0;
            if (numericRatio > 0.3 && subdomainPart.matches(".*[A-Za-z].*")) {
                evidences.setHasSuspiciousSubdomain(Boolean.TRUE);
                evidences.setSuspiciousSubdomainPattern(String.format("high_numeric_ratio_%.2f", numericRatio));
                System.out.printf("[Subdomain] High numeric ratio: %.2f (%s)%n", numericRatio, subdomainPart);
                return;
            }

            // Default if no anomaly
            evidences.setHasSuspiciousSubdomain(Boolean.FALSE);

        } catch (MalformedURLException e) {
            evidences.setHasSuspiciousSubdomain(Boolean.FALSE);
        }
    }

    /**
     * Calculates Shannon entropy of a string (measure of randomness)
     * Higher values = more random/obfuscated
     * Normal words: 2.5-3.5, Random strings: 3.8+
     */
    private double calculateEntropy(String s) {
        if (s == null || s.isEmpty())
            return 0.0;

        int[] counts = new int[256];
        for (char c : s.toCharArray()) {
            if (c < 256)
                counts[c]++;
        }

        double entropy = 0.0;
        int length = s.length();
        for (int count : counts) {
            if (count > 0) {
                double p = (double) count / length;
                entropy -= p * (Math.log(p) / Math.log(2));
            }
        }
        return entropy;
    }

}
