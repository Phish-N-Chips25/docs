from pyswip import Prolog
from services.dns_facts_integration import DNSFactsIntegration
from services.dns_service import DNSService
import json
import sys

url = sys.argv[1] if len(sys.argv) > 1 else 'https://www.zeus-alarm.at/'

p = Prolog()
integ = DNSFactsIntegration(p, DNSService(timeout=5.0))
res = integ.assert_dns_facts(url)
print('assert success:', res['success'])
q = list(p.query(f"dns_email_auth_count('{url}', V)."))
print('prolog fact:', q)
