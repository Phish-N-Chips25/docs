# Prolog Phishing Detection Rules - Complete Score & Trigger Summary

**Source:** `backend/engine/prolog/kb_rules.pl`
**Total Rules:** 62 active rules (Rules 201, 601-604, 621 removed; DOM rules 700-708 added)

---

## Rule Categories & Scoring Summary

### Quick Score Reference

- **High (100-149 points):** 6 rules
- **Medium (50-99 points):** 19 rules
- **Low (20-49 points):** 33 rules
- **Negative scores:** 2 rules (whitelist, trusted destination)
- **Zero-score (classification):** 4 rules

---

## REPUTATION & TRUST RULES (100-199)

### Rule 100: Whitelist ✓

- **Score:** -500 points (strong trust signal)
- **Trigger:** `url_whitelisted(Url, 1)`
- **Condition:** URL matches trusted domain whitelist
- **Purpose:** Reduce false positives for known legitimate sites

---

## URL STRUCTURE RULES (200-299)

### Rule 200: IP Address Detection ✓

- **Score:** 70 points
- **Trigger:** `is_ip_address(Url, 1)`
- **Condition:** URL uses raw IP address instead of domain name
- **Example:** `http://192.168.1.1/login`

### Rule 202: @ Character in URL ✓

- **Score:** 30 points
- **Trigger:** `has_at(Url, 1)`
- **Condition:** '@' character present (excluding legitimate `/@username/` patterns)
- **Excludes:** `^https?://[^/]+/@[^@]*$` (GitHub, Medium, Twitter profiles)
- **Examples:**
  - **Flagged:** `http://admin@phishing.com`, `http://bank.com@attacker.com`
  - **Safe:** `https://github.com/@octocat`, `https://medium.com/@author`

### Rule 203: Obfuscated/Encoded Parameters ✓

- **Score:** 35 points (updated from 15)
- **Trigger:** `url_has_obfuscated_params(Url, 1)`
- **Condition:** Multiple URL encoding layers OR very long base64-like values
- **Note:** Changed from `encoded_param_count > 0` to boolean flag (Drools alignment)
- **Implementation:** ⚠️ Python extractor TODO

### Rule 204: Suspicious Opaque Blob

- **Score:** 20 points
- **Trigger:** `url_suspicious_blob(Url, 1)`
- **Condition:** Long base64/base64url-like tokens in query (40+ chars)
- **Example:** `?data=YWJjZGVmZ2hpamtsbW5vcHFyc3R1dnd4eXoxMjM0NTY3ODkw`

---

## CLASSIFICATION THRESHOLDS (300-399)

### Rule 300: Safe Threshold

- **Score:** 0 points (classification only)
- **Trigger:** `score_URL(Url, <, 150)`
- **Purpose:** Mark as non-confirmed phishing

### Rule 301: Phishing Threshold

- **Score:** 0 points (classification only)
- **Trigger:** `score_URL(Url, >=, 150)`
- **Purpose:** Mark as confirmed phishing

---

## DOMAIN LEXICAL ANALYSIS RULES (400-499)

### Rule 401: Long Domain Name

- **Score:** 50 points
- **Trigger:** `dns_domain_length(Url, >, 30)`
- **Condition:** Domain name exceeds 30 characters
- **Example:** `very-long-suspicious-domain-name-here.com`

### Rule 402: Excessive Subdomains

- **Score:** 35 points
- **Trigger:** `dns_subdomain_count(Url, >=, 3)`
- **Condition:** 3 or more subdomain levels
- **Example:** `login.secure.bank.attacker.com`

### Rule 403: Excessive Subdomains + Deep Path

- **Score:** 60 points
- **Triggers:** `dns_subdomain_count(Url, >=, 2)` AND `dns_path_depth(Url, >=, 4)`
- **Condition:** Multiple subdomains combined with deep path structure
- **Note:** Requires both conditions

### Rule 404: High Numeric Ratio

- **Score:** 20 points
- **Trigger:** `dns_numeric_ratio(Url, >, 0.3)`
- **Condition:** >30% of domain characters are numbers
- **Example:** `paypa1-verify123.com`

### Rule 405: Excessive Hyphens

- **Score:** 20 points
- **Trigger:** `dns_hyphen_count(Url, >, 2)`
- **Condition:** More than 2 hyphens in domain
- **Example:** `secure-bank-login-verify.com`

### Rule 406: IDN Punycode

- **Score:** 40 points
- **Trigger:** `dns_idn_punycode(Url, 1)`
- **Condition:** Internationalized domain using punycode (homograph attack)
- **Example:** `xn--80akhbyknj4f.com` (Cyrillic characters)

### Rule 407: Credential Tokens in Domain

- **Score:** 50 points
- **Triggers:** `dns_credential_tokens(Url, >, 0)` (with other conditions)
- **Condition:** Domain contains keywords like "login", "signin", "account", "verify"
- **Example:** `login-verify-account.com`

### Rule 408: Deep Path

- **Score:** 15 points
- **Trigger:** `dns_path_depth(Url, >=, 6)`
- **Condition:** URL path has 6 or more segments
- **Example:** `site.com/a/b/c/d/e/f/page.html`

### Rule 409: Domain Listed in DNSBL

- **Score:** 200 points ⚠️ CRITICAL
- **Trigger:** `domain_dnsbl_listed(Url, 1)`
- **Condition:** Domain found in DNS-based blocklists (SURBL, Spamhaus DBL)
- **Purpose:** Real-time threat intelligence integration
- **Note:** Not in Drools - intentional Prolog extension

### Rule 410: Leet Substitutions

- **Score:** 25 points
- **Trigger:** `leet_substitution_count(Url, >, 0)`
- **Condition:** Leet-speak character substitutions (0→o, 1→l, 3→e, @→a, $→s)
- **Example:** `g00g1e.com`, `payp@l.com`

### Rule 411: Confusable Unicode Characters

- **Score:** 60 points
- **Trigger:** `confusable_char_count(Url, >=, 1)`
- **Condition:** Non-ASCII confusable characters in domain
- **Example:** `раураl.com` (Cyrillic 'а' looks like Latin 'a')

### Rule 412: Misleading Host Pattern

- **Score:** 20 points
- **Trigger:** `misleading_host_pattern(Url, 1)`
- **Condition:** Brand-like subdomain before attacker domain
- **Example:** `login.secure.attacker.com`

### Rule 413: Suspicious Path Pattern

- **Score:** 55 points
- **Trigger:** `url_suspicious_path(Url, 1)`
- **Condition:** Path matches phishing patterns: `/wp-content/uploads/`, `/login/`, `/verify/`, `/validation/`, etc.
- **Example:** `sketchy-site.com/wp-content/uploads/verify.html`

### Rule 414: Very Long URL (Corroborated) - Variant A

- **Score:** 25 points
- **Triggers:** `comprimentoUrl(Url, >, 75)` AND `encoded_param_count(Url, >, 0)`
- **Condition:** Long URL + encoded parameters
- **Note:** Requires corroboration (not just length alone)

### Rule 415: Suspicious Subdomain (Statistical)

- **Score:** 50 points
- **Trigger:** `dns_suspicious_subdomain(Url, 1)`
- **Condition:** Statistical anomalies in subdomain (high entropy, unusual patterns)
- **Example:** `x7k3-v9m2-q4p8.attacker.com`

### Rule 416: Domain Suspended/Redemption

- **Score:** 95 points
- **Trigger:** `dns_domain_suspended(Url, 1)`
- **Condition:** Domain status: suspended, hold, redemption, or pending deletion
- **Purpose:** Catches compromised/abandoned domains

### Rule 417: Domain Expiring Soon

- **Score:** 60 points
- **Trigger:** `dns_days_until_expiration(Url, <, 90)`
- **Condition:** Domain expires in less than 90 days
- **Purpose:** Temporary/disposable domain detection

### Rule 418: Very Long URL (Corroborated) - Variant B

- **Score:** 25 points
- **Triggers:** `comprimentoUrl(Url, >, 75)` AND `url_suspicious_path(Url, 1)`
- **Condition:** Long URL + suspicious path pattern

### Rule 419: Very Long URL (Corroborated) - Variant C

- **Score:** 25 points
- **Triggers:** `comprimentoUrl(Url, >, 75)` AND `dns_subdomain_count(Url, >=, 2)`
- **Condition:** Long URL + multiple subdomains

### Rule 420: Very Long URL (Corroborated) - Variant D

- **Score:** 25 points
- **Triggers:** `comprimentoUrl(Url, >, 75)` AND `dns_domain_age_days(Url, <, 365)`
- **Condition:** Long URL + young domain (<1 year)

---

## DNS INFRASTRUCTURE RULES (500-599)

### Rule 500: No DNS A/AAAA Records

- **Score:** 80 points
- **Trigger:** `dns_a_record_exists(Url, 0)`
- **Condition:** Domain does not resolve to any IP address
- **Purpose:** Non-existent or misconfigured domain

### Rule 501: Very Low TTL

- **Score:** 45 points
- **Trigger:** `dns_min_ttl(Url, <, 60)`
- **Condition:** DNS TTL < 60 seconds (fast-flux indicator)
- **Purpose:** Detects rapidly changing DNS (evasive hosting)

### Rule 502: Long CNAME Chain

- **Score:** 35 points
- **Trigger:** `dns_cname_chain_length(Url, >=, 3)`
- **Condition:** 3+ CNAME indirections
- **Purpose:** DNS redirection/cloaking technique

### Rule 503: No MX and No SPF

- **Score:** 30 points
- **Triggers:** `dns_mx_exists(Url, 0)` AND `dns_spf_dmarc(Url, 0)`
- **Condition:** Missing both MX and SPF records
- **Purpose:** Disposable/throwaway domain detection

### Rule 505: Young Domain + Credential Tokens

- **Score:** 120 points
- **Triggers:** `dns_domain_age_days(Url, <, 1095)` AND `dns_credential_tokens(Url, >, 0)`
- **Condition:** Domain <3 years old + credential keywords
- **Purpose:** New phishing site with suspicious naming

### Rule 512: Very New Domain (<3 Years)

### Rule 512: Very New Domain (<1 Year)

- **Score:** 55 points
- **Trigger:** `dns_domain_age_days(Url, <, 365)`
- **Condition:** Domain registered less than 1 year ago
- **Note:** ⚠️ Drools also has <30 days threshold (not yet in Prolog)

### Rule 513: CNAME Loop

- **Score:** 50 points
- **Trigger:** `dns_cname_loop(Url, 1)`
- **Condition:** Circular CNAME reference detected
- **Purpose:** DNS misconfiguration or evasion tactic

### Rule 514: Single Nameserver

- **Score:** 40 points
- **Trigger:** `dns_nameserver_count(Url, 1)`
- **Condition:** Only one authoritative nameserver
- **Purpose:** Weak infrastructure/lack of redundancy

### Rule 515: No Reverse DNS

- **Score:** 35 points
- **Trigger:** `dns_reverse_dns_exists(Url, 0)`
- **Condition:** Missing PTR records (no reverse DNS mapping)
- **Purpose:** Poor infrastructure hygiene

### Rule 516: No Email Authentication

- **Score:** 55 points
- **Trigger:** `dns_email_auth_count(Url, 0)`
- **Condition:** No SPF, DMARC, or DKIM records
- **Purpose:** Complete absence of email security

### Rule 517: Partial Email Authentication ✓

- **Score:** 20 points
- **Trigger:** `dns_email_auth_count(Url, 1)`
- **Condition:** Only 1 of 3 email auth mechanisms (SPF/DMARC/DKIM)
- **Purpose:** Incomplete email security setup

### Rule 518: Slow DNS Response

- **Score:** 25 points
- **Trigger:** `dns_response_time_seconds(Url, >, 2.0)`
- **Condition:** DNS query takes >2 seconds
- **Purpose:** DNS performance/availability issue

---

## HTTP BEHAVIOR RULES (600-699)

### Rule 600: HTTP Without TLS ⚠️

- **Score:** 50 points
- **Trigger:** `http_scheme(Url, 1)`
- **Condition:** Using HTTP instead of HTTPS
- **Purpose:** Insecure connection (no encryption)
- **Note:** Not in Drools - intentional Prolog extension

### ~~Rules 601-604: URL Unreachable~~ ❌ REMOVED

- **Status:** Removed for Drools alignment
- **Reason:** Drools doesn't analyze URL reachability
- **Impact:** Reduces false positives from network issues

### Rule 605: Reachable via Redirect

- **Score:** 10 points
- **Triggers:** `url_reachability(Url, reachable)` AND `url_reachability_reason(Url, redirect)`
- **Condition:** URL responds with 3xx redirect
- **Purpose:** Flag potential obfuscation

### Rule 606: Redirect Chain (Excessive) ✓ ⚠️ UPDATED

- **Score:** 45 points (updated from 150)
- **Trigger:** `redirect_chain_hops(Url, >, 3)`
- **Condition:** More than 3 redirects
- **Drools alignment:** "REDIRECT: Excessive redirect count"

### Rule 607: Redirect Chain (Very Excessive) ✓ ⚠️ UPDATED

- **Score:** 70 points (updated from 250)
- **Trigger:** `redirect_chain_hops(Url, >, 5)`
- **Condition:** More than 5 redirects (changed from ≥5)
- **Drools alignment:** "REDIRECT: Very excessive redirect count"

### Rule 608: High Domain Diversity

- **Score:** 100 points
- **Trigger:** `redirect_diversity_ratio(Url, >=, 0.6)`
- **Condition:** ≥60% of redirect chain uses different domains
- **Purpose:** Cross-domain evasion technique

### Rule 609: URL Shorteners in Chain

- **Score:** 45 points
- **Trigger:** `redirect_shortener_count(Url, >=, 1)`
- **Condition:** At least 1 URL shortener detected
- **Examples:** bit.ly, tinyurl.com, t.co, goo.gl

### Rule 610: Multiple URL Shorteners

- **Score:** 100 points
- **Trigger:** `redirect_shortener_count(Url, >=, 2)`
- **Condition:** 2+ URL shorteners in chain
- **Purpose:** Excessive obfuscation

### Rule 611: Untrusted Redirect (with Excessive Hops) - Variant A

- **Score:** 55 points
- **Triggers:** `redirect_untrusted_domain(Url, 1)` AND `redirect_chain_hops(Url, >, 3)`
- **Condition:** Untrusted domain + excessive redirects

### Rule 612: Open Redirect Pattern

- **Score:** 65 points
- **Trigger:** `redirect_open_redirect(Url, 1)`
- **Condition:** Open redirect parameters: `?redirect=`, `?goto=`, `?url=`, `?next=`
- **Purpose:** Abused legitimate redirects

### Rule 613: Obfuscated URL in Chain

- **Score:** 60 points
- **Trigger:** `redirect_obfuscated_url(Url, 1)`
- **Condition:** Hex/URL encoding in redirect chain
- **Purpose:** Encoded/hidden destination

### Rule 614: Broken Redirect Chain

- **Score:** 40 points
- **Trigger:** `redirect_chain_broken(Url, 1)`
- **Condition:** Redirect loop or error in chain
- **Purpose:** Misconfigured or malicious redirect

### Rule 615: Multiple Suspicious Redirect Indicators - Variant A

- **Score:** 100 points
- **Triggers:** `redirect_chain_hops(Url, >, 3)` AND `redirect_untrusted_domain(Url, 1)`
- **Condition:** Excessive redirects + untrusted domain

### Rule 616: Shortener with Additional Redirects

- **Score:** 55 points
- **Triggers:** `redirect_shortener_count(Url, >=, 1)` AND `redirect_chain_hops(Url, >, 1)`
- **Condition:** URL shortener + more redirects

### Rule 617: Shortener with Open Redirect

- **Score:** 85 points
- **Triggers:** `redirect_shortener_count(Url, >=, 1)` AND `redirect_open_redirect(Url, 1)`
- **Condition:** URL shortener + open redirect pattern

### Rule 618: Trusted Final Destination

- **Score:** -40 points (reduces risk)
- **Trigger:** `final_destination_trusted(Url, 1)`
- **Condition:** Redirects to trusted domain (Google, Microsoft, Amazon)
- **Purpose:** Legitimate redirect services

### Rule 619: Final Destination Very New

- **Score:** 90 points
- **Trigger:** `final_destination_age_days(Url, <, 180)`
- **Condition:** Final destination domain <180 days old
- **Purpose:** New final destination after redirects

### Rule 620: Final Destination <1 Year

- **Score:** 50 points
- **Triggers:** `final_destination_age_days(Url, >=, 180)` AND `final_destination_age_days(Url, <, 365)`
- **Condition:** Final destination 180-365 days old

### ~~Rule 621: Final Destination >1 Year~~ ❌ REMOVED

- **Status:** Removed - not a risk indicator
- **Reason:** Established domains (>1 year) don't indicate phishing risk

### Rule 622: TLS Certificate Error

- **Score:** 70 points
- **Trigger:** `http_tls_certificate_error(Url, 1)`
- **Condition:** Invalid, expired, or self-signed SSL certificate
- **Purpose:** HTTPS security issue

### Rule 623: Untrusted Redirect + Open Redirect - Variant B

- **Score:** 55 points (same as 611)
- **Triggers:** `redirect_untrusted_domain(Url, 1)` AND `redirect_open_redirect(Url, 1)`
- **Condition:** Untrusted domain + open redirect

### Rule 624: Untrusted Redirect + Obfuscated - Variant C

- **Score:** 55 points (same as 611)
- **Triggers:** `redirect_untrusted_domain(Url, 1)` AND `redirect_obfuscated_url(Url, 1)`
- **Condition:** Untrusted domain + obfuscated URL

### Rule 625: Untrusted Redirect + Very New Destination - Variant D

- **Score:** 55 points (same as 611)
- **Triggers:** `redirect_untrusted_domain(Url, 1)` AND `final_destination_age_days(Url, <, 180)`
- **Condition:** Untrusted domain + new final destination

### Rule 626: Multiple Indicators + Open Redirect - Variant B

- **Score:** 100 points (same as 615)
- **Triggers:** `redirect_chain_hops(Url, >, 3)` AND `redirect_open_redirect(Url, 1)`
- **Condition:** Excessive redirects + open redirect

### Rule 627: Multiple Indicators + Obfuscated - Variant C

- **Score:** 100 points (same as 615)
- **Triggers:** `redirect_chain_hops(Url, >, 3)` AND `redirect_obfuscated_url(Url, 1)`
- **Condition:** Excessive redirects + obfuscated URL

---

## DOM ANALYSIS RULES (700-799)

### Rule 700: Sensitive Input Fields Detected

- **Score:** 60 points
- **Trigger:** `sensitive_fields_present(Url, Count)` where Count ≥ 2
- **Condition:** 2+ sensitive input fields (password, email, credit card, SSN, phone)
- **Purpose:** Credential/PII harvesting detection
- **Example:** Login form with email + password fields

### Rule 701: Password Field Present

- **Score:** 40 points
- **Trigger:** `password_field_present(Url, 1)`
- **Condition:** Password input field detected in DOM
- **Purpose:** Credential harvesting indicator
- **Note:** Often legitimate, but combined with other signals increases risk

### Rule 702: External Form Actions

- **Score:** 25 points
- **Trigger:** `external_form_actions(Url, Count)` where Count ≥ 1
- **Condition:** HTML forms submitting to external/different domains
- **Purpose:** Data exfiltration to attacker-controlled servers
- **Example:** `<form action="http://attacker.com/collect.php">`

### Rule 703: External or Null Links

- **Score:** 20 points
- **Trigger:** `external_or_null_links(Url, Count)` where Count ≥ 5
- **Condition:** 5+ links pointing to external domains or `href="#"`/`href="javascript:void(0)"`
- **Purpose:** Detects scaffolding sites or excessive external linking
- **Note:** Fake UI with non-functional links

### Rule 704: External Media/Scripts

- **Score:** 35 points
- **Trigger:** `external_media(Url, Count)` where Count ≥ 3
- **Condition:** 3+ external resources (images, scripts, iframes from different domains)
- **Purpose:** Resource loading from suspicious CDNs or mixed content
- **Example:** Legitimate-looking page pulling assets from attacker infrastructure

### Rule 705: High DOM Entropy

- **Score:** 30 points
- **Trigger:** `dom_entropy(Url, Entropy)` where Entropy > 4.5
- **Condition:** High randomness in DOM text content (Shannon entropy > 4.5)
- **Purpose:** Obfuscated/encoded content detection
- **Note:** Legitimate compression may trigger; corroborate with other signals

### Rule 706: Title Obfuscation

- **Score:** 40 points
- **Trigger:** `title_obfuscated(Url, 1)`
- **Condition:** Page title contains excessive special chars, numbers, or is very short/empty
- **Purpose:** Detects auto-generated or obfuscated titles
- **Example:** `<title>x7k3...</title>` or `<title>***</title>`

### Rule 707: Suspicious Link/Feature Ratio

- **Score:** 25 points
- **Trigger:** `link_feature_ratio(Url, Ratio)` where Ratio > 10.0
- **Condition:** Very high ratio of links to input fields (>10:1)
- **Purpose:** Scaffolding or link-heavy pages with minimal functionality
- **Note:** Many links but few interactive elements suggests fake UI

### Rule 708: Critical DOM Combination ⚠️

- **Score:** 90 points
- **Triggers:** `password_field_present(Url, 1)` AND `external_form_actions(Url, ≥1)` AND `external_or_null_links(Url, ≥3)`
- **Condition:** Password field + external form submission + multiple suspicious links
- **Purpose:** High-confidence phishing page detection
- **Note:** Combines multiple strong indicators of credential harvesting

---

## SCORE THRESHOLDS & CLASSIFICATION

### Risk Level Mapping (Python Layer)

```
LEGITIMATE (safe):      score < 60
SUSPICIOUS:             60 ≤ score < 100
PROBABLE PHISHING:      100 ≤ score < 150
PHISHING (confirmed):   score ≥ 150
```

### Prolog Conclusions (Rules 300-301)

- `phishingNaoConfirmado`: score < 150
- `phishingConfirmado`: score ≥ 150

---

## HIGH-IMPACT RULES (Top 10 by Score)

1. **Rule 409:** Domain DNSBL Listed - **200 points**
2. **Rule 505:** Young Domain + Credentials - **120 points**
3. **Rule 608:** High Domain Diversity - **100 points**
4. **Rule 610:** Multiple URL Shorteners - **100 points**
5. **Rule 615/626/627:** Multiple Redirect Indicators - **100 points**
6. **Rule 416:** Domain Suspended - **95 points**
7. **Rule 619:** Final Destination Very New - **90 points**
8. **Rule 708:** Critical DOM Combination - **90 points**
9. **Rule 617:** Shortener with Open Redirect - **85 points**
10. **Rule 500:** No DNS A/AAAA Records - **80 points**

---

## NEGATIVE SCORE RULES (Risk Reducers)

1. **Rule 100:** Whitelist - **-500 points**
2. **Rule 618:** Trusted Final Destination - **-40 points**

---

## FACT EXTRACTORS MAPPING

### Python-Based Extractors (Asserted by rule_engine.py)

- `has_at/2` - Rule 202 ✓
- `encoded_param_count/2` - Rules 414, 418, 419, 420
- `url_suspicious_blob/2` - Rule 204
- `leet_substitution_count/2` - Rule 410
- `confusable_char_count/2` - Rule 411
- `misleading_host_pattern/2` - Rule 412
- `domain_dnsbl_listed/2` - Rule 409
- `redirect_*` facts - Rules 606-627
- `final_destination_*` facts - Rules 618-621
- `url_suspicious_path/2` - Rule 413
- `http_tls_certificate_error/2` - Rule 622
- `url_has_obfuscated_params/2` - Rule 203 ⚠️ TODO

### DNS Service Extractors (dns_facts_integration.py)

- `dns_a_record_exists/2` - Rule 500
- `dns_min_ttl/2` - Rule 501
- `dns_cname_chain_length/2` - Rule 502
- `dns_mx_exists/2` - Rule 503
- `dns_spf_dmarc/2` - Rule 503
- `dns_cname_loop/2` - Rule 513
- `dns_nameserver_count/2` - Rule 514
- `dns_reverse_dns_exists/2` - Rule 515
- `dns_email_auth_count/2` - Rules 516, 517
- `dns_response_time_seconds/2` - Rule 518

### DOM Analyzer Extractors (dom_analyzer.py)

- `sensitive_fields_present/2` - Rule 700
- `password_field_present/2` - Rules 701, 708
- `external_form_actions/2` - Rules 702, 708
- `external_or_null_links/2` - Rules 703, 708
- `external_media/2` - Rule 704
- `dom_entropy/2` - Rule 705
- `title_obfuscated/2` - Rule 706
- `link_feature_ratio/2` - Rule 707
- `dependent_request_ratio/2` - (Future use)

### Prolog-Based Extractors (kb_facts/\*.pl)

- `is_ip_address/2` - Rule 200
- `comprimentoUrl/2` - Rules 414, 418, 419, 420
- `dns_domain_length/2` - Rule 401
- `dns_subdomain_count/2` - Rules 402, 403, 419
- `dns_numeric_ratio/2` - Rule 404
- `dns_hyphen_count/2` - Rule 405
- `dns_idn_punycode/2` - Rule 406
- `dns_suspicious_subdomain/2` - Rule 415
- `dns_domain_suspended/2` - Rule 416
- `dns_days_until_expiration/2` - Rule 417
- `dns_domain_age_days/2` - Rules 505, 420, 512
- `http_scheme/2` - Rule 600

---

### ✅ Completed

1. **Rule 201 REMOVED** - Simplified URL length (no corroboration)
2. **Rule 202 UPDATED** - Added `/@username/` pattern exclusion
3. **Rule 203 UPDATED** - Changed to boolean flag, score 15→35
4. **Rules 601-604 REMOVED** - URL unreachability (not in Drools)
5. **Rule 606 UPDATED** - Threshold >2→>3, score 150→45
6. **Rule 607 UPDATED** - Operator ≥5→>5, score 250→70
7. **Rule 517 FIXED** - Email auth count logic corrected
8. **Rule 621 REMOVED** - Final destination >1 year not a risk indicator

### ✅ Score Normalization (November 2025)

1. **Rule 401:** 150→50 points (long domain)
2. **Rule 403:** 150→60 points (subdomains + deep path)
3. **Rule 409:** 400→200 points (DNSBL listed)
4. **Rule 411:** 40→60 points (confusable unicode)
5. **Rule 505:** 250→120 points (young domain + credentials)
6. **Rule 512:** 90→55 points, threshold 1095→365 days (<1 year)
7. **Rule 600:** 100→50 points (HTTP without TLS)
8. **Rule 608:** 200→100 points (domain diversity)
9. **Rule 610:** 180→100 points (multiple shorteners)
10. **Rule 622:** 90→70 points (TLS certificate error)

### ✅ DOM Analysis Integration

1. **Rules 700-708 ADDED** - DOM-based phishing detection
2. **New analyzer:** `backend/engine/dom_analyzer.py` (requests + BeautifulSoup)
3. **Engine integration:** `rule_engine.py` asserts 9 DOM facts before Prolog inference
4. **Explanation system:** `motorInferencia.pl` updated with DOM fact handlers
5. **Feature coverage:** Sensitive fields, password harvesting, external forms, suspicious links, media loading, content obfuscation, DOM structure analysis

---

## NOTES

- **Total possible negative score:** -540 points (whitelist + trusted destination)
- **Maximum single rule score:** 200 points (DNSBL - normalized from 400)
- **Most common score range:** 20-60 points (balanced distribution)
- **Rules with variants:** 414-420 (long URL), 611/623-625 (untrusted redirect), 615/626-627 (multiple indicators)
- **Intentional Prolog extensions:** Rules 409 (DNSBL), 600 (HTTP without TLS), 700-708 (DOM analysis)
- **Score normalization rationale:** Prevent single-rule dominance, maintain relative risk weighting across categories
- **DOM analysis approach:** Lightweight (requests + BeautifulSoup) for broad compatibility; Playwright upgrade optional for dynamic content

---

**End of Summary**
