"""
API Integration Test - Tests the complete inference engine through FastAPI endpoint

Tests end-to-end functionality with real phishing URLs from threat intelligence feeds.
Requires the API server to be running (uvicorn backend.api.main:app --reload)

Usage:
    cd backend/tests
    python test_api.py [--fetch-fresh]
"""
import urllib.request
import urllib.parse
import json
import os
import sys


def fetch_fresh_phishing_urls():
    """Fetch fresh phishing URLs from OpenPhish."""
    print("\nFetching fresh phishing URLs from OpenPhish...")
    try:
        url = "https://openphish.com/feed.txt"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        
        with urllib.request.urlopen(req, timeout=10) as response:
            content = response.read().decode('utf-8')
            urls = [line.strip() for line in content.split('\n') if line.strip()]
            valid_urls = [u for u in urls[:5] if u.startswith(('http://', 'https://'))]
            
            print(f"[OK] Fetched {len(valid_urls)} fresh phishing URLs\n")
            return valid_urls
    except Exception as e:
        print(f"[ERROR] Failed to fetch URLs: {e}")
        return []


def get_test_urls(fetch_fresh=False):
    """Get test URLs from various sources."""
    
    # Legitimate URLs (should score low/safe)
    legitimate = [
        "https://github.com",
        "https://www.google.com",
    ]
    
    # Synthetic suspicious URLs (for feature testing)
    synthetic = [
        "http://192.168.1.1/login",  # IP address
        "https://phishing.xyz/account/verify",  # Suspicious TLD
        "https://login.secure.account.verify.example.tk/reset",  # Multiple subdomains + suspicious TLD
        "https://dbltest.com",  # Spamhaus DNSBL test domain
    ]
    
    # Real phishing URLs
    real_phishing = []
    
    if fetch_fresh:
        real_phishing = fetch_fresh_phishing_urls()
    else:
        # Try loading from cached file first (one level up from tests/)
        urls_file = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'test_urls.json'))
        if os.path.exists(urls_file):
            try:
                with open(urls_file, 'r', encoding='utf-8') as f:
                    urls_data = json.load(f)
                real_phishing = urls_data['urls'].get('real_phishing', [])[:3]
                print(f"[OK] Loaded {len(real_phishing)} cached phishing URLs\n")
            except Exception as e:
                print(f"[WARNING] Could not load cached URLs: {e}")
    
    return {
        'legitimate': legitimate,
        'synthetic': synthetic,
        'real_phishing': real_phishing
    }


def test_api():
    """Test the FastAPI endpoint with various URL categories."""
    
    print("=" * 80)
    print("API INTEGRATION TEST - PHISHING DETECTION ENGINE")
    print("=" * 80)
    
    # Check for --fetch-fresh flag
    fetch_fresh = '--fetch-fresh' in sys.argv
    
    # Get test URLs
    test_data = get_test_urls(fetch_fresh)
    
    # Combine all URLs for testing
    all_urls = (
        test_data['legitimate'] + 
        test_data['synthetic'] + 
        test_data['real_phishing']
    )
    
    print(f"Testing {len(all_urls)} URLs:")
    print(f"  - Legitimate: {len(test_data['legitimate'])}")
    print(f"  - Synthetic Suspicious: {len(test_data['synthetic'])}")
    print(f"  - Real Phishing: {len(test_data['real_phishing'])}")
    print("\n" + "=" * 80)
    
    results_summary = {
        'safe': 0,
        'suspicious': 0,
        'probable_phishing': 0,
        'phishing': 0,
        'errors': 0
    }
    
    for url in all_urls:
        print(f"\nTesting: {url}")
        try:
            api_url = f"http://localhost:8000/analyze-url?url={urllib.parse.quote(url)}"
            req = urllib.request.Request(api_url, method='POST')
            
            with urllib.request.urlopen(req, timeout=15) as response:
                data = json.loads(response.read().decode('utf-8'))
                
                risk_level = data.get('risk_level', 'unknown').upper()
                risk_score = data.get('risk_score', 0)
                rules_count = len(data.get('results', []))
                
                print(f"  Status: {response.status}")
                print(f"  Risk Level: {risk_level}")
                print(f"  Risk Score: {risk_score}")
                print(f"  Rules Triggered: {rules_count}")
                
                # Update summary
                if risk_level == 'SAFE':
                    results_summary['safe'] += 1
                elif risk_level == 'SUSPICIOUS':
                    results_summary['suspicious'] += 1
                elif risk_level == 'PROBABLE_PHISHING':
                    results_summary['probable_phishing'] += 1
                elif risk_level == 'PHISHING':
                    results_summary['phishing'] += 1
                
                # Show triggered rules
                if data.get('results'):
                    print(f"  Triggered Rules:")
                    for rule in data['results']:
                        print(f"    - {rule['rule_name']}: {rule['score']} pts")
                        if rule.get('details'):
                            print(f"      {rule['details']}")
                else:
                    print(f"  [WARNING] No rules triggered!")
                
        except urllib.error.URLError as e:
            print(f"  [ERROR] API unavailable: {e}")
            print(f"\n  To start the API server, run:")
            print(f"    uvicorn backend.api.main:app --reload")
            results_summary['errors'] += 1
            break
        except Exception as e:
            print(f"  [ERROR] {e}")
            results_summary['errors'] += 1
    
    # Print summary
    print("\n" + "=" * 80)
    print("TEST SUMMARY")
    print("=" * 80)
    print(f"Total URLs Tested: {len(all_urls)}")
    print(f"  SAFE:               {results_summary['safe']}")
    print(f"  SUSPICIOUS:         {results_summary['suspicious']}")
    print(f"  PROBABLE_PHISHING:  {results_summary['probable_phishing']}")
    print(f"  PHISHING:           {results_summary['phishing']}")
    print(f"  ERRORS:     {results_summary['errors']}")
    print("=" * 80)
    
    return results_summary['errors'] == 0


if __name__ == "__main__":
    success = test_api()
    sys.exit(0 if success else 1)
