% Domain length fact
:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.
:- use_module(common_utils, [extract_host/2, is_ip/1, extract_domain_without_tld/2]).

feature_extractor(dns_domain_length_check).

dns_domain_length_check(URL) :-
    ultimo_facto(N), ultima_caracteristica(C),
    retract(ultima_caracteristica(_)), C1 is C + 1, asserta(ultima_caracteristica(C1)),
    retract(ultimo_facto(_)), N1 is N + 1, asserta(ultimo_facto(N1)),
    (   extract_host(URL, Host), \+ is_ip(Host), extract_domain_without_tld(Host, Domain), string_length(Domain, Length)
    ->  assertz(facto(N1, dns_domain_length(URL, Length)))
    ;   assertz(facto(N1, dns_domain_length(URL, 0)))
    ).
