% redirect_shortener_fact.pl
% Extractor for URL shortener usage in redirect chain

facto_redirect_shortener_count(Url, Count) :-
    redirect_shortener_count(Url, Count).
