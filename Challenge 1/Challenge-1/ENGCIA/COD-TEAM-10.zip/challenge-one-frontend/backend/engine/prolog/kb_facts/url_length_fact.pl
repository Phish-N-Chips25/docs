% URL length fact extractor
:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.

feature_extractor(url_length).

url_length(URL) :-
    string_length(URL, Length),
    ultimo_facto(N),
    ultima_caracteristica(C),
    retract(ultima_caracteristica(_)),
    C1 is C + 1,
    asserta(ultima_caracteristica(C1)),
    retract(ultimo_facto(_)),
    N1 is N + 1,
    assertz(facto(N1, comprimentoUrl(URL, Length))),
    asserta(ultimo_facto(N1)).
