% Hyphen count fact
:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.
:- use_module(common_utils, [extract_host/2, count_hyphens/2]).

feature_extractor(dns_hyphen_check).

dns_hyphen_check(URL) :-
    ultimo_facto(N), ultima_caracteristica(C),
    retract(ultima_caracteristica(_)), C1 is C + 1, asserta(ultima_caracteristica(C1)),
    retract(ultimo_facto(_)), N1 is N + 1, asserta(ultimo_facto(N1)),
    (   extract_host(URL, Host), count_hyphens(Host, HyphenCount)
    ->  assertz(facto(N1, dns_hyphen_count(URL, HyphenCount)))
    ;   assertz(facto(N1, dns_hyphen_count(URL, 0)))
    ).
