% DNS Utilities - Shared helper predicates for DNS fact extraction
% This file contains common utilities used by multiple DNS fact files

% Extract domain from URL
% extract_domain_from_url(+URL, -Domain)
extract_domain_from_url(URL, Domain) :-
    atom_string(URL, URLStr),
    (   sub_string(URLStr, _, _, _, "://")
    ->  split_string(URLStr, "/", "", [_, _, HostPath | _]),
        split_string(HostPath, "/", "", [Host | _]),
        atom_string(Domain, Host)
    ;   extract_domain_from_path(URL, Domain)
    ).

% Extract domain from path (fallback)
% extract_domain_from_path(+URL, -Domain)
extract_domain_from_path(URL, Domain) :-
    atom_string(URL, URLStr),
    split_string(URLStr, "/", "", [Host | _]),
    atom_string(Domain, Host).
