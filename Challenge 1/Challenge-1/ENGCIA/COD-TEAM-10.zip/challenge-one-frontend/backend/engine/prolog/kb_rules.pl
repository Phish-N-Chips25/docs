% ============================================================================
% DNS PHISHING DETECTION RULES - CONSOLIDATED
% ============================================================================
% All DSL-based rules for phishing detection in a single organized file
% Rules use custom DSL operators: regra, se, entao, e, nao
% ============================================================================

% Multifile declarations (populated throughout this file)
:- multifile regra/1.
:- multifile facto_dispara_regras/2.
:- multifile caracteristicas_regras/3.

% ============================================================================
% FACT-TO-RULE MAPPINGS
% ============================================================================
% Maps facts to the rule IDs they trigger

% Reputation and trust (100s)
facto_dispara_regras(url_whitelisted(_,_), [100]).

% URL structure analysis (200s)
facto_dispara_regras(is_ip_address(_,_), [200]).
facto_dispara_regras(comprimentoUrl(_, _), [414, 418, 419, 420]).
facto_dispara_regras(has_at(_,_), [202]).
facto_dispara_regras(url_has_obfuscated_params(_,_), [203]).
facto_dispara_regras(url_suspicious_blob(_,_), [204]).

% Classification thresholds (300s)
facto_dispara_regras(score_URL(_,_), [300, 301]).

% Domain lexical analysis (400s)
facto_dispara_regras(dns_domain_length(_,_), [401]).
facto_dispara_regras(dns_subdomain_count(_,_), [402, 403, 419]).
facto_dispara_regras(dns_numeric_ratio(_,_), [404]).
facto_dispara_regras(dns_hyphen_count(_,_), [405]).
facto_dispara_regras(dns_idn_punycode(_,_), [406]).
facto_dispara_regras(domain_dnsbl_listed(_,_), [409]).
facto_dispara_regras(leet_substitution_count(_,_), [410]).
facto_dispara_regras(confusable_char_count(_,_), [411]).
facto_dispara_regras(misleading_host_pattern(_,_), [412]).
% Added URL/host advanced patterns
facto_dispara_regras(url_suspicious_path(_,_), [413]).
facto_dispara_regras(dns_suspicious_subdomain(_,_), [415]).
facto_dispara_regras(dns_domain_suspended(_,_), [416]).
facto_dispara_regras(dns_days_until_expiration(_,_), [417]).

% DNS infrastructure (500s)
facto_dispara_regras(dns_a_record_exists(_,_), [500]).
facto_dispara_regras(dns_min_ttl(_,_), [501]).
facto_dispara_regras(dns_cname_chain_length(_,_), [502]).
facto_dispara_regras(dns_mx_exists(_,_), [503]).
facto_dispara_regras(dns_spf_dmarc(_,_), [503]).
facto_dispara_regras(dns_domain_age_days(_,_), [505, 420, 512]).
facto_dispara_regras(dns_cname_loop(_,_), [513]).
facto_dispara_regras(dns_nameserver_count(_,_), [514]).
facto_dispara_regras(dns_reverse_dns_exists(_,_), [515]).
facto_dispara_regras(dns_email_auth_count(_,_), [516, 517]).
facto_dispara_regras(dns_response_time_seconds(_,_), [518]).

% HTTP behavior (600s)
facto_dispara_regras(http_scheme(_,_), [600]).
% Removed: facto_dispara_regras(url_reachability(_,_), [601]) - not in Drools
facto_dispara_regras(url_reachability_reason(_,_), [605]).
facto_dispara_regras(url_reachability_status(_,_), [605]).
facto_dispara_regras(redirect_chain_hops(_,_), [606, 607, 611, 615, 626, 627]).
facto_dispara_regras(redirect_diversity_ratio(_,_), [608]).
facto_dispara_regras(redirect_shortener_count(_,_), [609, 610]).
% Added Redirect/HTTP advanced indicators
facto_dispara_regras(redirect_untrusted_domain(_,_), [611, 615, 623, 624, 625]).
facto_dispara_regras(redirect_open_redirect(_,_), [612, 615, 617, 623, 626]).
facto_dispara_regras(redirect_obfuscated_url(_,_), [613, 615, 624, 627]).
facto_dispara_regras(redirect_chain_broken(_,_), [614]).
facto_dispara_regras(final_destination_trusted(_,_), [618]).
facto_dispara_regras(final_destination_age_days(_,_), [619, 620, 625]).
facto_dispara_regras(http_tls_certificate_error(_,_), [622]).

% DOM analysis (700s)
facto_dispara_regras(sensitive_fields_present(_,_), [700]).
facto_dispara_regras(password_field_present(_,_), [701, 708]).
facto_dispara_regras(external_form_actions(_,_), [702, 708]).
facto_dispara_regras(external_or_null_links(_,_), [703, 708]).
facto_dispara_regras(external_media(_,_), [704]).
facto_dispara_regras(dom_entropy(_,_), [705]).
facto_dispara_regras(title_obfuscated(_,_), [706]).
facto_dispara_regras(link_feature_ratio(_,_), [707, 708]).
facto_dispara_regras(dependent_request_ratio(_,_), [707]).

% Future/placeholder
facto_dispara_regras(dns_credential_tokens(_,_), [407, 505]).
facto_dispara_regras(dns_path_depth(_,_), [403, 408]).

% ============================================================================
% RULE CHARACTERISTICS (ID, NAME, SCORE)
% ============================================================================
% Defines rule metadata: rule ID, descriptive name, and phishing score
% Organized by theme and execution order

% ============================================================================
% REPUTATION AND TRUST RULES (100-199)
% ============================================================================

caracteristicas_regras(100, whitelist, -500).

% ============================================================================
% URL STRUCTURE RULES (200-299)
% ============================================================================

caracteristicas_regras(200, url_presenca_de_ip, 70).
caracteristicas_regras(202, url_at_char, 30).
caracteristicas_regras(203, parametros_codificados, 35).
caracteristicas_regras(204, blob_opaco_suspeito, 20).

% ============================================================================
% CLASSIFICATION THRESHOLDS (300-399)
% ============================================================================

caracteristicas_regras(300, safe_threshold, 0).
caracteristicas_regras(301, phishing_threshold, 0).

% ============================================================================
% DOMAIN LEXICAL ANALYSIS RULES (400-499)
% ============================================================================

caracteristicas_regras(401, dominio_comprido, 50).
caracteristicas_regras(402, excesso_subdominios, 35).
caracteristicas_regras(403, excesso_subdominios_path, 60).
caracteristicas_regras(404, muitos_numeros, 20).
caracteristicas_regras(405, muitos_hifens, 20).
caracteristicas_regras(406, idn_punycode, 40).
caracteristicas_regras(407, tokens_credenciais, 50).
caracteristicas_regras(408, path_profundo, 15).
caracteristicas_regras(409, dominio_dnsbl, 150).
caracteristicas_regras(410, leet_substituicoes, 25).
caracteristicas_regras(411, unicode_confundivel, 60).
caracteristicas_regras(412, padrao_host_enganoso, 20).
caracteristicas_regras(413, padrao_caminho_suspeito, 55).
caracteristicas_regras(414, url_muito_longa_corroborada, 25).
caracteristicas_regras(415, subdominio_suspeito_estatistico, 50).
caracteristicas_regras(416, dominio_suspenso_ou_redencao, 95).
caracteristicas_regras(417, dominio_expira_breve, 60).

% ============================================================================
% DNS INFRASTRUCTURE RULES (500-599)
% ============================================================================

caracteristicas_regras(500, sem_dns_records, 80).
caracteristicas_regras(501, ttl_muito_baixo, 45).
caracteristicas_regras(502, cadeia_cname_longa, 35).
caracteristicas_regras(503, sem_mx_spf, 30).
caracteristicas_regras(505, dominio_jovem_credenciais, 120).
caracteristicas_regras(512, dominio_muito_novo_3_anos, 75).
caracteristicas_regras(513, loop_cname, 50).
caracteristicas_regras(514, nameserver_unico, 40).
caracteristicas_regras(515, sem_reverse_dns, 35).
caracteristicas_regras(516, sem_autenticacao_email, 55).
caracteristicas_regras(517, autenticacao_email_parcial, 20).
caracteristicas_regras(518, resposta_dns_lenta, 25).

% ============================================================================
% HTTP BEHAVIOR RULES (600-699)
% ============================================================================

caracteristicas_regras(600, http_sem_tls, 30).
% Rules 601-604 removed - not in Drools
caracteristicas_regras(605, url_atingivel_redirect, 10).
caracteristicas_regras(606, cadeia_redirecionamento, 45).
caracteristicas_regras(607, cadeia_redirecionamento_profunda, 70).
caracteristicas_regras(608, diversidade_dominios_redirect, 90).
caracteristicas_regras(609, encurtadores_em_cadeia, 45).
caracteristicas_regras(610, multiplos_encurtadores, 100).
caracteristicas_regras(611, redirect_dominios_nao_confiaveis, 55).
caracteristicas_regras(612, redirect_aberto_parametro, 65).
caracteristicas_regras(613, redirect_url_ofuscada, 60).
caracteristicas_regras(614, cadeia_redirect_quebrada, 40).
caracteristicas_regras(615, multiplos_indicadores_redirect, 100).
caracteristicas_regras(616, encurtador_com_redirects, 55).
caracteristicas_regras(617, encurtador_com_redirect_aberto, 85).
caracteristicas_regras(618, destino_final_confiavel, -40).
caracteristicas_regras(619, destino_final_muito_novo, 90).
caracteristicas_regras(620, destino_final_menos_um_ano, 50).
caracteristicas_regras(622, erro_certificado_tls, 70).

% ============================================================================
% DOM ANALYSIS RULES (700-709)
% ============================================================================

caracteristicas_regras(700, domCamposSensiveis, 60).
caracteristicas_regras(701, domSenhaPresente, 40).
caracteristicas_regras(702, domFormActionExterna, 25).
caracteristicas_regras(703, domMuitosLinksExternos, 20).
caracteristicas_regras(704, domMidiaExterna, 35).
caracteristicas_regras(705, domEntropiaAlta, 30).
caracteristicas_regras(706, domTituloOfuscado, 40).
caracteristicas_regras(707, domLinksSuspeitos, 25).
caracteristicas_regras(708, domMultiplosIndicadores, 90).

% ============================================================================
% REPUTATION AND TRUST RULES (100-199)
% ============================================================================

% ============================================================================
% RULE 100: WHITELIST
% ============================================================================
% Trusted domains receive negative score (reduces overall risk)
% Score: -500 points (strong trust indicator)

regra 100
	se [avalia(url_whitelisted(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, dominioConfiavel))].

% (Blacklist rule removed per policy)

% ============================================================================
% URL STRUCTURE RULES (200-299)
% ============================================================================

% ============================================================================
% RULE 200: IP ADDRESS DETECTION
% ============================================================================
% Detects URLs using IP addresses instead of domain names
% Score: 70 points (high risk indicator)

regra 200
	se [avalia(is_ip_address(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, temIp))].

% ============================================================================
% RULE 202: @ CHARACTER IN URL
% ============================================================================
% Detects presence of '@' character in URL (excluding legitimate /@username/ patterns)
% Score: 30 points (minor indicator)
% Note: Drools excludes pattern ^https?://[^/]+/@[^@]*$ (e.g., github.com/@user)
%       This requires pattern matching in Python fact extractor

regra 202
	se [avalia(has_at(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, possuiArroba))].

% ============================================================================
% RULE 203: OBFUSCATED OR ENCODED PARAMETERS
% ============================================================================
% Detects obfuscated or excessively encoded URL parameters
% (multiple URL encoding, very long base64-like values)
% Score: 35 points (medium indicator)
% Note: Drools checks hasObfuscatedParams boolean flag

regra 203
	se [avalia(url_has_obfuscated_params(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, parametrosCodificados))].

% ============================================================================
% CLASSIFICATION THRESHOLDS (300-399)
% ============================================================================

% ============================================================================
% RULE 300: SAFE/INTERMEDIATE/PHISHING THRESHOLDS
% ============================================================================
% RISK SCORE CLASSIFICATION
% ============================================================================
% LEGITIMATE (safe):      score < 60
% SUSPICIOUS:             60 <= score < 100
% PROBABLE PHISHING:     100 <= score < 150
% PHISHING (confirmed):   score >= 150
% Note:
% - Prolog asserts only two conclusion facts for explanation: 
%   conclusao(Url, phishingNaoConfirmado) when score < 150 and
%   conclusao(Url, phishingConfirmado) when score >= 150.
% - The Python layer maps the numeric score into the four public labels above.
% - These rules add classification facts only; they do not change the score.

% For scores below the phishing threshold, mark as not-confirmed phishing
regra 300
	se [avalia(score_URL(Url,<,150))]
	entao [cria_facto(conclusao(Url, phishingNaoConfirmado))].

% For scores at or above the phishing threshold, mark as confirmed phishing
regra 301
	se [avalia(score_URL(Url,>=,150))]
	entao [cria_facto(conclusao(Url, phishingConfirmado))].

% ============================================================================
% DOMAIN LEXICAL ANALYSIS RULES (400-499)
% ============================================================================

% ============================================================================
% RULE 401: LONG DOMAIN NAME
% ============================================================================
% Detects excessively long domain names (> 30 characters)
% Score: 150 points (moderate risk indicator)

regra 401
	se [avalia(dns_domain_length(Url, >, 30))]
	entao [cria_facto(caracteristicas(Url, dominioComprido))].

% ============================================================================
% RULE 402: EXCESSIVE SUBDOMAINS
% ============================================================================
% Detects URLs with too many subdomains (>= 3)
% Score: 35 points (moderate risk indicator)

regra 402
	se [avalia(dns_subdomain_count(Url, >=, 3))]
	entao [cria_facto(caracteristicas(Url, excessoSubdominios))].

% ============================================================================
% RULE 404: HIGH NUMERIC RATIO
% ============================================================================
% Detects domains with high percentage of numbers (> 30%)
% Score: 20 points (low-moderate risk indicator)

regra 404
	se [avalia(dns_numeric_ratio(Url, >, 0.3))]
	entao [cria_facto(caracteristicas(Url, muitosNumeros))].

% ============================================================================
% RULE 405: EXCESSIVE HYPHENS
% ============================================================================
% Detects domains with too many hyphens (> 2)
% Score: 20 points (low-moderate risk indicator)

regra 405
	se [avalia(dns_hyphen_count(Url, >, 2))]
	entao [cria_facto(caracteristicas(Url, muitosHifens))].

% ============================================================================
% RULE 406: IDN PUNYCODE
% ============================================================================
% Detects Internationalized Domain Names using punycode
% Score: 40 points (moderate risk - homograph attacks)

regra 406
	se [avalia(dns_idn_punycode(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, idnPunycode))].

% ============================================================================
% RULE 408: DEEP PATH
% ============================================================================
% Detects deep URL paths with many segments (>= 6)
% Score: 15 points (medium indicator)
% Note: Requires dns_path_depth/2 fact

regra 408
	se [avalia(dns_path_depth(Url, >=, 6))]
	entao [cria_facto(caracteristicas(Url, caminhoProfundo))].

% ============================================================================
% RULE 409: DOMAIN LISTED IN DNSBL
% ============================================================================
% Detects domains listed in DNS-based blocklists (SURBL, Spamhaus DBL)
% Score: 400 points (very high risk - real-time threat intelligence)

regra 409
	se [avalia(domain_dnsbl_listed(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, dominioDnsbl))].

% ============================================================================
% RULE 410: LEET/CHARACTER SUBSTITUTIONS IN DOMAIN
% ============================================================================
% Detects leet substitutions in domain labels (e.g., 0->o, 1->l/i)
% Score: 25 points (medium-high indicator)

regra 410
	se [avalia(leet_substitution_count(Url, >, 0))]
	entao [cria_facto(caracteristicas(Url, substituicoesLeet))].

% ============================================================================
% RULE 411: CONFUSABLE UNICODE IN DOMAIN
% ============================================================================
% Detects presence of non-ASCII confusable Unicode characters in domain
% Score: 30 points (high indicator for homograph attacks)

regra 411
	se [avalia(confusable_char_count(Url, >=, 1))]
	entao [cria_facto(caracteristicas(Url, unicodeConfundivel))].

% ============================================================================
% RULE 412: MISLEADING HOST PATTERN
% ============================================================================
% Detects brand-like subdomain before attacker domain (e.g., login.secure.*)
% Score: 20 points (medium-high indicator)

regra 412
	se [avalia(misleading_host_pattern(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, padraoHostEnganoso))].

% ============================================================================
% RULE 413: SUSPICIOUS PATH PATTERN
% ============================================================================
% Detects suspicious URL path patterns (/wp-content/uploads/, /validation/, /login/, /verify/, ...)
% Score: 0 for now (alignment only)

regra 413
	se [avalia(url_suspicious_path(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, caminhoSuspeito))].

% ============================================================================
% RULE 414: VERY LONG URL WITH CORROBORATION
% ============================================================================
% Applies only when long URL is corroborated by other signals (encoded params, suspicious path, many subdomains, or young domain)
% Score: 0 for now (alignment only)

% Variant A: corroborated by encoded params
regra 414
	se [avalia(comprimentoUrl(Url, >, 75)) e avalia(encoded_param_count(Url, >, 0))]
	entao [cria_facto(caracteristicas(Url, urlMuitoLongaCorroborada))].

% ============================================================================
% RULE 415: SUSPICIOUS SUBDOMAIN PATTERN (STATISTICAL)
% ============================================================================
% Detects statistical anomalies in subdomain structure (entropy, hyphen/digit ratios)
% Score: 0 for now (alignment only)

regra 415
	se [avalia(dns_suspicious_subdomain(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, subdominioSuspeitoEstatistico))].

% ============================================================================
% RULE 416: DOMAIN SUSPENDED / REDEMPTION
% ============================================================================
% Detects domains in suspension, hold, redemption, or pending deletion

regra 416
	se [avalia(dns_domain_suspended(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, dominioSuspenso))].

% ============================================================================
% RULE 417: DOMAIN EXPIRING SOON (< 90 DAYS)
% ============================================================================

regra 417
	se [avalia(dns_days_until_expiration(Url, <, 90))]
	entao [cria_facto(caracteristicas(Url, dominioExpiraBreve))].

% Variant B: corroborated by suspicious path
regra 418
	se [avalia(comprimentoUrl(Url, >, 75)) e avalia(url_suspicious_path(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, urlMuitoLongaCorroborada))].

% Variant C: corroborated by many subdomains
regra 419
	se [avalia(comprimentoUrl(Url, >, 75)) e avalia(dns_subdomain_count(Url, >=, 2))]
	entao [cria_facto(caracteristicas(Url, urlMuitoLongaCorroborada))].

% Variant D: corroborated by young domain (< 3 years)
regra 420
	se [avalia(comprimentoUrl(Url, >, 75)) e avalia(dns_domain_age_days(Url, <, 1095))]
	entao [cria_facto(caracteristicas(Url, urlMuitoLongaCorroborada))].

% ============================================================================
% DNS INFRASTRUCTURE RULES (500-599)
% ============================================================================

% ============================================================================
% RULE 500: NO DNS A/AAAA RECORDS
% ============================================================================
% Detects domains that do not resolve to any IP address
% Score: 80 points (high risk - domain does not exist)

regra 500
	se [avalia(dns_a_record_exists(Url, ==, 0))]
	entao [cria_facto(caracteristicas(Url, semDnsRecords))].

% ============================================================================
% RULE 501: VERY LOW TTL
% ============================================================================
% Detects very short DNS TTL values (fast-flux indicator)
% Score: 45 points (moderate risk - evasive hosting)

regra 501
	se [avalia(dns_min_ttl(Url, <, 60))]
	entao [cria_facto(caracteristicas(Url, ttlMuitoBaixo))].

% ============================================================================
% RULE 502: LONG CNAME CHAIN
% ============================================================================
% Detects multiple CNAME indirections (redirection/cloaking)
% Score: 35 points (low-moderate risk - obfuscation technique)

regra 502
	se [avalia(dns_cname_chain_length(Url, >=, 3))]
	entao [cria_facto(caracteristicas(Url, cadeiaCnameLonga))].

% ============================================================================
% RULE 503: NO MX AND NO SPF
% ============================================================================
% Detects domains without MX and SPF records (disposable domains)
% Score: 30 points (low risk - often throwaway domains)

regra 503
	se [avalia(dns_mx_exists(Url, ==, 0)), avalia(dns_spf_dmarc(Url, ==, 0))]
	entao [cria_facto(caracteristicas(Url, semMxSpf))].

% ============================================================================
% RULE 512: DOMAIN LESS THAN 3 YEAR OLD
% ============================================================================
% Detects relatively new domains (< 3 year / 1095 days)
% Score: 55 points (moderate risk indicator)

regra 512
	se [avalia(dns_domain_age_days(Url, <, 1095))]
	entao [cria_facto(caracteristicas(Url, dominioMuitoNovo3Anos))].

% ============================================================================
% RULE 513: CNAME LOOP DETECTION
% ============================================================================
% Detects circular CNAME chains (DNS misconfiguration or evasion)
% Score: 65 points (moderate-high risk - DNS infrastructure issue)

regra 513
	se [avalia(dns_cname_loop(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, loopCname))].

% ============================================================================
% RULE 514: SINGLE NAMESERVER
% ============================================================================
% Detects domains with only one authoritative nameserver (weak infrastructure)
% Score: 50 points (moderate risk - lack of redundancy)

regra 514
	se [avalia(dns_nameserver_count(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, nameserverUnico))].

% ============================================================================
% RULE 515: NO REVERSE DNS
% ============================================================================
% Detects missing PTR records (no reverse DNS mapping)
% Score: 40 points (low-moderate risk - poor infrastructure hygiene)

regra 515
	se [avalia(dns_reverse_dns_exists(Url, ==, 0))]
	entao [cria_facto(caracteristicas(Url, semReverseDns))].

% ============================================================================
% RULE 516: NO EMAIL AUTHENTICATION
% ============================================================================
% Detects complete absence of SPF, DMARC, and DKIM
% Score: 55 points (moderate-high risk - no email security)
% Note: Only fires when email auth was successfully checked (count >= 0)

regra 516
	se [avalia(dns_email_auth_count(Url, ==, 0))]
	entao [cria_facto(caracteristicas(Url, semAutenticacaoEmail))].

% ============================================================================
% RULE 517: PARTIAL EMAIL AUTHENTICATION  
% ============================================================================
% Detects partial email authentication (1 or 2 of SPF/DMARC/DKIM present)
% Score: 20 points (low-moderate risk - incomplete email security)

regra 517
	se [avalia(dns_email_auth_count(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, autenticacaoEmailParcial))].

% ============================================================================
% RULE 518: SLOW DNS RESPONSE
% ============================================================================
% Detects slow DNS query responses (> 2 seconds)
% Score: 45 points (moderate risk - DNS performance/availability issue)

regra 518
	se [avalia(dns_response_time_seconds(Url, >, 2.0))]
	entao [cria_facto(caracteristicas(Url, respostaDnsLenta))].

% ============================================================================
% HTTP BEHAVIOR RULES (600-699)
% ============================================================================

% ============================================================================
% RULE 600: HTTP WITHOUT TLS
% ============================================================================
% Penalize URLs using HTTP instead of HTTPS
% Score: 100 points (security risk)

regra 600
	se [avalia(http_scheme(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, semTLS))].

% ============================================================================
% RULE 601: URL UNREACHABLE (GENERIC)
% ============================================================================
% Penalize URLs that cannot be reached (fallback for granular rules)
% Score: 300 points (high risk - dead/fake sites)
% Note: Requires url_reachability/2 fact from Python (HTTP check)

% ============================================================================
% NOTE: Rules 601-604 (URL Unreachable) REMOVED
% ============================================================================
% These rules were not present in the Drools engine reference implementation.
% Drools does not analyze URL reachability (unreachable, network_failure, 
% client_error, server_error states). Removed for alignment with Drools.
%
% Removed Rules:
% - Rule 601: URL unreachable (generic) - Score 300
% - Rule 602: URL unreachable - network failure - Score 350
% - Rule 603: URL unreachable - client error (4xx) - Score 300
% - Rule 604: URL unreachable - server error (5xx) - Score 320
% ============================================================================

% ============================================================================
% RULE 605: URL REACHABLE VIA REDIRECT (3xx)
% ============================================================================
% Detects URLs that respond with redirect (3xx) - potential obfuscation
% Score: 10 points (low risk - redirects can be legitimate but worth flagging)
% Note: Requires url_reachability_reason(URL, redirect) from Python

regra 605
	se [avalia(url_reachability(Url, ==, reachable)), 
	    avalia(url_reachability_reason(Url, ==, redirect))]
	entao [cria_facto(caracteristicas(Url, urlAtingivelRedirect))].

% ============================================================================
% RULE 606: REDIRECT CHAIN
% ============================================================================
% Detects URLs with multiple redirects (> 3 hops)
% Score: 45 points (moderate risk - obfuscation technique)
% Aligns with Drools: "REDIRECT: Excessive redirect count" (>3 redirects)

regra 606
	se [avalia(redirect_chain_hops(Url, >, 3))]
	entao [cria_facto(caracteristicas(Url, cadeiaRedirecionamento))].

% ============================================================================
% RULE 607: HIGH REDIRECT DEPTH (5+ hops)
% ============================================================================
% Detects URLs with many redirects (> 5 hops) - strong phishing indicator
% Score: 70 points (high risk - excessive obfuscation)
% Aligns with Drools: "REDIRECT: Very excessive redirect count" (>5 redirects)

regra 607
	se [avalia(redirect_chain_hops(Url, >, 5))]
	entao [cria_facto(caracteristicas(Url, cadeiaRedirecionamentoProfunda))].

% ============================================================================
% RULE 608: HIGH DOMAIN DIVERSITY IN REDIRECT CHAIN
% ============================================================================
% Detects redirect chains with high domain diversity (ratio ≥ 0.6)
% Score: 200 points (high risk - cross-domain evasion technique)
% Based on: "Rules for Detecting Redirect Chains in URLs.md" - R1.B

regra 608
	se [avalia(redirect_diversity_ratio(Url, >=, 0.6))]
	entao [cria_facto(caracteristicas(Url, diversidadeDominiosRedirect))].

% ============================================================================
% RULE 609: URL SHORTENERS IN REDIRECT CHAIN
% ============================================================================
% Detects use of URL shorteners in redirect chain (≥ 1)
% Score: 100 points (medium risk - common obfuscation tactic)
% Based on: "Rules for Detecting Redirect Chains in URLs.md" - R1.C

regra 609
	se [avalia(redirect_shortener_count(Url, >=, 1))]
	entao [cria_facto(caracteristicas(Url, encurtadoresEmCadeia))].

% ============================================================================
% RULE 610: MULTIPLE URL SHORTENERS IN CHAIN
% ============================================================================
% Detects multiple URL shorteners (≥ 2) in redirect chain
% Score: 180 points (high risk - excessive obfuscation)
% Based on: "Rules for Detecting Redirect Chains in URLs.md" - R1.C

regra 610
	se [avalia(redirect_shortener_count(Url, >=, 2))]
	entao [cria_facto(caracteristicas(Url, multiplosEncurtadores))].

% ============================================================================
% RULE 611: UNTRUSTED REDIRECT IN CHAIN (WITH INDICATORS)
% ============================================================================

% Variant A: untrusted + excessive redirects
regra 611
	se [avalia(redirect_untrusted_domain(Url, ==, 1)) e avalia(redirect_chain_hops(Url, >, 3))]
	entao [cria_facto(caracteristicas(Url, redirectDominiosNaoConfiaveis))].

% Variant B: untrusted + open redirect
regra 623
	se [avalia(redirect_untrusted_domain(Url, ==, 1)) e avalia(redirect_open_redirect(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, redirectDominiosNaoConfiaveis))].

% Variant C: untrusted + obfuscated
regra 624
	se [avalia(redirect_untrusted_domain(Url, ==, 1)) e avalia(redirect_obfuscated_url(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, redirectDominiosNaoConfiaveis))].

% Variant D: untrusted + very new final destination
regra 625
	se [avalia(redirect_untrusted_domain(Url, ==, 1)) e avalia(final_destination_age_days(Url, <, 180))]
	entao [cria_facto(caracteristicas(Url, redirectDominiosNaoConfiaveis))].

% ============================================================================
% RULE 612: OPEN REDIRECT PATTERN
% ============================================================================

regra 612
	se [avalia(redirect_open_redirect(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, redirectAbertoParametro))].

% ============================================================================
% RULE 613: OBFUSCATED URL IN REDIRECT CHAIN
% ============================================================================

regra 613
	se [avalia(redirect_obfuscated_url(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, redirectUrlOfuscada))].

% ============================================================================
% RULE 614: BROKEN REDIRECT CHAIN (LOOP/ERROR)
% ============================================================================

regra 614
	se [avalia(redirect_chain_broken(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, cadeiaRedirectQuebrada))].

% ============================================================================
% RULE 615: MULTIPLE SUSPICIOUS REDIRECT INDICATORS
% ============================================================================

% Variant A: excessive redirects + untrusted
regra 615
	se [avalia(redirect_chain_hops(Url, >, 3)) e avalia(redirect_untrusted_domain(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, multiplosIndicadoresRedirect))].

% Variant B: excessive redirects + open redirect
regra 626
	se [avalia(redirect_chain_hops(Url, >, 3)) e avalia(redirect_open_redirect(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, multiplosIndicadoresRedirect))].

% Variant C: excessive redirects + obfuscated URL
regra 627
	se [avalia(redirect_chain_hops(Url, >, 3)) e avalia(redirect_obfuscated_url(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, multiplosIndicadoresRedirect))].

% ============================================================================
% RULE 616: URL SHORTENER WITH ADDITIONAL REDIRECTS
% ============================================================================

regra 616
	se [avalia(redirect_shortener_count(Url, >=, 1)) e avalia(redirect_chain_hops(Url, >, 1))]
	entao [cria_facto(caracteristicas(Url, encurtadorComRedirects))].

% ============================================================================
% RULE 617: URL SHORTENER WITH OPEN REDIRECT
% ============================================================================

regra 617
	se [avalia(redirect_shortener_count(Url, >=, 1)) e avalia(redirect_open_redirect(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, encurtadorComRedirectAberto))].

% ============================================================================
% RULE 618: TRUSTED FINAL DESTINATION
% ============================================================================

regra 618
	se [avalia(final_destination_trusted(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, destinoFinalConfiavel))].

% ============================================================================
% RULE 619-620: FINAL DESTINATION DOMAIN AGE BINS
% ============================================================================

regra 619
	se [avalia(final_destination_age_days(Url, <, 180))]
	entao [cria_facto(caracteristicas(Url, destinoFinalMuitoNovo))].

regra 620
	se [avalia(final_destination_age_days(Url, >=, 180)) e avalia(final_destination_age_days(Url, <, 365))]
	entao [cria_facto(caracteristicas(Url, destinoFinalMenosUmAno))].


% ============================================================================
% RULE 622: TLS/SSL CERTIFICATE ERROR
% ============================================================================

regra 622
	se [avalia(http_tls_certificate_error(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, erroCertificadoTLS))].

% ============================================================================
% DOM ANALYSIS RULES (700-708)
% ============================================================================

% RULE 700: Sensitive input fields detected (2+ fields: password, email, credit card, etc.)
regra 700
	se [avalia(sensitive_fields_present(Url, >=, 2))]
	entao [cria_facto(caracteristicas(Url, domCamposSensiveis))].

% RULE 701: Password field present in DOM
regra 701
	se [avalia(password_field_present(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, domSenhaPresente))].

% RULE 702: External form actions (forms submitting to external domains)
regra 702
	se [avalia(external_form_actions(Url, >=, 1))]
	entao [cria_facto(caracteristicas(Url, domFormActionExterna))].

% RULE 703: Many external or null links (5+ suspicious links)
regra 703
	se [avalia(external_or_null_links(Url, >=, 5))]
	entao [cria_facto(caracteristicas(Url, domMuitosLinksExternos))].

% RULE 704: External media/scripts loaded (3+ external resources)
regra 704
	se [avalia(external_media(Url, >=, 3))]
	entao [cria_facto(caracteristicas(Url, domMidiaExterna))].

% RULE 705: High DOM entropy (obfuscated/encoded content)
regra 705
	se [avalia(dom_entropy(Url, >, 4.5))]
	entao [cria_facto(caracteristicas(Url, domEntropiaAlta))].

% RULE 706: Obfuscated page title
regra 706
	se [avalia(title_obfuscated(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, domTituloOfuscado))].

% RULE 707: Suspicious link/feature ratio (high link count vs inputs)
regra 707
	se [avalia(link_feature_ratio(Url, >, 10.0))]
	entao [cria_facto(caracteristicas(Url, domLinksSuspeitos))].

% RULE 708: Critical DOM combination (password + external form + suspicious links)
regra 708
	se [avalia(password_field_present(Url, ==, 1)) e avalia(external_form_actions(Url, >=, 1)) e avalia(external_or_null_links(Url, >=, 3))]
	entao [cria_facto(caracteristicas(Url, domMultiplosIndicadores))].

% ============================================================================
% END OF RULES
% ============================================================================
