% Subdomain count fact
:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.
:- use_module(common_utils, [extract_host/2, is_ip/1, count_subdomains/2]).

feature_extractor(dns_subdomain_count_check).

dns_subdomain_count_check(URL) :-
    ultimo_facto(N), ultima_caracteristica(C),
    retract(ultima_caracteristica(_)), C1 is C + 1, asserta(ultima_caracteristica(C1)),
    retract(ultimo_facto(_)), N1 is N + 1, asserta(ultimo_facto(N1)),
    (   extract_host(URL, Host), \+ is_ip(Host), count_subdomains(Host, Count)
    ->  assertz(facto(N1, dns_subdomain_count(URL, Count)))
    ;   assertz(facto(N1, dns_subdomain_count(URL, 0)))
    ).
