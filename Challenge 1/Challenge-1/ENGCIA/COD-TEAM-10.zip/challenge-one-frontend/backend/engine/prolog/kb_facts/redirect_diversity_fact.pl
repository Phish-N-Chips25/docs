% redirect_diversity_fact.pl
% Extractor for redirect chain domain diversity ratio

facto_redirect_diversity(Url, Ratio) :-
    redirect_diversity_ratio(Url, Ratio).
