% Bridge dynamic facts asserted from Python into the inference engine
:- multifile feature_extractor/1.
:- dynamic python_fact/2.
:- dynamic ultimo_facto/1.
:- dynamic ultima_caracteristica/1.
:- dynamic facto/2.

feature_extractor(python_fact_bridge).

python_fact_bridge(URL) :-
    findall(Fact, python_fact(URL, Fact), Facts),
    seed_python_facts(Facts),
    retractall(python_fact(URL, _)).

seed_python_facts([]).
seed_python_facts([Fact|Rest]) :-
    ultimo_facto(N0),
    retract(ultimo_facto(_)),
    N is N0 + 1,
    asserta(ultimo_facto(N)),
    ultima_caracteristica(C0),
    retract(ultima_caracteristica(_)),
    C is C0 + 1,
    asserta(ultima_caracteristica(C)),
    assertz(facto(N, Fact)),
    seed_python_facts(Rest).
