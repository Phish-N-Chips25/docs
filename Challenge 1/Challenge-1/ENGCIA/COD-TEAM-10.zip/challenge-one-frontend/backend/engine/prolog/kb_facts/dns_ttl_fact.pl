% ============================================================================
% DNS TTL (Time To Live) ANALYSIS FACT
% ============================================================================
% Checks minimum DNS TTL values for fast-flux detection
%
% This file declares the dynamic predicate that Python will assert.
% No feature_extractor needed - kb_rules.pl queries this directly via avalia().
%
% Predicate: dns_min_ttl/2
%   Args: dns_min_ttl(URL, TTL)
%   Values: TTL = minimum TTL in seconds, -1 if no records found
%
% Asserted by: DNSFactsIntegration.assert_dns_facts() in dns_facts_integration.py
% Queried by: Rule 501 (ttl_muito_baixo) in kb_rules.pl
% ============================================================================

:- dynamic dns_min_ttl/2.