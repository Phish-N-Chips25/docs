"""
Lightweight DOM analyzer for phishing indicators.

This implementation uses requests + BeautifulSoup to avoid heavy browser dependencies.
It extracts a few signals that map to the DOM rules used by the Prolog engine.

Returned fields (all optional, with safe defaults):
- sensitive_fields_count: int
- password_field_present: 0|1
- external_form_actions_count: int
- external_or_null_links_count: int
- external_media_count: int
- dom_entropy: float
- title_obfuscated: 0|1
- link_feature_ratio: float  (ratio of “suspicious” links among all links)
- dependent_request_ratio: float (ratio of external resources among all resources)
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict
from urllib.parse import urlparse, urljoin

import requests
from bs4 import BeautifulSoup


@dataclass
class DomFeatures:
    sensitive_fields_count: int = 0
    password_field_present: int = 0
    external_form_actions_count: int = 0
    external_or_null_links_count: int = 0
    external_media_count: int = 0
    dom_entropy: float = 0.0
    title_obfuscated: int = 0
    link_feature_ratio: float = 0.0
    dependent_request_ratio: float = 0.0

    def to_dict(self) -> Dict[str, object]:
        return {
            "sensitive_fields_count": int(self.sensitive_fields_count),
            "password_field_present": int(self.password_field_present),
            "external_form_actions_count": int(self.external_form_actions_count),
            "external_or_null_links_count": int(self.external_or_null_links_count),
            "external_media_count": int(self.external_media_count),
            "dom_entropy": float(self.dom_entropy),
            "title_obfuscated": int(self.title_obfuscated),
            "link_feature_ratio": float(self.link_feature_ratio),
            "dependent_request_ratio": float(self.dependent_request_ratio),
        }


def _entropy(text: str) -> float:
    if not text:
        return 0.0
    freq: Dict[str, int] = {}
    for ch in text:
        freq[ch] = freq.get(ch, 0) + 1
    length = len(text)
    ent = 0.0
    for count in freq.values():
        p = count / length
        if p > 0:
            # log2(p) approximation without math import to keep it light
            from math import log2
            ent -= p * log2(p)
    return ent


def _same_site(url: str, target: str) -> bool:
    try:
        u = urlparse(url if url else "")
        t = urlparse(target if target else "")
        if not u.hostname or not t.hostname:
            return False
        return u.hostname.lower() == t.hostname.lower()
    except Exception:
        return False


def analyze_dom(url: str, timeout: float = 4.0) -> Dict[str, object]:
    features = DomFeatures()
    if not url or not url.lower().startswith(("http://", "https://")):
        return features.to_dict()

    headers = {"User-Agent": "phish-n-chips/1.0"}
    html = ""
    try:
        resp = requests.get(url, headers=headers, timeout=timeout, allow_redirects=True)
        # only parse if text-like
        ctype = resp.headers.get("Content-Type", "").lower()
        if "text/html" in ctype or ctype.startswith("text/") or ctype == "":
            html = resp.text or ""
        else:
            html = ""
    except Exception:
        # Network issues: return defaults
        return features.to_dict()

    if not html:
        return features.to_dict()

    try:
        soup = BeautifulSoup(html, "html.parser")

        # Sensitive fields: password inputs or fields with sensitive names
        inputs = soup.find_all("input")
        pw_fields = [i for i in inputs if (i.get("type", "").lower() == "password")]
        sensitive_named = [
            i for i in inputs
            if re.search(r"(ssn|credit|card|cvv|iban|tax|document|passport)",
                         (i.get("name") or "") + " " + (i.get("id") or ""), re.I)
        ]
        features.password_field_present = 1 if len(pw_fields) > 0 else 0
        features.sensitive_fields_count = len(set(pw_fields + sensitive_named))

        # Forms: external or null actions
        forms = soup.find_all("form")
        ext_or_null_actions = 0
        for f in forms:
            action = (f.get("action") or "").strip()
            if not action:
                ext_or_null_actions += 1
                continue
            abs_action = urljoin(url, action)
            if not _same_site(url, abs_action):
                ext_or_null_actions += 1
        features.external_form_actions_count = ext_or_null_actions

        # Links: external or null href
        a_tags = soup.find_all("a")
        ext_or_null_links = 0
        suspicious_links = 0
        for a in a_tags:
            href = (a.get("href") or "").strip()
            if not href or href.startswith("#"):
                ext_or_null_links += 1
                continue
            abs_href = urljoin(url, href)
            if not _same_site(url, abs_href):
                ext_or_null_links += 1
            # simple link suspiciousness: very long, contains token-like value, or many params
            if len(abs_href) > 120 or re.search(r"[A-Za-z0-9+/_-]{40,}", abs_href):
                suspicious_links += 1
            elif abs_href.count("=") >= 4:
                suspicious_links += 1
        total_links = max(1, len(a_tags))
        features.external_or_null_links_count = ext_or_null_links
        features.link_feature_ratio = round(suspicious_links / total_links, 4)

        # Media/resources: external
        external_media = 0
        resources = []
        resources.extend(soup.find_all("img"))
        resources.extend(soup.find_all("script"))
        resources.extend(soup.find_all("link"))
        resources.extend(soup.find_all("video"))
        resources.extend(soup.find_all("audio"))
        for r in resources:
            src = (r.get("src") or r.get("href") or "").strip()
            if not src:
                continue
            abs_src = urljoin(url, src)
            if not _same_site(url, abs_src):
                external_media += 1
        total_res = max(1, len(resources))
        features.external_media_count = external_media
        features.dependent_request_ratio = round(external_media / total_res, 4)

        # Entropy: title + visible text (truncate to avoid huge pages)
        title = (soup.title.string if soup.title and soup.title.string else "").strip()
        body_text = (soup.get_text(" ") or "").strip()
        body_text = body_text[:8000]
        ent = _entropy((title + " " + body_text)[:10000])
        features.dom_entropy = round(ent, 4)

        # Title obfuscation: very high entropy or heavy symbol usage or extremely long
        title_obf = False
        if len(title) > 80:
            title_obf = True
        # Many non-word symbols
        if re.search(r"[^\w\s]{8,}", title):
            title_obf = True
        if _entropy(title) > 4.5:
            title_obf = True
        features.title_obfuscated = 1 if title_obf else 0

    except Exception:
        # Parsing issues – return whatever we have collected so far
        pass

    return features.to_dict()
