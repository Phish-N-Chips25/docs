"""
Services package for phishing detection backend.

This package contains service modules that provide specialized functionality:
- dns_service: DNS lookups and analysis for domain validation
- dns_facts_integration: Integration of DNS results into Prolog knowledge base
"""

from .dns_service import DNSService
from .dns_facts_integration import DNSFactsIntegration

__all__ = ['DNSService', 'DNSFactsIntegration']
