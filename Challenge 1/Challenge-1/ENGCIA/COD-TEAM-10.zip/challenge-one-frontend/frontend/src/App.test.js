import { render, screen, within } from '@testing-library/react';
import App from './App';

test('renders phishing analysis workflow affordances', () => {
  render(<App />);

  expect(
    screen.getByRole('heading', {
      level: 2,
      name: /real-time phishing url scanner/i,
    })
  ).toBeInTheDocument();

  expect(
    screen.getByRole('button', {
      name: /analyze url/i,
    })
  ).toBeDisabled();

  const navigationPanel = screen.getByRole('complementary', {
    name: /session navigation/i,
  });

  expect(
    within(navigationPanel).getByRole('heading', {
      level: 3,
      name: /active rules/i,
    })
  ).toBeInTheDocument();
});
