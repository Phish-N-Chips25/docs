import { useCallback, useState } from 'react';

const STORAGE_KEY = 'phish.sessionHistory';

function readStoredHistory(limit) {
  if (typeof window === 'undefined' || typeof window.sessionStorage === 'undefined') {
    return [];
  }

  try {
    const rawValue = window.sessionStorage.getItem(STORAGE_KEY);
    if (!rawValue) {
      return [];
    }

    const parsed = JSON.parse(rawValue);
    if (!Array.isArray(parsed)) {
      return [];
    }

    return parsed.slice(0, limit);
  } catch (error) {
    console.warn('Unable to read session history', error);
    return [];
  }
}

function persistHistory(entries) {
  try {
    if (typeof window !== 'undefined' && typeof window.sessionStorage !== 'undefined') {
      window.sessionStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
    }
  } catch (error) {
    console.warn('Unable to persist session history', error);
  }
}

export function useSearchHistory(limit = 6) {
  const [history, setHistory] = useState(() => readStoredHistory(limit));

  const addEntry = useCallback(
    (entry) => {
      if (!entry || !entry.url) {
        return;
      }

      setHistory((previous) => {
        const deduped = previous.filter(
          (item) => !(item.url === entry.url && item.engine === entry.engine)
        );
        const next = [entry, ...deduped].slice(0, limit);
        persistHistory(next);
        return next;
      });
    },
    [limit]
  );

  const clearHistory = useCallback(() => {
    setHistory([]);
    persistHistory([]);
  }, []);

  return { history, addEntry, clearHistory };
}
