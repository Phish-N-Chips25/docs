// frontend/src/services/droolsApi.js
import axios from "axios";

const BACKEND_BASE_URL =
  process.env.REACT_APP_BACKEND_URL?.replace(/\/$/, "") || "http://localhost:8080";
const DROOLS_TIMEOUT_MS = Number(process.env.REACT_APP_DROOLS_TIMEOUT_MS || 60000);

const droolsClient = axios.create({
  baseURL: `${BACKEND_BASE_URL}`,
  timeout: DROOLS_TIMEOUT_MS,
});

droolsClient.interceptors.request.use(
  (config) => {
    console.info(
      `[DroolsAPI] ${config.method?.toUpperCase()} ${config.baseURL ?? ""}${
        config.url ?? ""
      }`
    );
    return config;
  },
  (error) => {
    console.error("[DroolsAPI] Request error", error);
    return Promise.reject(error);
  }
);

droolsClient.interceptors.response.use(
  (response) => response,
  (error) => {
    console.error("[DroolsAPI] Response error", error);
    return Promise.reject(error);
  }
);

const STATUS_CATEGORY_MAP = {
  CLEAR: "safe",
  LEGITIMATE: "safe",
  LOW_RISK: "safe",
  REVIEW: "suspicious",
  SUSPICIOUS: "suspicious",
  PROBABLE_PHISHING: "phishing",
  CONFIRMED_PHISHING: "phishing",
};

const STATUS_DISPLAY_MAP = {
  CLEAR: "Clear",
  LEGITIMATE: "Legitimate",
  LOW_RISK: "Low Risk",
  REVIEW: "Review",
  SUSPICIOUS: "Suspicious",
  PROBABLE_PHISHING: "Probable Phishing",
  CONFIRMED_PHISHING: "Most Likely Phishing",
};

const STATUS_COPY_MAP = {
  CLEAR:
    "Drools did not detect meaningful risk indicators. Maintain routine monitoring.",
  LEGITIMATE:
    "Drools classified the URL as legitimate. Continue normal monitoring routines.",
  LOW_RISK:
    "Low-risk signals surfaced. Track user reports but no immediate action is required.",
  REVIEW: "Manual review recommended before trusting this URL.",
  SUSPICIOUS:
    "Suspicious heuristics detected. Investigate thoroughly before interacting.",
  PROBABLE_PHISHING:
    "High-confidence phishing patterns found. Treat as hostile and escalate.",
  CONFIRMED_PHISHING:
    "Critical indicators confirm a phishing attempt. Block and notify stakeholders immediately.",
};

export class DroolsEvaluationRequest {
  constructor(url) {
    this.url = url;
  }

  toPayload() {
    return { url: this.url };
  }
}

export class DroolsRuleFinding {
  constructor(finding, value) {
    this.finding = finding ?? "";
    this.value = value ?? "";
  }

  toText() {
    if (!this.finding) {
      return String(this.value ?? "");
    }
    if (this.value === undefined || this.value === null || this.value === "") {
      return `${this.finding}`;
    }
    return `${this.finding}: ${this.value}`;
  }

  static from(rawFinding = {}) {
    return new DroolsRuleFinding(rawFinding.finding, rawFinding.value);
  }
}

export class DroolsTriggeredRule {
  constructor(name, score, description, details = []) {
    this.name = name ?? "Unknown rule";
    this.score = typeof score === "number" ? score : Number(score) || 0;
    this.description = description ?? "";
    this.details = details.map((detail) => DroolsRuleFinding.from(detail));
  }

  toRuleResult() {
    const detailFragments = this.details
      .map((detail) => detail.toText())
      .filter((fragment) => fragment && fragment.trim().length > 0);

    const composedDetails = [this.description, ...detailFragments]
      .filter(Boolean)
      .join(" ");

    return {
      rule_name: this.name,
      score: this.score,
      details: composedDetails || "No additional details provided by Drools.",
    };
  }

  static fromEntry([name, payload]) {
    if (!payload || typeof payload !== "object") {
      return new DroolsTriggeredRule(name, 0, "No description available.");
    }
    const { score, description, details } = payload;
    const detailList = Array.isArray(details) ? details : [];
    return new DroolsTriggeredRule(name, score, description, detailList);
  }
}

export class DroolsEvaluationResponse {
  constructor(
    status,
    score,
    totalRulesTriggered,
    totalRulesEvaluated,
    triggeredRules = []
  ) {
    this.status = status ?? "CLEAR";
    this.score = typeof score === "number" ? score : Number(score) || 0;
    this.totalRulesTriggered =
      typeof totalRulesTriggered === "number"
        ? totalRulesTriggered
        : Number(totalRulesTriggered) || 0;
    this.totalRulesEvaluated =
      typeof totalRulesEvaluated === "number"
        ? totalRulesEvaluated
        : Number(totalRulesEvaluated) || 0;
    this.triggeredRules = triggeredRules;
  }

  static fromRaw(raw = {}) {
    const {
      status,
      score,
      totalRulesTriggered,
      totalRulesEvaluated,
      triggeredRules,
    } = raw;
    const entries =
      triggeredRules && typeof triggeredRules === "object"
        ? Object.entries(triggeredRules)
        : [];
    const normalizedRules = entries.map((entry) =>
      DroolsTriggeredRule.fromEntry(entry)
    );
    return new DroolsEvaluationResponse(
      status,
      score,
      totalRulesTriggered,
      totalRulesEvaluated,
      normalizedRules
    );
  }

  riskLevel() {
    return STATUS_CATEGORY_MAP[this.status] ?? "suspicious";
  }

  riskLabel() {
    return STATUS_DISPLAY_MAP[this.status] ?? STATUS_DISPLAY_MAP.REVIEW;
  }

  riskCopy() {
    return STATUS_COPY_MAP[this.status] ?? STATUS_COPY_MAP.REVIEW;
  }

  toRuleResults() {
    return this.triggeredRules.map((rule) => rule.toRuleResult());
  }

  triggeredCount() {
    return this.totalRulesTriggered || this.triggeredRules.length;
  }

  evaluatedCount() {
    return this.totalRulesEvaluated || this.triggeredRules.length;
  }
}

export async function evaluateDroolsUrl(url) {
  const request = new DroolsEvaluationRequest(url);
  const response = await droolsClient.post("/evaluate", request.toPayload());
  return DroolsEvaluationResponse.fromRaw(response.data);
}
