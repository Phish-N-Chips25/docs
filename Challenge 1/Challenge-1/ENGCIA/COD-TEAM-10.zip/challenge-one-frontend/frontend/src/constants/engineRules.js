export const ENGINE_RULES = {
  prolog: [
    {
      name: 'https',
      description: 'Detect URLs that use HTTPS to prioritize secure connections.',
    },
    {
      name: 'domain_age',
      description: 'Highlight domains older than six months.',
    },
    {
      name: 'whitelist',
      description: 'Confirm whether the URL appears in the organization whitelist.',
    },
    {
      name: 'blacklist',
      description: 'Flag URLs previously blocked during phishing campaigns.',
    },
    {
      name: 'ip_address',
      description: 'Identify hosts that rely on direct IP addresses.',
    },
    {
      name: 'redirect_chain',
      description: 'Monitor redirect chains with more than three hops.',
    },
    {
      name: 'long_url',
      description: 'Detect URLs that exceed an acceptable length.',
    },
    {
      name: 'suspicious_tld',
      description: 'Highlight domains that use TLDs associated with malicious campaigns.',
    },
  ],
  drools: [
    {
      name: 'https',
      description: 'Score URLs that start with HTTPS more favorably.',
    },
    {
      name: 'domain_age',
      description: 'Award extra score to older, stable domains.',
    },
    {
      name: 'whitelist',
      description: 'Consider URLs officially approved by the security team.',
    },
    {
      name: 'blacklist',
      description: 'Elevate indicators previously marked as malicious.',
    },
    {
      name: 'ip_address',
      description: 'Raise an alert when the host uses an IP format.',
    },
    {
      name: 'redirect_chain',
      description: 'Analyze redirect sequences longer than five steps.',
    },
    {
      name: 'long_url',
      description: 'Mark long URLs that may hide suspicious parameters.',
    },
    {
      name: 'suspicious_tld',
      description: 'Indicate TLDs frequently used in social engineering attacks.',
    },
  ],
};

export const ENGINE_TITLES = {
  prolog: 'Prolog engine',
  drools: 'Drools engine',
};
