import React, { useCallback, useMemo, useState } from 'react';
import UrlSearch from './components/UrlSearch';
import RuleBook from './components/RuleBook';
import SearchHistory from './components/SearchHistory';
import { ENGINE_RULES, ENGINE_TITLES } from './constants/engineRules';
import { useSearchHistory } from './hooks/useSearchHistory';
import './App.css';


export default function App() {
  const [engine, setEngine] = useState('prolog');
  const [prefillRequest, setPrefillRequest] = useState(null);
  const activeRules = useMemo(() => ENGINE_RULES[engine] ?? [], [engine]);
  const { history, addEntry, clearHistory } = useSearchHistory(6);

  const activeEngineLabel = ENGINE_TITLES[engine] ?? engine;

  const handleSelectHistoryEntry = useCallback(
    (entry) => {
      if (!entry || !entry.url) {
        return;
      }

      setEngine((previous) => (previous === entry.engine ? previous : entry.engine));
      setPrefillRequest({
        id: `${entry.id ?? entry.url}-${Date.now()}`,
        url: entry.url,
        engine: entry.engine,
      });
    },
    []
  );

  return (
    <div className="app-shell">
      <aside className="app-navigation" aria-label="Session navigation">
        <div className="app-navigation__brand">
          <img className="app-navigation__logo" src="/logo.jpg" alt="Phish-n-Chips" loading="lazy" />
          <div className="app-navigation__identity">
            <p className="app-navigation__eyebrow">Phish-n-Chips</p>
            <p className="app-navigation__title">Investigation Console</p>
          </div>
        </div>

        <div className="app-navigation__content">
          <SearchHistory
            entries={history}
            onSelectEntry={handleSelectHistoryEntry}
            onClearHistory={history.length > 0 ? clearHistory : undefined}
          />
          <div className="app-navigation__rules" aria-label="Active rule reference">
            <RuleBook engine={engine} rules={activeRules} />
          </div>
        </div>

        <div className="app-navigation__footer">
          <p className="app-navigation__footerTitle">Need more context?</p>
          <p className="app-navigation__footerHint">Drill into any session to expand insights and analyst notes.</p>
        </div>
      </aside>

      <div className="app-main" aria-label="Operations workspace">
        <header className="app-header" aria-labelledby="workspace-heading">
          <div className="app-header__content">
            <p className="app-header__eyebrow">Live operations workspace</p>
            <h1 id="workspace-heading" className="app-header__title">
              Real-time intelligence against phishing
            </h1>
            <p className="app-header__description">
              Combine Prolog and Drools rules to review suspicious URLs, prioritize response work, and improve the SOC
              analyst experience across regions.
            </p>
          </div>
          <div className="app-header__meta" aria-live="polite">
            <span className="app-header__metaLabel">Active engine</span>
            <span className="app-header__metaValue">{activeEngineLabel}</span>
            <span className="app-header__metaHint">{activeRules.length} rules loaded</span>
          </div>
        </header>

        <section className="app-workspace" aria-label="Analysis tools">
          <div className="app-workspace__primary">
            <UrlSearch
              engine={engine}
              onEngineChange={setEngine}
              totalRules={activeRules.length}
              onRecordSearch={addEntry}
              prefillRequest={prefillRequest}
            />
          </div>
        </section>

        <footer className="app-footer">
          <span>Updated for v0.1.0 — optimized for desktop and mobile.</span>
        </footer>
      </div>
    </div>
  );
}
