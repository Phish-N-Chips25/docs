import React from 'react';
import RuleResult from './RuleResult';

export default function ResultsPanel({ results, loading, error, hasSearched, redirectMetrics }) {
  if (error) {
    return (
      <p className="error-message" role="alert">
        {error}
      </p>
    );
  }

  if (loading) {
    return (
      <div className="loading-state" role="status" aria-live="polite">
        <span className="spinner" aria-hidden="true" />
        <span>Running heuristics...</span>
      </div>
    );
  }

  if (hasSearched && results.length === 0) {
    return (
      <p className="empty-state" role="status">
        No rules were triggered for this URL.
      </p>
    );
  }

  if (results.length === 0) {
    return null;
  }

  return (
    <div className="results-list" aria-live="polite">
      {results.map((result, index) => (
        <RuleResult key={`${result.rule_name}-${index}`} rule={result} redirectMetrics={redirectMetrics} />
      ))}
    </div>
  );
}
