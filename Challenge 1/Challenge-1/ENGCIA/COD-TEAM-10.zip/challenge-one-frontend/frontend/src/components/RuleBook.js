import React from 'react';
import { ENGINE_TITLES } from '../constants/engineRules';

export default function RuleBook({ engine, rules }) {
  const displayRules = Array.isArray(rules) ? rules : [];
  const totalRules = displayRules.length;
  const rulesLabel = totalRules === 1 ? 'heuristic rule' : 'heuristic rules';

  return (
    <div className="engine-rules" aria-live="polite">
      <h3 className="engine-rules__title">Active rules ({ENGINE_TITLES[engine] ?? engine})</h3>
      {displayRules.length > 0 && (
        <p className="engine-rules__summary">
          This engine evaluates {totalRules} {rulesLabel}. Any rule that fires during analysis will be highlighted in
          the results panel.
        </p>
      )}
      {displayRules.length > 0 ? (
        <ul className="engine-rules__list">
          {displayRules.map((rule) => (
            <li key={rule.name} className="engine-rules__item">
              <span className="engine-rules__badge">{rule.name}</span>
              <span className="engine-rules__description">{rule.description}</span>
            </li>
          ))}
        </ul>
      ) : (
        <p className="engine-rules__empty">No rules are registered for this engine.</p>
      )}
    </div>
  );
}
