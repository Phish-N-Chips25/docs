import React from 'react';
import { ENGINE_TITLES } from '../constants/engineRules';

const ENGINES = ['prolog', 'drools'];

export default function EngineSelector({ engine, onChange, disabled }) {
  return (
    <fieldset className="engine-select" role="radiogroup" aria-label="Rule engine selection">
      <legend className="sr-only">Rule engine</legend>
      {ENGINES.map((engineId) => (
        <label key={engineId}>
          <input
            type="radio"
            name="engine"
            value={engineId}
            checked={engine === engineId}
            onChange={() => onChange(engineId)}
            disabled={disabled}
          />
          {ENGINE_TITLES[engineId]}
        </label>
      ))}
    </fieldset>
  );
}
