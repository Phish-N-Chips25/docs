// frontend/src/components/RuleResult.js
import React from 'react';
import styles from './RuleResult.module.css';

const HIGH_THRESHOLD = 0.7;
const MEDIUM_THRESHOLD = 0.4;

const formatDecimal = (value, digits = 2) => {
  const numeric = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(numeric) ? numeric.toFixed(digits) : '—';
};

const formatInteger = (value) => {
  const numeric = typeof value === 'number' ? value : Number(value);
  return Number.isFinite(numeric) ? Math.round(numeric) : '—';
};

const formatText = (value) => {
  if (!value) {
    return '—';
  }
  if (typeof value === 'string' && value.trim().toLowerCase() === 'unknown') {
    return '—';
  }
  return value;
};

export default function RuleResult({ rule, redirectMetrics }) {
  const scoreClass =
    rule.score >= HIGH_THRESHOLD
      ? styles.scoreHigh
      : rule.score >= MEDIUM_THRESHOLD
      ? styles.scoreMedium
      : styles.scoreDefault;

  const redirectPath =
    rule.rule_name === 'redirect_chain' && redirectMetrics && Array.isArray(redirectMetrics.redirect_urls)
      ? redirectMetrics.redirect_urls
      : [];
  const lastIndex = redirectPath.length - 1;

  return (
      <article className={styles.resultCard} aria-label={`Rule result ${rule.rule_name}`}>
          <h3 className={styles.ruleTitle}>{rule.rule_name}</h3>
          <span className={`${styles.scoreBadge} ${scoreClass}`}>
        Score {rule.score.toFixed(2)}
      </span>
          <p className={styles.detailsLabel}>Details</p>
          <div className={styles.detailsText} style={{whiteSpace: "pre-wrap"}}>
              {rule.details}
          </div>
          {rule.rule_name === 'redirect_chain' && redirectMetrics && (
              <dl className={styles.redirectMetrics}>
                  <div className={styles.redirectMetricRow}>
                      <dt>Classification</dt>
                      <dd>
                          {redirectMetrics.classification} · {redirectMetrics.confidence} confidence
                      </dd>
                  </div>
                  <div className={styles.redirectMetricRow}>
                      <dt>Landing host</dt>
                      <dd title={redirectMetrics.final_url ?? undefined}>{formatText(redirectMetrics.final_hostname)}</dd>
                  </div>
                  <div className={styles.redirectMetricRow}>
                      <dt>Expanded length</dt>
                      <dd>{formatInteger(redirectMetrics.final_url_length)}</dd>
                  </div>
                  <div className={styles.redirectMetricRow}>
                      <dt>Shorteners</dt>
                      <dd>{formatInteger(redirectMetrics.shortener_count)}</dd>
                  </div>
                  <div className={styles.redirectMetricRow}>
                      <dt>Diversity ratio</dt>
                      <dd>{formatDecimal(redirectMetrics.diversity_ratio)}</dd>
                  </div>
                  <div className={styles.redirectMetricRow}>
                      <dt>Redirect score</dt>
                      <dd>{formatDecimal(redirectMetrics.final_score)}</dd>
                  </div>
              </dl>
          )}
          {redirectPath.length > 0 && (
              <div className={styles.redirectPath}>
                  <p className={styles.redirectPathTitle}>Redirect sequence</p>
                  <ol className={styles.redirectPathList}>
                      {redirectPath.map((url, index) => (
                          <li key={`${url}-${index}`} className={styles.redirectPathItem}>
                              <span className={styles.redirectPathIndex}>{index + 1}</span>
                              <span
                                  className={index === lastIndex ? styles.redirectPathUrlFinal : styles.redirectPathUrl}
                                  title={url}
                              >
                  {url}
                </span>
                          </li>
                      ))}
                  </ol>
              </div>
          )}
      </article>
  );
}
