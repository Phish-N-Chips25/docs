# Phish-N-Chips Drools Chrome Extension

This Chrome extension injects a React UI into every page and offers a popup experience for evaluating URLs against the Drools (Java) and Prolog (Python) phishing rule engines that power the project backend.

## Features
- **Manifest v3** compliant configuration (`manifest.json`).
- **React UI** bundled with webpack and delivered as a single `content.js` file for on-page injection.
- **Shadow DOM mounting** keeps the injected interface isolated from host-page styles and scripts.
- **Popup UI** (`popup.html` + `popup.js`) provides instant access to the same workflow from the browser toolbar.
- **Backend integration** with Drools (`POST /evaluate`) and the Python Prolog API (`POST /analyze-url`).
- **CORS friendly** via Chrome extension host permissions (`<all_urls>`, `http://localhost:8000/*`, `http://localhost:8080/*`).

## Prerequisites
- Node.js 18+
- Access to the Drools service (default `http://localhost:8080`) and Python/Prolog backend (default `http://localhost:8000`).

## Installation
1. `cd extension`
2. Install dependencies:
   ```powershell
   npm install
   ```

## Build
- Production bundle (outputs to `dist/`):
  ```powershell
  npm run build
  ```
- Development watch mode:
  ```powershell
  npm run watch
  ```

### Environment overrides
Webpack inlines the following environment variables at build time:
- `DROOLS_API_URL` – defaults to `http://localhost:8080`
- `PROLOG_API_URL` – defaults to `http://localhost:8000`

Example:
```powershell
$env:DROOLS_API_URL="https://drools.example.com"; npm run build
```

## Load the extension in Chrome
1. Navigate to `chrome://extensions`.
2. Toggle **Developer mode** on (top right).
3. Choose **Load unpacked** and select the `extension/dist` folder.
4. Verify the extension icon appears in the toolbar and pin it if desired.

## Usage
- **Popup experience:** Click the toolbar icon to open the React UI, paste a URL, choose the engine, and press **Analyze URL**.
- **Inline experience:** Each page automatically gets an injected scanner (top-right). Use it to scan the current page URL or any arbitrary link.

## Development notes
- The injected UI is mounted inside a Shadow DOM to avoid style collisions with the host page.
- All bundled assets live in `dist/`. Re-run `npm run build` after changes.
- Update `manifest.json` or `public/popup.html` as needed; the build step copies them into the bundle.
