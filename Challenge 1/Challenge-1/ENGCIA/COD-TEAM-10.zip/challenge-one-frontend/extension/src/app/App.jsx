import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { evaluateDroolsUrl, evaluatePrologUrl } from '../services/droolsClient';

const ENGINES = [
  { id: 'drools', label: 'Drools (Java)' },
  { id: 'prolog', label: 'Prolog (Python)' }
];

const CATEGORY_TO_CLASS = {
  safe: 'pnc-ext-tag-safe',
  suspicious: 'pnc-ext-tag-suspicious',
  phishing: 'pnc-ext-tag-phishing'
};

export default function App({ surface = 'popup' }) {
  const [url, setUrl] = useState('');
  const [engine, setEngine] = useState('drools');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [result, setResult] = useState(null);

  const defaultTargetUrl = useMemo(() => {
    if (surface !== 'content') {
      return '';
    }
    try {
      return window.location.href || '';
    } catch (err) {
      return '';
    }
  }, [surface]);

  const placeholder = useMemo(
    () =>
      surface === 'content'
        ? 'Scan this page or paste another URL...'
        : 'Paste the URL you want to evaluate...'
    ,
    [surface]
  );

  useEffect(() => {
    if (!url && defaultTargetUrl) {
      setUrl(defaultTargetUrl);
    }
  }, [defaultTargetUrl, url]);

  const handleSubmit = async (event) => {
    event.preventDefault();
    let candidate = url.trim();
    if (!candidate && surface === 'content' && defaultTargetUrl) {
      candidate = defaultTargetUrl.trim();
      setUrl(defaultTargetUrl);
    }
    if (!candidate) {
      setError('Provide a URL to evaluate.');
      return;
    }
    const targetUrl = candidate;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const evaluation =
        engine === 'drools' ? await evaluateDroolsUrl(targetUrl) : await evaluatePrologUrl(targetUrl);
      setResult({ ...evaluation, url: targetUrl });
    } catch (err) {
      setError(err?.message ?? 'Unable to reach the analysis services.');
    } finally {
      setLoading(false);
    }
  };

  const handleUseCurrent = useCallback(() => {
    if (!defaultTargetUrl) {
      setError('Current page URL unavailable.');
      return;
    }
    setError(null);
    setResult(null);
    setUrl(defaultTargetUrl);
  }, [defaultTargetUrl]);

  const containerClass = useMemo(() => {
    const classes = ['pnc-ext-container'];
    if (surface === 'content') {
      classes.push('pnc-ext-surface-content');
    }
    return classes.join(' ');
  }, [surface]);

  return (
    <div className={containerClass}>
      <h2 className="pnc-ext-title">Drools Risk Scanner</h2>
      <p className="pnc-ext-subtitle">
        Evaluate URLs with the Drools (Java) and Prolog (Python) rule engines without leaving the page.
      </p>
      <form className="pnc-ext-form" onSubmit={handleSubmit}>
        <input
          type="url"
          className="pnc-ext-input"
          placeholder={placeholder}
          value={url}
          onChange={(event) => setUrl(event.target.value)}
          disabled={loading}
          required
        />
        <label className="pnc-ext-engineSelect">
          <span>Engine:</span>
          <select
            className="pnc-ext-input"
            value={engine}
            onChange={(event) => {
              setEngine(event.target.value);
              setError(null);
            }}
            disabled={loading}
          >
            {ENGINES.map((engineOption) => (
              <option key={engineOption.id} value={engineOption.id}>
                {engineOption.label}
              </option>
            ))}
          </select>
        </label>
        <div className="pnc-ext-actions">
          {surface === 'content' && (
            <button
              type="button"
              className="pnc-ext-button pnc-ext-button-secondary"
              onClick={handleUseCurrent}
              disabled={loading}
            >
              Use current page
            </button>
          )}
          <button type="submit" className="pnc-ext-button" disabled={loading}>
            {loading ? 'Analyzing…' : 'Analyze URL'}
          </button>
        </div>
      </form>

      {loading && (
        <p className="pnc-ext-loading">
          <span className="pnc-ext-spinner" aria-hidden="true" />
          Contacting analysis services…
        </p>
      )}

      {error && <p className="pnc-ext-error" role="alert">{error}</p>}

      {result && (
        <div className="pnc-ext-resultCard" role="status" aria-live="polite">
          <div className="pnc-ext-resultMeta">
            <span className={`pnc-ext-tag ${CATEGORY_TO_CLASS[result.riskCategory] || 'pnc-ext-tag-suspicious'}`}>
              {result.riskLabel}
            </span>
            <span className="pnc-ext-tag pnc-ext-tag-raw">Score {result.riskScore.toFixed(2)}</span>
            <span className="pnc-ext-tag pnc-ext-tag-raw">Engine · {result.engineLabel}</span>
          </div>
          {result.url && (
            <div>
              <strong>URL:</strong>
              <p className="pnc-ext-url" title={result.url}>
                {result.url}
              </p>
            </div>
          )}
          <div>
            <strong>Summary:</strong>
            <p>{result.summary}</p>
          </div>
          {result.findings.length > 0 && (
            <ul className="pnc-ext-resultDetails">
              {result.findings.map((finding, index) => (
                <li key={`${finding}-${index}`}>{finding}</li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
