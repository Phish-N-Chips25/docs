const DROOLS_API_URL = (process.env.DROOLS_API_URL || 'http://localhost:8080').replace(/\/$/, '');
const PROLOG_API_URL = (process.env.PROLOG_API_URL || 'http://localhost:8000').replace(/\/$/, '');

const DROOLS_STATUS_DESCRIPTIONS = {
  CLEAR: {
    category: 'safe',
    label: 'Clear',
    summary: 'Drools reports no risk indicators. Maintain standard monitoring.'
  },
  LOW_RISK: {
    category: 'safe',
    label: 'Low Risk',
    summary: 'Low-risk heuristics triggered. Track, but no immediate action required.'
  },
  REVIEW: {
    category: 'suspicious',
    label: 'Review',
    summary: 'Manual review is recommended before trusting this URL.'
  },
  SUSPICIOUS: {
    category: 'suspicious',
    label: 'Suspicious',
    summary: 'Suspicious patterns detected. Investigate before interacting.'
  },
  PROBABLE_PHISHING: {
    category: 'phishing',
    label: 'Probable Phishing',
    summary: 'High-confidence phishing traits observed. Treat as hostile.'
  },
  CONFIRMED_PHISHING: {
    category: 'phishing',
    label: 'Most Likely Phishing',
    summary: 'Critical indicators confirm a phishing attempt. Block immediately.'
  }
};

const PROLOG_RISK_DESCRIPTIONS = {
  safe: {
    category: 'safe',
    label: 'Safe',
    summary: 'No critical heuristics triggered in the Prolog engine.'
  },
  suspicious: {
    category: 'suspicious',
    label: 'Suspicious',
    summary: 'Signals detected. Investigate before trusting this URL.'
  },
  phishing: {
    category: 'phishing',
    label: 'Phishing',
    summary: 'Strong phishing indicators present. Block and escalate.'
  }
};

function normalizeDroolsFindings(triggeredRules = {}) {
  return Object.entries(triggeredRules).map(([ruleName, payload]) => {
    if (!payload || typeof payload !== 'object') {
      return `${ruleName}: triggered`;
    }

    const { description, details, score } = payload;
    const fragments = [description, Array.isArray(details) ? details.join(' · ') : '', `Score ${score ?? 0}`]
      .map((fragment) => (fragment ? String(fragment).trim() : ''))
      .filter(Boolean);
    return `${ruleName}: ${fragments.join(' | ')}`;
  });
}

export async function evaluateDroolsUrl(url) {
  const response = await fetch(`${DROOLS_API_URL}/evaluate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url }),
    mode: 'cors',
    credentials: 'omit'
  });

  if (!response.ok) {
    const errorText = await safeReadError(response);
    throw new Error(`Drools service error: ${errorText}`);
  }

  const data = await response.json();
  const statusKey = data.status || 'REVIEW';
  const statusMeta = DROOLS_STATUS_DESCRIPTIONS[statusKey] || DROOLS_STATUS_DESCRIPTIONS.REVIEW;

  return {
    engine: 'drools',
    engineLabel: 'Drools (Java)',
    riskCategory: statusMeta.category,
    riskLabel: statusMeta.label,
    riskScore: Number.isFinite(data.score) ? Number(data.score) : 0,
    findings: normalizeDroolsFindings(data.triggeredRules),
    summary: statusMeta.summary
  };
}

function normalizePrologFindings(results = []) {
  return results.map((entry) => {
    const name = entry?.rule_name || 'Unnamed rule';
    const details = entry?.details;
    const score = entry?.score;
    const fragments = [details, Number.isFinite(score) ? `Score ${score}` : null]
      .map((fragment) => (fragment ? String(fragment).trim() : ''))
      .filter(Boolean);
    return `${name}: ${fragments.join(' | ') || 'triggered'}`;
  });
}

export async function evaluatePrologUrl(url) {
  const response = await fetch(`${PROLOG_API_URL}/analyze-url?url=${encodeURIComponent(url)}&engine=prolog`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    mode: 'cors',
    credentials: 'omit'
  });

  if (!response.ok) {
    const errorText = await safeReadError(response);
    throw new Error(`Prolog service error: ${errorText}`);
  }

  const data = await response.json();
  const riskKey = data.risk_level || 'suspicious';
  const riskMeta = PROLOG_RISK_DESCRIPTIONS[riskKey] || PROLOG_RISK_DESCRIPTIONS.suspicious;

  return {
    engine: 'prolog',
    engineLabel: 'Prolog (Python)',
    riskCategory: riskMeta.category,
    riskLabel: riskMeta.label,
    riskScore: Number.isFinite(data.risk_score) ? Number(data.risk_score) : 0,
    findings: normalizePrologFindings(data.results),
    summary: riskMeta.summary
  };
}

async function safeReadError(response) {
  try {
    const text = await response.text();
    return text ? text.slice(0, 200) : `${response.status} ${response.statusText}`;
  } catch (error) {
    return `${response.status} ${response.statusText}`;
  }
}
