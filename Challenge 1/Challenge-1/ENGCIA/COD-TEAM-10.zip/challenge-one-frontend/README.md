# Phish-n-Chips PoC

Phish-n-Chips is a proof-of-concept threat intelligence assistant that blends a Python FastAPI backend (powered by Prolog and Drools heuristics) with a modern React frontend. Analysts can compare scoring engines, inspect triggered rules, and understand persona-driven needs in a single responsive interface.

## Tech Stack

- **Backend:** Python 3.11, FastAPI, Pydantic, `pyswip` (Prolog bridge), Drools integration
- **Frontend:** React (Create React App), Axios, CSS modules, modern responsive layout
- **Extension:** Chrome extension with React UI, dual-engine support (Prolog + Drools)
- **Tooling:** Pytest, PowerShell helper script for dual service startup, Webpack for extension builds

## Setup

All commands below are shown for Windows PowerShell. Adapt paths/activations for your OS if needed.

### 1. Prerequisites

- Git
- Python 3.11 or higher
- Node.js 18+ and npm

### 2. Clone the repository

```powershell
git clone https://github.com/Phish-N-Chips25/challenge-1-poc.git
cd challenge-1-poc
```

### 3. Backend — install & run

```powershell
cd backend
python -m venv venv
.\venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn backend.api.main:app --reload
```

The API lives at `http://127.0.0.1:8000/analyze-url` and hot-reloads on file changes.

### 4. Frontend — install & run

Open a second terminal:

```powershell
cd challenge-1-poc\frontend
npm install
npm start
```

The React UI launches on `http://localhost:3000` and proxies API calls to the backend.

### 5. One-command dev startup (optional)

From the project root you can launch both services with dedicated terminals:

```powershell
pwsh .\scripts\start-dev.ps1
```

Press **Enter** in the controller window when you want to terminate both watchers.

### 6. Run backend tests

```powershell
cd backend
.\venv\Scripts\Activate.ps1
python -m pytest tests
```

### 7. Chrome Extension — build & install

The project includes a Chrome extension that allows you to analyze URLs directly from your browser using both the Prolog and Drools engines.

#### Build the extension

```powershell
cd extension
npm install
npm run build
```

This creates a production build in the `extension/dist` directory.

#### Install in Chrome

1. Open Chrome and navigate to `chrome://extensions/`
2. Enable **Developer mode** (toggle in the top-right corner)
3. Click **Load unpacked**
4. Select the `extension/dist` folder from your project directory
5. The Phish-n-Chips extension icon should now appear in your toolbar

#### Usage

- Click the extension icon to open the popup
- Choose between **Drools (Java)** or **Prolog (Python)** engine
- Paste a URL or click "Use Current Page" to analyze the active tab
- View risk assessment, score, and triggered rules

**Note:** Both backend services must be running for the extension to work:

- Prolog backend on `http://localhost:8000`
- Drools backend on `http://localhost:8080`

### DNS Service Components

```
backend/services/
├── dns_service.py              # Core DNS lookup functionality
├── dns_facts_integration.py    # Prolog integration layer
├── rdap_service.py             # RDAP lookup functionality
└── whois_service.py            # WHOIS lookup functionality (RDAP fallback)
```

For detailed implementation and testing notes, see `backend/services/README.md`.

### Testing DNS Integration

```powershell
# Test DNS service standalone
cd backend
python -m services.dns_service google.com example.com

# Run comprehensive tests
cd tests
python test_knowledge_base.py    # Offline KB validation
python test_api.py     # API endpoint testing (requires running server)
```

The DNS service automatically integrates with the rule engine - no manual configuration needed!

## Rule evaluation workflow and gating

This summarizes how the engine evaluates a URL and how gates avoid irrelevant checks. The Prolog knowledge base is the source of truth for rule IDs and scores via `caracteristicas_regras/3` in `backend/engine/prolog/kb_rules.pl`.

### Stages

1. Pre-checks and feature extraction

- Parse and normalize URL
- Extract lexical URL facts (length, `@`, scheme)
- Extract DNS facts (A/AAAA presence, TTL, CNAME, MX/SPF if available)
- Check reachability (HTTP HEAD) and capture status/reason

2. Reputation and Trust (100-199)

- Rule 100 (whitelist): trusted domains → -500 points
- If `url_whitelisted(URL, 1)` then short-circuit: only Rule 100 fires

3. URL Structure (200-299)

- Rule 200: IP address in URL → 70
- Rule 201: Long URL (> 75) → 25
- Rule 202: '@' present → 30

4. Domain Lexical (400 - 499)

- Rule 400: Suspicious TLD (.xyz, .tk, …) → 200
- Rule 401: Long domain (> 30) → 150
- Rule 402: Excess subdomains (≥ 3) → 35
- Rule 404: High numeric ratio (> 30%) → 20
- Rule 405: Many hyphens (> 2) → 20
- Rule 406: Punycode/IDN → 40

5. DNS Infrastructure (500-599)

- Rule 500: No A/AAAA → 80
- Rule 501: Very low TTL (< 60s) → 45
- Rule 502: Long CNAME chain (≥ 3) → 35
- Rule 503: No MX and no SPF → 30
- Rule 504: Young domain (< 30d) → 90

6. HTTP Behavior (600-699)

- Rule 600: HTTP without TLS → 100
- Rule 601: URL unreachable (generic) → 300
- Rule 602: Network failure → 350
- Rule 603: Client error (4xx) → 300
- Rule 604: Server error (5xx) → 320
- Rule 605: Redirect detected (3xx) → 10
- Rule 606: Redirect chain (> 2 hops) → 150

7. DOM Analysis (700-799)

- Rule 700: Sensitive input fields (≥2) → 60
- Rule 701: Password field present → 40
- Rule 702: External form actions (≥1) → 25
- Rule 703: External/null links (≥5) → 20
- Rule 704: External media (≥3) → 35
- Rule 705: High DOM entropy (>4.5) → 30
- Rule 706: Title obfuscated → 40
- Rule 707: High link/feature ratio (>10) → 25
- Rule 708: Critical DOM combination → 90

8. Classification Thresholds (300-399)

- Rule 300: Score < 500 → safe/potential phishing
- Rule 301: Score ≥ 500 → phishing confirmed

### Gating logic (implemented in `motorInferencia.pl`)

- If using an IP address (`is_ip_address(URL,1)`), skip domain-lexical and certain DNS rules that don't apply: 400-408, 500-505
- If no A/AAAA (`dns_a_record_exists(URL,0)`), skip resolution-dependent and HTTP/redirect checks: 600-606, 501-502
- If unreachable (`url_reachability(URL,unreachable)`), skip the redirect chain rule: 606
- Prevent double-counting: when Rule 601 fires, skip granular 602-605; if reachable, skip 601-605
- Early stop: once score ≥ 500, skip all but classification rules 300-301

### Granular reachability facts asserted by Python

- `url_reachability(URL, reachable|unreachable)`
- `url_reachability_status(URL, StatusCode)` (e.g., 404, 500)
- `url_reachability_reason(URL, Reason)` (network_failure, client_error, server_error, redirect, success, http_error)

The Python side (`_check_url_reachability` in `backend/engine/rule_engine.py`) performs an HTTP HEAD, categorizes the response, and asserts these facts before inference.

### Rule ID organization

- 100-199: Reputation and Trust (whitelist)
- 200-299: URL Structure
- 300-399: Classification Thresholds
- 400-499: Domain Lexical
- 500-599: DNS Infrastructure
- 600-699: HTTP Behavior
- 700-799: DOM Analysis

Maintenance tips:

- Keep `caracteristicas_regras/3` in `kb_rules.pl` as the single source of truth for IDs, names, and scores
- Update gating lists when adding rules with applicability constraints
- Ensure tests reflect threshold changes and that gates don't hide needed signals
- Update `is_relevant_fact_for_rule/2` and `format_fact/2` in `motorInferencia.pl` when adding new fact types

### Behavior notes

- Whitelisted URLs: if a URL is on the whitelist, the engine short-circuits and skips further inference (explanations will only reflect the whitelist decision).
- Explanations: facts are formatted for readability, filtered to those relevant to each rule, and limited in number to keep results concise.

### Prolog knowledge base layout (current)

The Prolog engine auto-loads rules and fact extractors relative to `motorInferencia.pl`:

- `backend/engine/prolog/kb_rules.pl` — consolidated rule definitions and scores
- `backend/engine/prolog/kb_facts/*.pl` — feature extractors and fact formatters

No environment variables are required. The previous `base-conhecimento.txt` file was legacy and has been removed.

## Features & UX Improvements

- **Dual rule engines:** Toggle between Prolog and Drools scoring to compare heuristics instantly.
- **Chrome extension:** Browser extension for on-the-fly URL analysis without leaving the page.
- **Interactive rulebook:** Live list highlights which rules are active for the selected engine.
- **Persona insights:** `frontend/src/data/persona.json` feeds a profile card that summarizes a sample SOC analyst.
- **Responsive layout:** Hero, sidebar persona card, and analysis panel adapt across desktop, tablet, and mobile screens.
- **Enhanced feedback:** Inline loaders, error handling, and empty states keep analysts informed during evaluation.

## Usage

### Web Application

1. Choose a scoring engine (Prolog or Drools) to load the matching rule set.
2. Paste or type a suspicious URL and submit.
3. Review triggered rules, scores, and explanations in the results panel.
4. Reference the persona card for context on analyst goals and preferences.

### Chrome Extension

1. Click the extension icon in your Chrome toolbar.
2. Select your preferred engine (Drools or Prolog).
3. Either paste a URL or click "Use Current Page" to analyze the active tab.
4. View real-time risk assessment with detailed rule breakdowns.

The persona definition can be edited at `frontend/src/data/persona.json` to mirror your target users.

## Project Structure (excerpt)

```
backend/
	api/main.py                    FastAPI endpoint with dual engine support
	engine/rule_engine.py          Prolog inference engine integration
	engine/dom_analyzer.py         DOM analysis for phishing detection
	services/dns_service.py        DNS lookup and validation
	tests/test_knowledge_base.py   Offline KB validation
	tests/test_api.py              API E2E testing
frontend/
	src/components/                React UI (UrlSearch, PersonaCard, etc.)
	src/constants/engineRules.js   Rule metadata shared across components
	src/data/persona.json          Mock SOC persona displayed in the UI
extension/
	src/app/App.jsx                Chrome extension React UI
	src/services/droolsClient.js   Dual-engine API client
	manifest.json                  Extension configuration
	webpack.config.js              Build configuration
scripts/start-dev.ps1            Dev helper to run backend & frontend together
```

## Contributing

1. Create a feature branch from `main`.
2. Keep code modular and accessible; follow existing formatting and linting conventions.
3. Add or update tests where relevant (`python -m pytest backend/tests`).
4. For frontend work, run `npm start` (or `npm run build`) to validate before opening a pull request.
5. Submit a PR describing changes, testing performed, and any follow-up ideas.

Please open an issue first if you plan large architectural changes.

## License

This proof-of-concept is shared for academic evaluation and does not yet carry a formal license. Contact the maintainers before production use or redistribution.
