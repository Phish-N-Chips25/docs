const path = require('path');
const CopyWebpackPlugin = require('copy-webpack-plugin');
const webpack = require('webpack');

module.exports = {
  entry: {
    content: path.resolve(__dirname, 'src/contentScript.js'),
    popup: path.resolve(__dirname, 'src/popup.jsx')
  },
  output: {
    filename: '[name].js',
    path: path.resolve(__dirname, 'dist'),
    clean: true
  },
  resolve: {
    extensions: ['.js', '.jsx']
  },
  module: {
    rules: [
      {
        test: /\.jsx?$/,
        exclude: /node_modules/,
        use: {
          loader: 'babel-loader',
          options: {
            presets: [
              ['@babel/preset-env', { targets: 'defaults' }],
              ['@babel/preset-react', { runtime: 'automatic' }]
            ]
          }
        }
      },
      {
        test: /\.css$/i,
        use: [
          {
            loader: 'css-loader',
            options: {
              exportType: 'string'
            }
          }
        ]
      }
    ]
  },
  plugins: [
    new webpack.DefinePlugin({
      'process.env.DROOLS_API_URL': JSON.stringify(process.env.DROOLS_API_URL || 'http://localhost:8080'),
      'process.env.PROLOG_API_URL': JSON.stringify(process.env.PROLOG_API_URL || 'http://localhost:8000')
    }),
    new CopyWebpackPlugin({
      patterns: [
        { from: 'manifest.json', to: 'manifest.json' },
        { from: 'public/popup.html', to: 'popup.html' }
      ]
    })
  ],
  optimization: {
    splitChunks: false
  },
  devtool: 'source-map',
  performance: {
    hints: false
  }
};
