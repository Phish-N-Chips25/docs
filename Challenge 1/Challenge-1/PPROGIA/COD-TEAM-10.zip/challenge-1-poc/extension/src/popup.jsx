import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './app/App';
import styles from './app/App.css';

function injectStyles(cssText) {
  if (!cssText) {
    return;
  }
  const style = document.createElement('style');
  style.textContent = cssText;
  document.head.appendChild(style);
}

document.addEventListener('DOMContentLoaded', () => {
  injectStyles(styles);

  const container = document.getElementById('root');
  if (!container) {
    return;
  }

  const root = createRoot(container);
  root.render(<App surface="popup" />);
});
