import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './app/App';
import styles from './app/App.css';
import { ensureShadowRoot } from './utils/createShadowRoot';

const MOUNT_FLAG = '__pncDroolsExtensionMounted';

(function initialise() {
  if (window[MOUNT_FLAG]) {
    return;
  }
  window[MOUNT_FLAG] = true;

  const { mountPoint } = ensureShadowRoot(styles);
  const root = createRoot(mountPoint);
  root.render(<App surface="content" />);
})();
