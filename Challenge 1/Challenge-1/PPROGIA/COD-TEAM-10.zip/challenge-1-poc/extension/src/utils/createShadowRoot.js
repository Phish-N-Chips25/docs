const HOST_ID = 'pnc-drools-extension-root';

export function ensureShadowRoot(styleContent = '') {
  let host = document.getElementById(HOST_ID);
  if (host) {
    const shadow = host.shadowRoot;
    const mountPoint = shadow.querySelector('#pnc-extension-app');
    return { host, shadowRoot: shadow, mountPoint };
  }

  host = document.createElement('div');
  host.id = HOST_ID;
  host.style.all = 'initial';
  host.style.position = 'fixed';
  host.style.inset = '0';
  host.style.zIndex = '2147483645';
  host.style.width = '0';
  host.style.height = '0';

  const targetParent = document.body || document.documentElement;
  targetParent.appendChild(host);

  const shadowRoot = host.attachShadow({ mode: 'open' });
  const style = document.createElement('style');
  style.textContent = `:host { all: initial; }\n* { box-sizing: border-box; font-family: inherit; }\n${styleContent}`;
  shadowRoot.appendChild(style);

  const mountPoint = document.createElement('div');
  mountPoint.id = 'pnc-extension-app';
  shadowRoot.appendChild(mountPoint);

  return { host, shadowRoot, mountPoint };
}
