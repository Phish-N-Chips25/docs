param(
    [switch]$NoBrowser
)

$repoRoot = (Resolve-Path -Path (Join-Path -Path $PSScriptRoot -ChildPath "..")).Path
$backendDir = Join-Path -Path $repoRoot -ChildPath "backend"
$frontendDir = Join-Path -Path $repoRoot -ChildPath "frontend"

$backendCommand = @"
Set-Location -Path '$repoRoot'
if (Test-Path -Path '$backendDir\venv\Scripts\Activate.ps1') {
    . '$backendDir\venv\Scripts\Activate.ps1'
}
& '$backendDir\venv\Scripts\python.exe' -m uvicorn backend.api.main:app --reload --reload-dir '$backendDir'
"@

if ($NoBrowser) {
    $frontendCommand = @"
Set-Location -Path '$frontendDir'
$env:BROWSER = 'none'
npm start
"@
} else {
    $frontendCommand = @"
Set-Location -Path '$frontendDir'
npm start
"@
}

Write-Host "Starting backend watcher..."
$backendProcess = Start-Process -FilePath "pwsh" -ArgumentList "-NoExit", "-Command", $backendCommand -PassThru

Start-Sleep -Seconds 1

Write-Host "Starting frontend watcher..."
$frontendProcess = Start-Process -FilePath "pwsh" -ArgumentList "-NoExit", "-Command", $frontendCommand -PassThru

Write-Host "Backend PID: $($backendProcess.Id)"
Write-Host "Frontend PID: $($frontendProcess.Id)"
Write-Host "Press ENTER to stop both services."

try {
    [Console]::ReadLine() | Out-Null
}
finally {
    foreach ($process in @($frontendProcess, $backendProcess)) {
        if ($process -and -not $process.HasExited) {
            Write-Host "Stopping PID $($process.Id)..."
            Stop-Process -Id $process.Id -Force
        }
    }
}
