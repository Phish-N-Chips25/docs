from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Literal, Optional

from backend.engine.rule_engine import assess_risk, evaluate_url


app = FastAPI()

DROOLS_BASE_URL = "http://localhost:8080"

# Version marker for debugging
@app.get("/health")
async def health_check():
    return {"status": "ok", "version": "v2_with_debug", "timestamp": "2025-10-30"}

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class RuleResult(BaseModel):
    rule_name: str
    score: float
    details: str


class RedirectChainMetrics(BaseModel):
    hops: int
    classification: Literal["legitimate", "suspicious", "phishing"]
    confidence: Literal["high", "medium", "low"]
    diversity_ratio: float
    shortener_count: int
    depth_component: float
    diversity_component: float
    shortener_component: float
    reputation_component: float
    final_score: float
    final_url_length: int
    final_hostname: Optional[str] = None
    final_url: Optional[str] = None
    redirect_urls: List[str] = Field(default_factory=list)


class UrlAnalysisResponse(BaseModel):
    url: str
    results: List[RuleResult]
    risk_level: Literal["safe", "suspicious", "probable_phishing", "phishing"]
    risk_score: float
    redirect_hops: int
    redirect_metrics: Optional[RedirectChainMetrics] = None


class DroolsEvaluationRequest(BaseModel):
    url: str = Field(..., description="URL to submit to the Drools engine")


class DroolsEvaluationResponse(BaseModel):
    status: str
    score: float
    triggeredRules: dict


@app.post("/analyze-url", response_model=UrlAnalysisResponse)
async def analyze_url(
    url: str = Query(..., description="URL to analyze"),
):
    """Run the Prolog phishing rule engine for the provided URL."""
    
    try:
        results = evaluate_url(url)
    except Exception as e:
        print(f"[ERROR] evaluate_url failed: {e}")
        import traceback
        traceback.print_exc()
        results = []
    
    risk = assess_risk(results)
    
    # Ensure all results have a details field
    for result in results:
        if 'details' not in result or not result['details']:
            result['details'] = f"Rule triggered: {result.get('rule_name', 'unknown')}"
    
    return {
        "url": url,
        "results": results,
        "risk_level": risk["risk_level"],
        "risk_score": risk["risk_score"],
        "redirect_hops": 0,
        "redirect_metrics": None,
    }


@app.post("/drools/evaluate", response_model=DroolsEvaluationResponse)
async def proxy_drools_evaluation(payload: DroolsEvaluationRequest):
    """Forward evaluation requests to the Drools engine to avoid browser-side CORS issues."""

    import httpx

    try:
        async with httpx.AsyncClient(base_url=DROOLS_BASE_URL, timeout=10.0) as client:
            response = await client.post("/evaluate", json=payload.model_dump())
        response.raise_for_status()
    except httpx.HTTPStatusError as exc:
        detail = exc.response.text or "Drools engine returned an error response."
        raise HTTPException(status_code=exc.response.status_code, detail=detail)
    except httpx.RequestError as exc:
        raise HTTPException(status_code=502, detail=f"Drools engine unreachable: {exc}") from exc

    return response.json()
