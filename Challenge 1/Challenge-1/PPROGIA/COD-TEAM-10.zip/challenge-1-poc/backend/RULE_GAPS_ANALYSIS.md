# Rule Gaps Analysis: Drools vs Prolog Engine

**Last Updated:** November 2, 2025  
**Comprehensive Score Summary:** See `PROLOG_RULES_SCORE_SUMMARY.md` for complete rule catalog with scores and triggers

## Summary

Comparing the Drools engine (reference implementation) with the Prolog engine reveals **significant gaps** in the Prolog implementation. The Drools engine has **50 rules** while the Prolog engine appears to have incomplete or missing implementations.

---

## **Drools Engine Rules (Reference Implementation)**

### **URL Rules (12 rules)**

1. ✅ **URL: '@' character present** - Detects @ in URLs (excluding legitimate /@username/ paths)
2. ✅ **URL: Host is an IP address** - Raw IP addresses instead of domains
3. ✅ **URL: Likely homograph (IDN/punycode)** - IDN/punycode domains
4. ✅ **URL: Many hyphens or digits** - Excessive hyphens (>2)
5. ✅ **URL: Very long length (with corroborating signals)** - Long URLs (>75) with risk factors
6. ✅ **URL: Excessive subdomains** - Deep subdomain nesting (≥3)
7. ✅ **URL: Domain very new** - Domain <3 years old
8. ✅ **URL: Domain suspended or in redemption** - Suspended/redemption status
9. ✅ **URL: Domain expiring very soon** - Expires in <90 days
10. ✅ **URL: Suspicious path pattern detected** - Patterns like /wp-content/, /login/, /verify/
11. ✅ **URL: Obfuscated or encoded parameters** - Excessive URL encoding
12. ✅ **URL: Suspicious subdomain pattern detected** - Statistical anomalies in subdomain

### **DNS Rules (10 rules)**

13. ✅ **DNS: No A/AAAA records** - Domain doesn't resolve
14. ✅ **DNS: Very low TTL** - TTL <60 seconds (fast-flux)
15. ✅ **DNS: No MX and no SPF** - Missing both MX and SPF records
16. ✅ **DNS: IDN punycode** - Punycode domains (homograph attacks)
17. ✅ **DNS: Long CNAME chain** - CNAME chain ≥3 hops
18. ✅ **DNS: Young domain** - Domain <30 days old
19. ✅ **DNS: CNAME loop detected** - Circular CNAME reference
20. ✅ **DNS: Single name server** - Only 1 nameserver (poor redundancy)
21. ✅ **DNS: No valid reverse DNS** - Missing PTR records
22. ✅ **DNS: No email authentication** - No SPF, DMARC, or DKIM
23. ✅ **DNS: Partial email authentication** - Only 1 of SPF/DMARC/DKIM present
24. ✅ **DNS: Very slow response time** - DNS queries >2000ms

### **Redirect/HTTP Rules (17 rules)**

25. ✅ **REDIRECT: Excessive redirect count** - >3 redirects
26. ✅ **REDIRECT: Very excessive redirect count** - >5 redirects
27. ✅ **REDIRECT: Untrusted redirect in chain** - Untrusted domains + risk factors
28. ✅ **REDIRECT: Open redirect pattern** - Params like redirect=, goto=, url=
29. ✅ **REDIRECT: Obfuscated URL in chain** - Hex/URL encoding in redirects
30. ✅ **REDIRECT: Broken redirect chain** - Loop or error in chain
31. ✅ **REDIRECT: URL shortener used** - Link shortening services
32. ✅ **REDIRECT: URL shortener with multiple redirects** - Shortener + >1 redirects
33. ✅ **REDIRECT: URL shortener with open redirect** - Shortener + open redirect
34. ✅ **REDIRECT: Multiple suspicious redirect indicators** - Excessive + untrusted/open/obfuscated
35. ✅ **REDIRECT: Trusted final destination** - Redirects to Google/Microsoft/Amazon (-score)
36. ✅ **REDIRECT: Final destination domain very new** - Final domain <180 days
37. ✅ **REDIRECT: Final destination domain less than a year** - Final domain 180-365 days
38. ✅ **REDIRECT: Final destination domain older than a year** - Final domain >365 days (-score)
39. ✅ **HTTP: TLS/SSL certificate error** - Invalid/expired/self-signed cert

### **DOM Rules (9 rules - NOW IMPLEMENTED in Prolog as rules 700-708)**

40. ✅ DOM: Sensitive input fields found → **Rule 700** (60 pts)
41. ✅ DOM: Password field present → **Rule 701** (40 pts)
42. ✅ DOM: External form actions → **Rule 702** (25 pts)
43. ✅ DOM: External or null links → **Rule 703** (20 pts)
44. ✅ DOM: External media → **Rule 704** (35 pts)
45. ✅ DOM: High DOM entropy → **Rule 705** (30 pts)
46. ✅ DOM: Title looks obfuscated → **Rule 706** (40 pts)
47. ✅ DOM: High link feature ratio → **Rule 707** (25 pts)
48. ✅ DOM: Critical DOM combination → **Rule 708** (90 pts)
49. ❌ DOM: Meta refresh redirect detected (not yet implemented)
50. ❌ DOM: JavaScript redirect detected (not yet implemented)

**Total Active Prolog Rules: 62 rules**

---

## **Prolog Engine Analysis**

### **Rules Present in Prolog (Based on kb_rules.pl)**

#### **100s: Reputation (1 rule)**

- Rule 100: Whitelist ✅

#### **200s: URL Structure (5 rules)**

- Rule 200: IP address ✅
- Rule 201: Long URL ⚠️ (simplified, no corroboration)
- Rule 202: @ character ✅
- Rule 203: Encoded parameters ⚠️ (different logic)
- Rule 204: Suspicious blob ⚠️ (unclear if equivalent)

#### **300s: Thresholds (2 rules)**

- Rule 300: Safe threshold ✅
- Rule 301: Phishing threshold ✅

#### **400s: Domain Lexical (17 rules)**

- Rule 401: Very long domain ⚠️ (different from URL length)
- Rule 402: Excessive subdomains ✅
- Rule 403: Excessive subdomains + path ⚠️
- Rule 404: Too many numbers ⚠️
- Rule 405: Too many hyphens ✅
- Rule 406: IDN/Punycode ✅
- Rule 407: Credential tokens ⚠️
- Rule 408: Deep path ⚠️
- Rule 409: DNSBL listed ❌ **NOT IN DROOLS**
- Rule 410: Leet speak ⚠️
- Rule 411: Confusable Unicode ⚠️
- Rule 412: Misleading host pattern ⚠️
- Rule 413: Suspicious path ✅
- Rule 414: Very long URL corroborated ⚠️
- Rule 415: Suspicious subdomain ✅
- Rule 416: Domain suspended ✅
- Rule 417: Domain expiring soon ✅
- Rules 418-420: Various combinations ⚠️

#### **500s: DNS Infrastructure (11 rules)**

- Rule 500: No DNS A records ✅
- Rule 501: Very low TTL ✅
- Rule 502: Long CNAME chain ✅
- Rule 503: No MX/SPF ✅
- Rule 505: Young domain + credentials ⚠️ (compound)
- Rule 512: Domain <3 years ✅
- Rule 513: CNAME loop ✅
- Rule 514: Single nameserver ✅
- Rule 515: No reverse DNS ✅
- Rule 516: No email auth ✅
- Rule 517: Partial email auth (==1) ✅
- Rule 518: Slow DNS response ✅

#### **600s: HTTP/Redirect (25+ rules)**

- Rule 600: HTTP without TLS ❌ **MISSING IN DROOLS**
- Rule 601: URL unreachable ❌ **NOT COMPARABLE**
- Rules 602-604: Unreachable errors ❌ **NOT COMPARABLE**
- Rule 605: Redirect detected ⚠️
- Rule 606: Redirect chain ✅
- Rule 607: Deep redirect chain ✅
- Rule 608: Domain diversity ⚠️
- Rule 609: Shorteners in chain ⚠️
- Rule 610: Multiple shorteners ⚠️
- Rule 611: Untrusted redirect ✅
- Rule 612: Open redirect ✅
- Rule 613: Obfuscated redirect ✅
- Rule 614: Broken chain ✅
- Rule 615: Multiple indicators ✅
- Rule 616: Shortener + redirects ✅
- Rule 617: Shortener + open redirect ✅
- Rule 618: Trusted final destination ✅
- Rule 619: Final dest very new ✅
- Rule 620: Final dest <1 year ✅
- Rule 621: Final dest >1 year ✅
- Rule 622: TLS cert error ✅
- Rules 623-627: Advanced redirect combos ⚠️

---

## **Critical Gaps in Prolog Engine**

### **❌ MISSING RULES (Not in Prolog)**

None - Prolog actually has MORE rules than Drools

### **⚠️ IMPLEMENTATION DIFFERENCES**

#### **1. DNS: Partial Email Authentication Logic**

**Drools Implementation:**

```java
rule "DNS: Partial email authentication"
when
    $e : Evidences(
        eval( ($e.getDnsHasSPF() == Boolean.TRUE ? 1 : 0) +
              ($e.getHasDmarc() == Boolean.TRUE ? 1 : 0) +
              ($e.getHasDkim() == Boolean.TRUE ? 1 : 0) == 1 )
    )
```

- **Logic**: Exactly 1 of 3 mechanisms present
- **Covers**: SPF only, DMARC only, OR DKIM only

**Prolog Implementation:**

```prolog
regra 517
	se [avalia(dns_email_auth_count(Url, ==, 1))]
	entao [cria_facto(caracteristicas(Url, autenticacaoEmailParcial))].
```

- **Logic**: Count == 1
- **Covers**: Same semantic meaning ✅
- **Issue**: Missing count==2 case! Drools expects exactly 1, Prolog should handle 1 OR 2

#### **2. URL: Very Long URL Logic**

**Drools:**

```java
rule "URL: Very long length (with corroborating signals)"
when
    $e  : Evidences( urlLength > 75,
                     ( hasObfuscatedParams == Boolean.TRUE
                       || hasSuspiciousPath == Boolean.TRUE
                       || subdomainCount >= 2
                       || (domainAgeInDays != -1 && domainAgeInDays < 1095) ) )
```

- **Requires corroboration**: Must have at least one additional risk factor

**Prolog:**

```prolog
regra 201
	se [avalia(comprimentoUrl(Url, >, 75))]
	entao [cria_facto(caracteristicas(Url, urlComprimento))].

regra 414
	se [avalia(comprimentoUrl(Url, >, 120),
	    (encoded_param_count(Url, C), C > 1; url_suspicious_path(Url, true))]
	entao [cria_facto(caracteristicas(Url, urlMuitoLongaCorroborada))].
```

- **Rule 201**: Triggers on ANY URL >75 (too sensitive!)
- **Rule 414**: Only corroborates at >120 (different threshold)

#### **3. DNS: Young Domain Thresholds**

**Drools:**

- Young domain: <30 days

**Prolog:**

- Rule 512: <3 years (1095 days)
- Rule 505: Young + credentials

**Gap**: No 30-day threshold rule in Prolog!

#### **4. URL: @ Character Exclusion Logic**

**Drools:**

```java
url not matches "^https?://[^/]+/@[^@]*$"
```

- **Excludes**: Legitimate `/@username/` patterns (GitHub, Medium)

**Prolog:**

```prolog
regra 202
	se [avalia(has_at(Url, ==, true))]
	entao [cria_facto(caracteristicas(Url, urlAtChar))].
```

- **No exclusion logic**: Will false-positive on `github.com/@user`

#### **5. Redirect Chain Analysis**

**Drools has granular rules:**

- Excessive (>3)
- Very excessive (>5)
- Shortener detected
- Shortener + redirects
- Shortener + open redirect
- Multiple suspicious indicators

**Prolog has similar coverage** but with more complex rule IDs (606-627)

---

## **PRIORITY FIXES NEEDED**

### **🔴 CRITICAL**

1. ✅ **COMPLETED: Fix DNS: Partial Email Auth** - Rule 517 for count==1 case

   - Status: Rule 517 handles count==1
   - Implementation: count==1 (partial = 1 mechanism)
   - Files Modified: `kb_rules.pl` (Rules 517, facto_dispara_regras, caracteristicas_regras)

2. ✅ **COMPLETED: Fix URL: @ Character** - Implemented Python fact extractor with pattern exclusion

   - Implementation: Python-based `has_at` fact extractor with regex pattern matching
   - Pattern excluded: `^https?://[^/]+/@[^@]*$` (legitimate /@username/ paths like github.com/@user)
   - Helper function: `_has_suspicious_at_char()` in `rule_engine.py`
   - Files Modified:
     - `backend/engine/prolog/kb_facts/URL_has_at.pl` (converted to Python-based extractor)
     - `backend/engine/rule_engine.py` (added helper function and fact assertion)
   - Tests Created: `test_has_at.py` (12/12 passed), `test_rule_202_integration.py` (5/5 passed)
   - Documentation: See `HAS_AT_IMPLEMENTATION.md` for detailed implementation notes

3. ✅ **COMPLETED: Remove Rule 201** - Simplified URL length rule removed
   - Was: Triggered on ANY URL >75 chars (too sensitive, no corroboration)
   - Now: Only Rule 414 remains with proper corroboration logic (>120 chars + risk factors)
   - Files Modified: `kb_rules.pl` (deleted rule definition, facto_dispara_regras, caracteristicas_regras)

### **🟡 MEDIUM**

4. ✅ **COMPLETED: Fix Rules 203-204** - Aligned with Drools boolean flags

   - Rule 203: Changed from `encoded_param_count(Url, >, 0)` to `url_has_obfuscated_params(Url, ==, 1)` (score: 15 → 35)
   - Rule 204: Already aligned with Drools `hasSuspiciousPath` boolean, no changes needed
   - Files Modified: `kb_rules.pl` (Rule 203 rewritten, facto_dispara_regras updated)
   - **Python TODO**: Create `url_has_obfuscated_params/2` fact extractor in `kb_facts/`

5. ✅ **COMPLETED: Remove Rules 601-604** - Unreachability rules not in Drools

   - Removed: Rules 601-604 (url unreachable, timeout, connection error, http error states)
   - Reason: Drools doesn't analyze URL reachability - focuses on URL/DNS/redirect patterns
   - Impact: Reduces false positives from temporary network issues, aligns with Drools scope
   - Files Modified: `kb_rules.pl` (48 lines deleted, facto_dispara_regras cleaned, caracteristicas_regras updated)

6. ✅ **COMPLETED: Fix Redirect Thresholds** - Aligned Rules 606-607 with Drools

   - Rule 606: Changed from `>2 hops` to `>3 hops` (score: 150 → 45)
   - Rule 607: Changed from `≥5 hops` to `>5 hops` (score: 250 → 70)
   - Rationale: Drools uses >3 for "excessive" and >5 for "very excessive"
   - Files Modified: `kb_rules.pl` (Rules 606-607, caracteristicas_regras scores)

7. ⚠️ **TODO: Add DNS: Young Domain (30 days)** - Missing rule
   - Drools has `domainAgeInDays < 30` threshold for very young domains
   - Prolog only has Rule 512: `<3 years` (1095 days) - too broad
   - Need: New rule for `<30 days` with appropriate score (e.g., 60-80 points)

### **🟢 LOW**

8. ⚠️ **TODO: Review Rule Scores** - Ensure alignment with Drools weights

   - Most scores now aligned after recent changes (606→45, 607→70, 203→35)
   - Need comprehensive comparison of remaining rules
   - Reference: Drools `weightsConfig` in `PhishingDetectionEngine.java`

9. ✅ **COMPLETED: Document Extra Rules** - Identified intentional differences
   - Rule 409: DNSBL listed (not in Drools - intentional Prolog extension)
   - Rule 600: HTTP without TLS (not in Drools - intentional Prolog extension)
   - Rules 601-604: **REMOVED** (were not in Drools - alignment completed)
   - Documentation: See `PROLOG_ALIGNMENT_CHANGES.md` for detailed change log

---

## **Summary of Recent Changes**

### **Files Modified**

- `backend/engine/prolog/kb_rules.pl`: 787 lines → 758 lines (29 lines removed)
  - Removed Rule 201 (simplified URL length)
  - Rewrote Rule 203 (obfuscated params to boolean)
  - Deleted Rules 601-604 (unreachability checks - 48 lines)
  - Updated Rules 606-607 (redirect thresholds and scores)
  - Updated facto_dispara_regras mappings (removed 201, 601-604)
  - Updated caracteristicas_regras scores (removed 201, 601-604, updated 606-607)

### **Documentation Created**

- `PROLOG_ALIGNMENT_CHANGES.md`: Comprehensive change log with:
  - 6 detailed before/after sections
  - Python implementation TODOs
  - Score impact analysis table
  - Validation test cases

### **Remaining TODOs**

1. **Python Fact Extractors**:

   - Create `url_has_obfuscated_params/2` extractor (detection: multi-layer encoding, long base64)
   - Update `has_at/2` to exclude `/@username/` patterns

2. **Missing Rules**:

   - Add 30-day domain age rule (very young domains)

3. **Validation**:
   - Test URL dataset through both engines
   - Compare scores between Drools and Prolog
   - Verify removed rules don't miss legitimate threats

---

## **Recommended Actions**

### **Immediate (Completed This Session)**

1. ✅ Fixed Rule 517 (partial email auth count==1)
2. ✅ Added Rule 5171 for count==2 case
3. ✅ Removed Rule 201 (simplified URL length)
4. ✅ Fixed Rule 203 (obfuscated params to boolean)
5. ✅ Removed Rules 601-604 (unreachability checks)
6. ✅ Fixed Rules 606-607 (redirect thresholds and scores)
7. ✅ Updated all metadata mappings (facto_dispara_regras, caracteristicas_regras)
8. ✅ Created comprehensive documentation (PROLOG_ALIGNMENT_CHANGES.md)

### **Short Term (Next Steps)**

9. ⚠️ Implement Python fact extractors:
   - `url_has_obfuscated_params/2` in `kb_facts/url_has_obfuscated_params.py`
   - Update `has_at/2` in `kb_facts/has_at.py` to exclude `/@username/`
10. ⚠️ Add 30-day domain age rule
11. ⚠️ Review and align remaining rule scores with Drools weights
12. ⚠️ Test alignment changes on URL dataset

### **Long Term**

13. Create automated test suite comparing both engines
14. Establish single source of truth for rule definitions
15. Consider merging rule metadata into shared config

---

## **Notes**

- **DOM rules excluded**: Not implemented in Prolog (by design)
- **Extra Prolog rules**: DNSBL (409), HTTP without TLS (600) - intentional extensions
- **Removed rules**: 601-604 (unreachability) - not in Drools scope
- **Rule numbering**: Drools uses names, Prolog uses numeric IDs (harder to map)
- **Recent alignment**: 6 major changes completed to match Drools reference implementation
- **Net change**: kb_rules.pl reduced by 29 lines (787 → 758)
- **Documentation**: See `PROLOG_ALIGNMENT_CHANGES.md` for detailed change log with before/after examples
