"""
Knowledge Base Test - Tests the Prolog inference engine in offline mode

Displays all available rules, facts, and reasoning chains without requiring API.
Tests the core Prolog knowledge base and inference engine directly.

Usage:
    cd backend/tests
    python test_knowledge_base.py
"""
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from engine.rule_engine import evaluate_url, assess_risk
from pyswip import Prolog


def test_knowledge_base():
    """Test the knowledge base in offline mode."""
    
    print("=" * 80)
    print("KNOWLEDGE BASE TEST - PROLOG INFERENCE ENGINE")
    print("=" * 80)
    
    # Initialize engine
    print("\n[1] Initializing Prolog engine...")
    try:
        # Test that we can import and use the functions
        test_result = evaluate_url("https://github.com")
        print("[OK] Engine initialized successfully")
    except Exception as e:
        print(f"[ERROR] Failed to initialize engine: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    # Test URLs representing different risk profiles
    test_cases = [
        {
            'url': 'https://github.com',
            'description': 'Whitelisted legitimate site',
            'expected': 'SAFE'
        },
        {
            'url': 'https://phishing.xyz/account/verify',
            'description': 'Suspicious TLD + sensitive path',
            'expected': 'SUSPICIOUS'
        },
        {
            'url': 'http://192.168.1.1/login',
            'description': 'IP address with login path',
            'expected': 'SUSPICIOUS'
        },
        {
            'url': 'https://login.secure.account.verify.example.tk/reset',
            'description': 'Multiple subdomains + suspicious TLD + sensitive path',
            'expected': 'SUSPICIOUS/PHISHING'
        },
    ]
    
    print(f"\n[2] Testing {len(test_cases)} URL patterns...")
    print("=" * 80)
    
    for i, test_case in enumerate(test_cases, 1):
        print(f"\n--- Test Case {i}/{len(test_cases)} ---")
        print(f"URL: {test_case['url']}")
        print(f"Description: {test_case['description']}")
        print(f"Expected: {test_case['expected']}")
        print()
        
        try:
            # Analyze URL
            results = evaluate_url(test_case['url'])
            risk = assess_risk(results)
            
            # Display results
            print(f"Risk Level: {risk['risk_level']}")
            print(f"Risk Score: {risk['risk_score']}")
            print(f"Rules Triggered: {len(results)}")
            
            # Show all triggered rules
            if results:
                print("\nTriggered Rules:")
                for rule in sorted(results, key=lambda x: x.get('score', 0), reverse=True):
                    print(f"  [{rule.get('score', 0):>4} pts] {rule.get('rule_name', 'unknown')}")
                    if rule.get('details'):
                        print(f"             {rule['details']}")
            else:
                print("\n[WARNING] No rules triggered")
            
        except Exception as e:
            print(f"[ERROR] Analysis failed: {e}")
            import traceback
            traceback.print_exc()
    
    # Display available rules
    print("\n" + "=" * 80)
    print("[3] KNOWLEDGE BASE SUMMARY")
    print("=" * 80)
    
    try:
        # Initialize Prolog to query rules directly
        prolog = Prolog()
        kb_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'engine', 'prolog', 'kb_rules.pl'))
        prolog.consult(kb_path)
        
        print("\nQuerying all available rules from kb_rules.pl...")
        
        # Get rule categories based on actual rule IDs in kb_rules.pl
        categories = {
            'Whitelist/Blacklist': [100],
            'URL Structure Analysis': list(range(200, 205)),  # 200-204
            'Risk Thresholds': [300, 301],
            'URL/Domain Lexical Analysis': [401, 402, 403, 404, 405, 406, 407, 408, 409, 410, 411, 412],  # Skipping deleted 400
            'DNS-Based Analysis': [500, 501, 502, 503, 505, 512, 513, 514, 515, 516, 517, 518],  # Skipping deleted 504
            'Transport/Reachability': list(range(600, 606)),  # 600-605
            'Redirect Chain Analysis': list(range(606, 611)),  # 606-610
        }
        
        total_rules = sum(len(rules) for rules in categories.values())
        
        print(f"\nTotal Rules Available: {total_rules}")
        print("\nRules by Category:")
        
        for category, rule_ids in categories.items():
            print(f"\n  {category}:")
            for rule_id in rule_ids:
                try:
                    # Query rule from Prolog
                    query = f"caracteristicas_regras({rule_id}, Name, Score)"
                    results = list(prolog.query(query))
                    
                    if results:
                        rule_name = results[0].get('Name', 'Unknown')
                        score = results[0].get('Score', 0)
                        print(f"    [{rule_id}] {rule_name} ({score} pts)")
                    else:
                        print(f"    [{rule_id}] (not found in KB)")
                except Exception as e:
                    print(f"    [{rule_id}] (query error: {e})")
        
        # Query fact types
        print("\n" + "=" * 80)
        print("Fact Types Supported:")
        
        fact_types = [
            'dns_ttl', 'dns_suspicious_ttl', 'dns_young_domain', 'dns_dnsbl_listed',
            'redirect_chain_hops', 'redirect_diversity_ratio', 'redirect_shortener_count',
            'url_suspicious_tld', 'url_ip_address', 'url_subdomain_count',
            'dom_suspicious_forms', 'dom_hidden_elements'
        ]
        
        for fact_type in fact_types:
            print(f"  - {fact_type}")
        
    except Exception as e:
        print(f"[ERROR] Failed to query knowledge base: {e}")
        import traceback
        traceback.print_exc()
    
    print("\n" + "=" * 80)
    print("TEST COMPLETE")
    print("=" * 80)
    
    return True


if __name__ == "__main__":
    success = test_knowledge_base()
    sys.exit(0 if success else 1)
