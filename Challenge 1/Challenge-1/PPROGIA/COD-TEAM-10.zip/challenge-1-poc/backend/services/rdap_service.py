"""
RDAP/WHOIS Service (HTTP RDAP first, WHOIS fallback if available)
=================================================================
Provides domain registration metadata:
- Creation/registration date -> domain age days
- Expiration date -> days until expiration
- Status flags -> suspension/hold indicators

We prefer RDAP via public aggregator https://rdap.org to avoid extra dependencies.
If RDAP fails, we attempt a very lightweight WHOIS fallback if the optional
`whois` package is installed (skipped otherwise).
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional, Tuple
import re
import requests

ISO_FORMATS = [
    "%Y-%m-%dT%H:%M:%S%z",
    "%Y-%m-%dT%H:%M:%S.%f%z",
    "%Y-%m-%dT%H:%M:%SZ",
    "%Y-%m-%dT%H:%M:%S.%fZ",
]


@dataclass
class RDAPResult:
    created_at: Optional[datetime]
    expires_at: Optional[datetime]
    statuses: list

    @property
    def age_days(self) -> Optional[int]:
        if not self.created_at:
            return None
        now = datetime.now(timezone.utc)
        return max(0, (now - self.created_at).days)

    @property
    def days_until_expiration(self) -> Optional[int]:
        if not self.expires_at:
            return None
        now = datetime.now(timezone.utc)
        return max(0, (self.expires_at - now).days)


class RDAPService:
    def __init__(self, timeout: float = 3.0, base_url: str = "https://rdap.org"):
        self.timeout = timeout
        self.base_url = base_url.rstrip("/")

    def _parse_rdap_datetime(self, s: str) -> Optional[datetime]:
        s = (s or "").strip()
        if not s:
            return None
        # Normalize Z to +00:00 when needed
        if s.endswith("Z") and "+" not in s and "-" not in s[10:]:
            for fmt in ["%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%dT%H:%M:%S.%fZ"]:
                try:
                    dt = datetime.strptime(s, fmt)
                    return dt.replace(tzinfo=timezone.utc)
                except Exception:
                    pass
        for fmt in ["%Y-%m-%dT%H:%M:%S%z", "%Y-%m-%dT%H:%M:%S.%f%z"]:
            try:
                return datetime.strptime(s, fmt)
            except Exception:
                continue
        # Fallback: try plain date
        try:
            dt = datetime.strptime(s[:10], "%Y-%m-%d")
            return dt.replace(tzinfo=timezone.utc)
        except Exception:
            return None

    def lookup(self, domain: str) -> Optional[RDAPResult]:
        """Query RDAP and parse creation/expiration dates and statuses.
        Returns None on failure/timeouts.
        """
        try:
            url = f"{self.base_url}/domain/{domain}"
            resp = requests.get(url, timeout=self.timeout, headers={"User-Agent": "phish-n-chips/1.0"})
            if resp.status_code != 200:
                return None
            data = resp.json()
        except Exception:
            return None

        created_at = None
        expires_at = None
        statuses = data.get("status", []) or []

        # RDAP events can include creation/registration and expiration
        for evt in data.get("events", []) or []:
            action = (evt.get("eventAction") or "").lower()
            date_str = evt.get("eventDate") or evt.get("eventDateLdhName") or evt.get("eventDateRoid")
            if not date_str:
                continue
            dt = self._parse_rdap_datetime(date_str)
            if not dt:
                continue
            if action in ("registration", "creation"):
                if not created_at or dt < created_at:
                    created_at = dt
            elif action in ("expiration", "expiry"):
                expires_at = dt

        return RDAPResult(created_at=created_at, expires_at=expires_at, statuses=statuses)

    def is_suspended(self, result: RDAPResult) -> int:
        if not result:
            return 0
        statuses = [s.lower() for s in (result.statuses or [])]
        # Common RDAP statuses for suspension/hold/redeem
        indicators = [
            "serverhold", "clienthold", "redemptionperiod", "pendingdelete", "inactive",
        ]
        return 1 if any(any(ind in s for ind in indicators) for s in statuses) else 0

    def get_domain_metadata(self, domain: str) -> Tuple[Optional[int], Optional[int], int]:
        """Returns (age_days, days_until_expiration, suspended_flag)."""
        res = self.lookup(domain)
        if not res:
            return None, None, 0
        return res.age_days, res.days_until_expiration, self.is_suspended(res)
