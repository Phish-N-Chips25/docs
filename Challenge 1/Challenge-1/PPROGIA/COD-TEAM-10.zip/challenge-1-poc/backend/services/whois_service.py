"""
WhoisXML API client (whoisxmlapi.com)
=====================================
Fetches domain WHOIS data and extracts:
- created date (domain age in days)
- expiration date (days until expiration)
- suspension/hold indicators based on status flags

Environment:
- WHOISXML_API_KEY must be set to use this provider.

Docs:
https://www.whoisxmlapi.com/whois-api-doc.php
Endpoint (JSON):
  https://www.whoisxmlapi.com/whoisserver/WhoisService?apiKey=KEY&domainName=example.com&outputFormat=JSON
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Optional, Tuple
import os
import requests


DATE_FORMATS = [
    "%Y-%m-%dT%H:%M:%SZ",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%d",
    "%d-%b-%Y",  # e.g., 15-Feb-2024
    "%Y.%m.%d %H:%M:%S",
]


@dataclass
class WhoisResult:
    created_at: Optional[datetime]
    expires_at: Optional[datetime]
    statuses: list

    @property
    def age_days(self) -> Optional[int]:
        if not self.created_at:
            return None
        now = datetime.now(timezone.utc)
        return max(0, (now - self.created_at).days)

    @property
    def days_until_expiration(self) -> Optional[int]:
        if not self.expires_at:
            return None
        now = datetime.now(timezone.utc)
        return max(0, (self.expires_at - now).days)


class WhoisXmlApiService:
    def __init__(self, api_key: Optional[str] = None, timeout: float = 4.0,
                 base_url: str = "https://www.whoisxmlapi.com/whoisserver/WhoisService"):
        self.api_key = api_key or os.getenv("WHOISXML_API_KEY")
        self.timeout = timeout
        self.base_url = base_url

    def _parse_date(self, s: Optional[str]) -> Optional[datetime]:
        if not s:
            return None
        s = s.strip()
        # Normalize timezone-less to UTC when format has Z
        for fmt in DATE_FORMATS:
            try:
                dt = datetime.strptime(s, fmt)
                # Assume naive dates are UTC
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                return dt
            except Exception:
                continue
        return None

    def lookup(self, domain: str) -> Optional[WhoisResult]:
        if not self.api_key:
            return None
        try:
            params = {
                "apiKey": self.api_key,
                "domainName": domain,
                "outputFormat": "JSON",
            }
            resp = requests.get(self.base_url, params=params, timeout=self.timeout,
                                headers={"User-Agent": "phish-n-chips/1.0"})
            if resp.status_code != 200:
                return None
            data = resp.json()
        except Exception:
            return None

        record = data.get("WhoisRecord") or {}
        # Prefer registryData dates if present; fallback to top-level
        reg = record.get("registryData") or {}

        created = self._parse_date(reg.get("createdDate") or record.get("createdDate"))
        expires = self._parse_date(reg.get("expiresDate") or record.get("expiresDate"))

        statuses = []
        # statuses may appear in registryData.status or record.status (string or list)
        for src in (reg.get("status"), record.get("status")):
            if not src:
                continue
            if isinstance(src, list):
                statuses.extend([str(x) for x in src])
            else:
                statuses.append(str(src))

        return WhoisResult(created_at=created, expires_at=expires, statuses=statuses)

    def is_suspended(self, res: WhoisResult) -> int:
        if not res:
            return 0
        flags = [s.lower() for s in (res.statuses or [])]
        indicators = ["serverhold", "clienthold", "redemptionperiod", "pendingdelete", "inactive"]
        return 1 if any(any(ind in s for ind in indicators) for s in flags) else 0

    def get_domain_metadata(self, domain: str) -> Tuple[Optional[int], Optional[int], int]:
        res = self.lookup(domain)
        if not res:
            return None, None, 0
        return res.age_days, res.days_until_expiration, self.is_suspended(res)
