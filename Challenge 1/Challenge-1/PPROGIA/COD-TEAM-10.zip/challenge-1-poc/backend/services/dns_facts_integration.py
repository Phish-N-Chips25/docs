"""
DNS Facts Integration Module
=============================
Integrates DNS service results into the Prolog fact database.

This module provides functions to:
1. Query DNS information using DNSService
2. Assert DNS facts into the Prolog knowledge base
3. Update feature extractors to use Python DNS lookups
"""

from typing import Optional
from pyswip import Prolog
from services.dns_service import DNSService
import logging

logger = logging.getLogger(__name__)


class DNSFactsIntegration:
    """Integrates DNS service results into Prolog fact database"""
    
    def __init__(self, prolog: Prolog, dns_service: Optional[DNSService] = None):
        """
        Initialize DNS facts integration.
        
        Args:
            prolog: PySwip Prolog instance
            dns_service: DNSService instance (creates new one if None)
        """
        self.prolog = prolog
        self.dns_service = dns_service or DNSService()
        
    def assert_dns_facts(self, url: str) -> dict:
        """
        Perform DNS analysis and assert facts into Prolog.
        
        This method:
        1. Uses DNSService to analyze the URL
        2. Asserts the following facts into Prolog:
           - dns_a_record_exists(URL, Value)      [Rule 500]
           - dns_min_ttl(URL, Value)              [Rule 501]
           - dns_cname_chain_length(URL, Value)   [Rule 502]
           - dns_mx_exists(URL, Value)            [Rule 503]
           - dns_spf_dmarc(URL, Value)            [Rule 503]
           - dns_cname_loop(URL, Value)           [Rule 513]
           - dns_nameserver_count(URL, Value)     [Rule 514]
           - dns_reverse_dns_exists(URL, Value)   [Rule 515]
           - dns_email_auth_count(URL, Value)     [Rule 516-517]
           - dns_response_time_seconds(URL, Value) [Rule 518]
        
        Args:
            url: URL to analyze
            
        Returns:
            Dict with DNS analysis results and assertion status
        """
        # Perform DNS analysis
        dns_results = self.dns_service.analyze_domain(url)
        
        # Escape URL for Prolog (handle special characters)
        safe_url = url.replace("'", "\\'")
        
        # Assert facts into Prolog
        facts_asserted = []
        
        try:
            # Rule 500: dns_a_record_exists
            fact = f"dns_a_record_exists('{safe_url}', {dns_results['dns_a_record_exists']})"
            self.prolog.assertz(fact)
            facts_asserted.append(fact)
            
            # Rule 501: dns_min_ttl
            fact = f"dns_min_ttl('{safe_url}', {dns_results['dns_min_ttl']})"
            self.prolog.assertz(fact)
            facts_asserted.append(fact)
            
            # Rule 502: dns_cname_chain_length
            fact = f"dns_cname_chain_length('{safe_url}', {dns_results['dns_cname_chain_length']})"
            self.prolog.assertz(fact)
            facts_asserted.append(fact)
            
            # Rule 503: dns_mx_exists
            fact = f"dns_mx_exists('{safe_url}', {dns_results['dns_mx_exists']})"
            self.prolog.assertz(fact)
            facts_asserted.append(fact)
            
            # Rule 503: dns_spf_dmarc
            fact = f"dns_spf_dmarc('{safe_url}', {dns_results['dns_spf_dmarc']})"
            self.prolog.assertz(fact)
            facts_asserted.append(fact)
            
            # Rule 513: dns_cname_loop
            fact = f"dns_cname_loop('{safe_url}', {dns_results['dns_cname_loop']})"
            self.prolog.assertz(fact)
            facts_asserted.append(fact)
            
            # Rule 514: dns_nameserver_count
            fact = f"dns_nameserver_count('{safe_url}', {dns_results['dns_nameserver_count']})"
            self.prolog.assertz(fact)
            facts_asserted.append(fact)
            
            # Rule 515: dns_reverse_dns_exists
            fact = f"dns_reverse_dns_exists('{safe_url}', {dns_results['dns_reverse_dns_exists']})"
            self.prolog.assertz(fact)
            facts_asserted.append(fact)
            
            # Rule 516-517: dns_email_auth_count (only assert if >= 0; -1 means couldn't check)
            if dns_results['dns_email_auth_count'] >= 0:
                fact = f"dns_email_auth_count('{safe_url}', {dns_results['dns_email_auth_count']})"
                self.prolog.assertz(fact)
                facts_asserted.append(fact)
            
            # Rule 518: dns_response_time_seconds
            fact = f"dns_response_time_seconds('{safe_url}', {dns_results['dns_response_time_seconds']})"
            self.prolog.assertz(fact)
            facts_asserted.append(fact)
            
            logger.info(f"Asserted {len(facts_asserted)} DNS facts for {url}")
            
        except Exception as e:
            logger.error(f"Error asserting DNS facts for {url}: {e}")
            return {
                'success': False,
                'error': str(e),
                'dns_results': dns_results,
                'facts_asserted': facts_asserted
            }
        
        return {
            'success': True,
            'dns_results': dns_results,
            'facts_asserted': facts_asserted
        }
    
    def get_dns_facts_summary(self, url: str) -> dict:
        """
        Get summary of DNS facts for a URL without asserting them.
        
        Useful for testing and debugging.
        
        Args:
            url: URL to analyze
            
        Returns:
            Dict with DNS facts that would be asserted
        """
        dns_results = self.dns_service.analyze_domain(url)
        
        return {
            'url': url,
            'domain': dns_results['domain'],
            'facts': {
                'dns_a_record_exists': dns_results['dns_a_record_exists'],
                'dns_min_ttl': dns_results['dns_min_ttl'],
                'dns_cname_chain_length': dns_results['dns_cname_chain_length'],
                'dns_mx_exists': dns_results['dns_mx_exists'],
                'dns_spf_dmarc': dns_results['dns_spf_dmarc'],
                'dns_cname_loop': dns_results['dns_cname_loop'],
                'dns_nameserver_count': dns_results['dns_nameserver_count'],
                'dns_reverse_dns_exists': dns_results['dns_reverse_dns_exists'],
                'dns_email_auth_count': dns_results['dns_email_auth_count'],
                'dns_response_time_seconds': dns_results['dns_response_time_seconds']
            },
            'details': dns_results['details'],
            'errors': dns_results['errors']
        }


# Example usage and testing
if __name__ == '__main__':
    import sys
    from pyswip import Prolog
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Initialize Prolog and integration
    prolog = Prolog()
    integration = DNSFactsIntegration(prolog)
    
    # Test URLs
    test_urls = [
        'https://google.com',
        'https://example.com',
        'https://github.com',
    ]
    
    if len(sys.argv) > 1:
        test_urls = sys.argv[1:]
    
    for url in test_urls:
        print(f"\n{'='*70}")
        print(f"Testing DNS Facts Integration: {url}")
        print('='*70)
        
        # Get summary first
        summary = integration.get_dns_facts_summary(url)
        
        print(f"\nDomain: {summary['domain']}")
        print(f"\nFacts to be asserted:")
        for fact_name, fact_value in summary['facts'].items():
            print(f"  {fact_name} = {fact_value}")
        
        if summary['errors']:
            print(f"\nWarnings/Errors:")
            for error in summary['errors']:
                print(f"  - {error}")
        
        # Assert facts
        result = integration.assert_dns_facts(url)
        
        if result['success']:
            print(f"\n✓ Successfully asserted {len(result['facts_asserted'])} facts")
            
            # Verify by querying Prolog
            print(f"\nVerifying facts in Prolog:")
            for fact_name in summary['facts'].keys():
                safe_url = url.replace("'", "\\'")
                query = f"{fact_name}('{safe_url}', Value)"
                try:
                    solutions = list(prolog.query(query))
                    if solutions:
                        print(f"  ✓ {fact_name} = {solutions[0]['Value']}")
                    else:
                        print(f"  ✗ {fact_name} not found")
                except Exception as e:
                    print(f"  ✗ {fact_name} query failed: {e}")
        else:
            print(f"\n✗ Failed to assert facts: {result['error']}")
