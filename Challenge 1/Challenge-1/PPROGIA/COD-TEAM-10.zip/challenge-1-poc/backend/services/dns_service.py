"""
DNS Service for Phishing Detection
====================================
Provides DNS lookups and analysis to extract facts needed for rule evaluation.

This service supports the following DNS-based rules:
- Rule 16 (sem_dns_records): No DNS A/AAAA records
- Rule 17 (ttl_muito_baixo): Very low TTL values
- Rule 18 (cadeia_cname_longa): Long CNAME chains
- Rule 25 (sem_mx_spf): No MX and no SPF records
"""

import dns.resolver
import dns.exception
from typing import Dict, Any, Optional, List
from urllib.parse import urlparse
import logging

logger = logging.getLogger(__name__)


class DNSService:
    """Service for DNS lookups and analysis"""
    
    def __init__(self, timeout: float = 3.0):
        """
        Initialize DNS service with configurable timeout.
        
        Args:
            timeout: DNS query timeout in seconds (default: 3.0)
        """
        self.timeout = timeout
        self.resolver = dns.resolver.Resolver()
        self.resolver.lifetime = timeout

    def _get_txt_values(self, name: str) -> list:
        """
        Resolve TXT records for a name and return a list of decoded strings.

        Handles dnspython 1.x/2.x differences and joins split TXT chunks.
        Returns an empty list on NXDOMAIN/NoAnswer rather than raising.
        """
        try:
            answers = self.resolver.resolve(name, 'TXT')
        except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
            return []
        except Exception:
            # Any other error – treat as no values; callers may retry on other names
            return []

        values = []
        for rdata in answers:
            # dnspython 1.x exposes rdata.strings (list[bytes]); 2.x keeps it too
            if hasattr(rdata, 'strings'):
                try:
                    txt_value = b''.join(rdata.strings).decode('utf-8', errors='ignore')
                except Exception:
                    # Fallback to textual form
                    txt_value = rdata.to_text().strip('"')
            else:
                txt_value = rdata.to_text().strip('"')
            values.append(txt_value)
        return values
        
    def extract_domain(self, url: str) -> Optional[str]:
        """
        Extract domain from URL.
        
        Args:
            url: Full URL or domain name
            
        Returns:
            Domain name or None if extraction fails
        """
        try:
            # Handle both URLs and plain domains
            if not url.startswith(('http://', 'https://')):
                url = f'http://{url}'
            
            parsed = urlparse(url)
            domain = parsed.netloc or parsed.path
            
            # Remove port if present
            if ':' in domain:
                domain = domain.split(':')[0]
                
            return domain.lower() if domain else None
        except Exception as e:
            logger.error(f"Error extracting domain from {url}: {e}")
            return None
    
    def check_a_records(self, domain: str) -> Dict[str, Any]:
        """
        Check if domain has A or AAAA records (Rule 16: sem_dns_records).
        
        Args:
            domain: Domain name to check
            
        Returns:
            Dict with:
                - dns_a_record_exists: 1 if records exist, 0 otherwise
                - ip_addresses: List of resolved IP addresses
                - error: Error message if lookup failed
        """
        result = {
            'dns_a_record_exists': 0,
            'ip_addresses': [],
            'error': None
        }
        
        try:
            # Try A records (IPv4)
            try:
                answers = self.resolver.resolve(domain, 'A')
                result['ip_addresses'].extend([str(rdata) for rdata in answers])
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
                pass
            
            # Try AAAA records (IPv6)
            try:
                answers = self.resolver.resolve(domain, 'AAAA')
                result['ip_addresses'].extend([str(rdata) for rdata in answers])
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
                pass
            
            # Set exists flag if we found any IPs
            if result['ip_addresses']:
                result['dns_a_record_exists'] = 1
                
        except dns.resolver.NXDOMAIN:
            result['error'] = 'Domain does not exist'
        except dns.exception.Timeout:
            result['error'] = 'DNS query timeout'
        except Exception as e:
            result['error'] = f'DNS lookup error: {str(e)}'
            logger.error(f"A/AAAA record check failed for {domain}: {e}")
        
        return result
    
    def check_ttl(self, domain: str) -> Dict[str, Any]:
        """
        Check minimum TTL across DNS records (Rule 17: ttl_muito_baixo).
        
        Args:
            domain: Domain name to check
            
        Returns:
            Dict with:
                - dns_min_ttl: Minimum TTL value in seconds
                - record_ttls: Dict of record types and their TTL values
                - error: Error message if lookup failed
        """
        result = {
            'dns_min_ttl': None,
            'record_ttls': {},
            'error': None
        }
        
        record_types = ['A', 'AAAA', 'MX', 'NS', 'TXT']
        ttl_values = []
        
        try:
            for rtype in record_types:
                try:
                    answers = self.resolver.resolve(domain, rtype)
                    ttl = answers.rrset.ttl
                    result['record_ttls'][rtype] = ttl
                    ttl_values.append(ttl)
                except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
                    continue
            
            if ttl_values:
                result['dns_min_ttl'] = min(ttl_values)
            else:
                result['dns_min_ttl'] = -1  # No records found
                result['error'] = 'No DNS records found'
                
        except dns.resolver.NXDOMAIN:
            result['dns_min_ttl'] = -1
            result['error'] = 'Domain does not exist'
        except dns.exception.Timeout:
            result['dns_min_ttl'] = -1
            result['error'] = 'DNS query timeout'
        except Exception as e:
            result['dns_min_ttl'] = -1
            result['error'] = f'TTL check error: {str(e)}'
            logger.error(f"TTL check failed for {domain}: {e}")
        
        return result
    
    def check_cname_chain(self, domain: str, max_depth: int = 10) -> Dict[str, Any]:
        """
        Check CNAME chain length (Rule 18: cadeia_cname_longa).
        
        Args:
            domain: Domain name to check
            max_depth: Maximum chain depth to prevent infinite loops
            
        Returns:
            Dict with:
                - dns_cname_chain_length: Number of CNAME hops
                - cname_chain: List of domains in the chain
                - error: Error message if lookup failed
        """
        result = {
            'dns_cname_chain_length': 0,
            'cname_chain': [],
            'error': None
        }
        
        try:
            current_domain = domain
            visited = set()
            
            for _ in range(max_depth):
                if current_domain in visited:
                    result['error'] = 'CNAME loop detected'
                    break
                
                visited.add(current_domain)
                
                try:
                    answers = self.resolver.resolve(current_domain, 'CNAME')
                    cname = str(answers[0].target).rstrip('.')
                    result['cname_chain'].append(cname)
                    result['dns_cname_chain_length'] += 1
                    current_domain = cname
                except dns.resolver.NoAnswer:
                    # No more CNAMEs, end of chain
                    break
                except dns.resolver.NXDOMAIN:
                    result['error'] = f'CNAME target {current_domain} does not exist'
                    break
                    
        except dns.resolver.NXDOMAIN:
            result['error'] = 'Domain does not exist'
        except dns.exception.Timeout:
            result['error'] = 'DNS query timeout'
        except Exception as e:
            result['error'] = f'CNAME check error: {str(e)}'
            logger.error(f"CNAME check failed for {domain}: {e}")
        
        return result
    
    def check_mx_and_spf(self, domain: str) -> Dict[str, Any]:
        """
        Check for MX and SPF records (Rule 25: sem_mx_spf).
        
        Args:
            domain: Domain name to check
            
        Returns:
            Dict with:
                - dns_mx_exists: 1 if MX records exist, 0 otherwise
                - dns_spf_dmarc: 1 if SPF/DMARC records exist, 0 otherwise
                - mx_records: List of MX server names
                - spf_records: List of SPF records
                - error: Error message if lookup failed
        """
        result = {
            'dns_mx_exists': 0,
            'dns_spf_dmarc': 0,
            'mx_records': [],
            'spf_records': [],
            'error': None
        }
        
        try:
            # Check MX records
            try:
                answers = self.resolver.resolve(domain, 'MX')
                result['mx_records'] = [str(rdata.exchange).rstrip('.') for rdata in answers]
                if result['mx_records']:
                    result['dns_mx_exists'] = 1
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
                pass
            
            # Check SPF records (in TXT records)
            try:
                answers = self.resolver.resolve(domain, 'TXT')
                for rdata in answers:
                    txt_value = b''.join(rdata.strings).decode('utf-8', errors='ignore')
                    if txt_value.startswith('v=spf1') or txt_value.startswith('v=DMARC1'):
                        result['spf_records'].append(txt_value)
                
                if result['spf_records']:
                    result['dns_spf_dmarc'] = 1
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
                pass
                
        except dns.resolver.NXDOMAIN:
            result['error'] = 'Domain does not exist'
        except dns.exception.Timeout:
            result['error'] = 'DNS query timeout'
        except Exception as e:
            result['error'] = f'MX/SPF check error: {str(e)}'
            logger.error(f"MX/SPF check failed for {domain}: {e}")
        
        return result
    
    def check_cname_loop(self, domain: str) -> Dict[str, Any]:
        """
        Check for CNAME loops (circular CNAME chains).
        
        Args:
            domain: Domain name to check
            
        Returns:
            Dict with:
                - dns_cname_loop: 1 if loop detected, 0 otherwise
                - error: Error message if lookup failed
        """
        result = {
            'dns_cname_loop': 0,
            'error': None
        }
        
        try:
            seen_names = set()
            current_name = domain
            
            for _ in range(20):  # Max 20 iterations to detect loops
                if current_name in seen_names:
                    result['dns_cname_loop'] = 1
                    break
                    
                seen_names.add(current_name)
                
                try:
                    answers = self.resolver.resolve(current_name, 'CNAME')
                    # Get the target of the CNAME
                    current_name = str(answers[0].target).rstrip('.')
                except dns.resolver.NoAnswer:
                    # End of CNAME chain - no loop
                    break
                except dns.resolver.NXDOMAIN:
                    # Domain doesn't exist - no loop but broken chain
                    break
                    
        except dns.exception.Timeout:
            result['error'] = 'DNS query timeout'
        except Exception as e:
            result['error'] = f'CNAME loop check error: {str(e)}'
            logger.error(f"CNAME loop check failed for {domain}: {e}")
        
        return result
    
    def check_nameserver_count(self, domain: str) -> Dict[str, Any]:
        """
        Count authoritative nameservers for the domain.
        
        Args:
            domain: Domain name to check
            
        Returns:
            Dict with:
                - dns_nameserver_count: Number of NS records
                - nameservers: List of nameserver names
                - error: Error message if lookup failed
        """
        result = {
            'dns_nameserver_count': 0,
            'nameservers': [],
            'error': None
        }
        
        try:
            answers = self.resolver.resolve(domain, 'NS')
            result['nameservers'] = [str(rdata).rstrip('.') for rdata in answers]
            result['dns_nameserver_count'] = len(result['nameservers'])
                
        except dns.resolver.NoAnswer:
            result['error'] = 'No NS records found'
        except dns.resolver.NXDOMAIN:
            result['error'] = 'Domain does not exist'
        except dns.exception.Timeout:
            result['error'] = 'DNS query timeout'
        except Exception as e:
            result['error'] = f'NS check error: {str(e)}'
            logger.error(f"NS check failed for {domain}: {e}")
        
        return result
    
    def check_reverse_dns(self, domain: str) -> Dict[str, Any]:
        """
        Check if reverse DNS (PTR record) exists for domain's IP addresses.
        
        Args:
            domain: Domain name to check
            
        Returns:
            Dict with:
                - dns_reverse_dns_exists: 1 if any PTR found, 0 otherwise
                - ptr_records: List of PTR records found
                - error: Error message if lookup failed
        """
        result = {
            'dns_reverse_dns_exists': 0,
            'ptr_records': [],
            'error': None
        }
        
        try:
            # First get IP addresses
            ip_addresses = []
            try:
                answers = self.resolver.resolve(domain, 'A')
                ip_addresses.extend([str(rdata) for rdata in answers])
            except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
                pass
            
            if not ip_addresses:
                result['error'] = 'No A records to check reverse DNS'
                return result
            
            # Check PTR for each IP
            for ip in ip_addresses:
                try:
                    # Reverse the IP for PTR lookup
                    reversed_ip = dns.reversename.from_address(ip)
                    ptr_answers = self.resolver.resolve(reversed_ip, 'PTR')
                    result['ptr_records'].extend([str(rdata).rstrip('.') for rdata in ptr_answers])
                except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN):
                    pass
            
            if result['ptr_records']:
                result['dns_reverse_dns_exists'] = 1
                
        except dns.exception.Timeout:
            result['error'] = 'DNS query timeout'
        except Exception as e:
            result['error'] = f'Reverse DNS check error: {str(e)}'
            logger.error(f"Reverse DNS check failed for {domain}: {e}")
        
        return result
    
    def _apex_domain(self, domain: str) -> str:
        """
        Strip 'www.' prefix to get apex domain for email auth checks.
        
        Email authentication records (SPF, DMARC, DKIM) are typically 
        published at the apex domain, not subdomains.
        
        Args:
            domain: Domain name (may include www. prefix)
            
        Returns:
            Apex domain without www. prefix
        """
        if domain.startswith('www.'):
            return domain[4:]  # Remove 'www.' prefix
        return domain

    def check_email_auth_granular(self, domain: str) -> Dict[str, Any]:
        """
        Check email authentication mechanisms (SPF, DMARC, DKIM) separately.
        
        Email auth records are checked at the apex domain (e.g., example.com
        instead of www.example.com) because that's where they're typically published.
        
        Args:
            domain: Domain name to check
            
        Returns:
            Dict with:
                - dns_email_auth_count: 0-3 (number of mechanisms found)
                - has_spf: 1 if SPF found, 0 otherwise
                - has_dmarc: 1 if DMARC found, 0 otherwise
                - has_dkim: 1 if DKIM found, 0 otherwise
                - error: Error message if lookup failed
        """
        # Use apex domain for email auth checks (strip www.)
        apex = self._apex_domain(domain)
        
        result = {
            'dns_email_auth_count': 0,
            'has_spf': 0,
            'has_dmarc': 0,
            'has_dkim': 0,
            'error': None
        }
        
        try:
            # --- SPF --- (TXT at apex with v=spf1)
            for txt in self._get_txt_values(apex):
                if 'v=spf1' in txt.lower():
                    result['has_spf'] = 1
                    break

            # --- DMARC --- (TXT at _dmarc.<apex> with v=DMARC1)
            for txt in self._get_txt_values(f'_dmarc.{apex}'):
                if 'v=dmarc1' in txt.lower():
                    result['has_dmarc'] = 1
                    break

            # --- DKIM ---
            # Robust heuristic: check a set of common selectors and only
            # accept TXT values that look like real DKIM records (v=DKIM1 or p= keys).
            common_selectors = [
                'default', 'google', 'selector1', 'selector2', 'k1', 'dkim', 's1', 's2'
            ]
            found_selector = None
            for sel in common_selectors:
                name = f"{sel}._domainkey.{apex}"
                txts = self._get_txt_values(name)
                if any(('v=dkim1' in t.lower()) or (' p=' in (' ' + t.lower())) or (';p=' in t.lower()) for t in txts):
                    result['has_dkim'] = 1
                    found_selector = sel
                    break
                # Some providers publish DKIM via CNAME to vendor-managed keys
                try:
                    cname_ans = self.resolver.resolve(name, 'CNAME')
                    target = str(cname_ans[0].target).rstrip('.') if cname_ans else ''
                    if target and ('._domainkey.' in target or any(v in target for v in ['amazonses', 'sendgrid', 'mailgun', 'sparkpost', 'postmark'])):
                        result['has_dkim'] = 1
                        found_selector = sel
                        break
                except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN, dns.exception.Timeout):
                    pass

            # Count mechanisms
            result['dns_email_auth_count'] = result['has_spf'] + result['has_dmarc'] + result['has_dkim']

            # Provide minimal introspection for debugging/UI (non-rule data)
            result['details'] = {
                'apex_domain_used': apex,
                'dkim_selector_found': found_selector,
            }

        except dns.exception.Timeout:
            result['error'] = 'DNS query timeout'
            result['dns_email_auth_count'] = -1  # Sentinel: couldn't check
        except Exception as e:
            result['error'] = f'Email auth check error: {str(e)}'
            result['dns_email_auth_count'] = -1  # Sentinel: couldn't check
            logger.error(f"Email auth check failed for {apex}: {e}")
        
        return result
    
    def check_dns_response_time(self, domain: str) -> Dict[str, Any]:
        """
        Measure DNS query response time.
        
        Args:
            domain: Domain name to check
            
        Returns:
            Dict with:
                - dns_response_time_seconds: Response time in seconds (float)
                - error: Error message if lookup failed
        """
        import time
        
        result = {
            'dns_response_time_seconds': 0.0,
            'error': None
        }
        
        try:
            start_time = time.time()
            # Perform a simple A record query
            self.resolver.resolve(domain, 'A')
            end_time = time.time()
            
            result['dns_response_time_seconds'] = round(end_time - start_time, 3)
                
        except dns.resolver.NXDOMAIN:
            end_time = time.time()
            result['dns_response_time_seconds'] = round(end_time - start_time, 3)
            result['error'] = 'Domain does not exist'
        except dns.exception.Timeout:
            result['dns_response_time_seconds'] = self.timeout
            result['error'] = 'DNS query timeout'
        except Exception as e:
            result['error'] = f'DNS response time check error: {str(e)}'
            logger.error(f"DNS response time check failed for {domain}: {e}")
        
        return result
    
    def analyze_domain(self, url: str) -> Dict[str, Any]:
        """
        Perform comprehensive DNS analysis for a URL.
        
        This method runs all DNS checks and returns facts needed for rules:
        - Rule 500: dns_a_record_exists
        - Rule 501: dns_min_ttl
        - Rule 502: dns_cname_chain_length
        - Rule 503: dns_mx_exists, dns_spf_dmarc
        - Rule 513: dns_cname_loop
        - Rule 514: dns_nameserver_count
        - Rule 515: dns_reverse_dns_exists
        - Rule 516-517: dns_email_auth_count
        - Rule 518: dns_response_time_seconds
        
        Args:
            url: URL or domain to analyze
            
        Returns:
            Dict containing all DNS facts with keys:
                - domain: Extracted domain name
                - dns_a_record_exists: 0 or 1
                - dns_min_ttl: TTL value in seconds (-1 if no records)
                - dns_cname_chain_length: Number of CNAME hops
                - dns_mx_exists: 0 or 1
                - dns_spf_dmarc: 0 or 1
                - dns_cname_loop: 0 or 1
                - dns_nameserver_count: Number of nameservers
                - dns_reverse_dns_exists: 0 or 1
                - dns_email_auth_count: 0-3
                - dns_response_time_seconds: Response time in seconds
                - details: Nested dict with detailed results from each check
                - errors: List of error messages
        """
        domain = self.extract_domain(url)
        
        if not domain:
            return {
                'domain': None,
                'dns_a_record_exists': 0,
                'dns_min_ttl': -1,
                'dns_cname_chain_length': 0,
                'dns_mx_exists': 0,
                'dns_spf_dmarc': 0,
                'dns_cname_loop': 0,
                'dns_nameserver_count': 0,
                'dns_reverse_dns_exists': 0,
                'dns_email_auth_count': -1,  # Sentinel: couldn't check (no domain)
                'dns_response_time_seconds': 0.0,
                'details': {},
                'errors': ['Failed to extract domain from URL']
            }
        
        # Run all DNS checks
        a_records = self.check_a_records(domain)
        ttl_info = self.check_ttl(domain)
        cname_info = self.check_cname_chain(domain)
        mx_spf_info = self.check_mx_and_spf(domain)
        cname_loop_info = self.check_cname_loop(domain)
        ns_info = self.check_nameserver_count(domain)
        reverse_dns_info = self.check_reverse_dns(domain)
        email_auth_info = self.check_email_auth_granular(domain)
        response_time_info = self.check_dns_response_time(domain)
        
        # Collect errors
        errors = []
        for check_name, check_result in [
            ('A/AAAA records', a_records),
            ('TTL', ttl_info),
            ('CNAME chain', cname_info),
            ('MX/SPF', mx_spf_info),
            ('CNAME loop', cname_loop_info),
            ('Nameservers', ns_info),
            ('Reverse DNS', reverse_dns_info),
            ('Email auth', email_auth_info),
            ('DNS response time', response_time_info)
        ]:
            if check_result.get('error'):
                errors.append(f"{check_name}: {check_result['error']}")
        
        return {
            'domain': domain,
            'dns_a_record_exists': a_records['dns_a_record_exists'],
            'dns_min_ttl': ttl_info['dns_min_ttl'] if ttl_info['dns_min_ttl'] is not None else -1,
            'dns_cname_chain_length': cname_info['dns_cname_chain_length'],
            'dns_mx_exists': mx_spf_info['dns_mx_exists'],
            'dns_spf_dmarc': mx_spf_info['dns_spf_dmarc'],
            'dns_cname_loop': cname_loop_info['dns_cname_loop'],
            'dns_nameserver_count': ns_info['dns_nameserver_count'],
            'dns_reverse_dns_exists': reverse_dns_info['dns_reverse_dns_exists'],
            'dns_email_auth_count': email_auth_info['dns_email_auth_count'],
            'dns_response_time_seconds': response_time_info['dns_response_time_seconds'],
            'details': {
                'a_records': a_records,
                'ttl': ttl_info,
                'cname': cname_info,
                'mx_spf': mx_spf_info,
                'cname_loop': cname_loop_info,
                'nameservers': ns_info,
                'reverse_dns': reverse_dns_info,
                'email_auth': email_auth_info,
                'response_time': response_time_info
            },
            'errors': errors
        }


# Example usage and testing
if __name__ == '__main__':
    import sys
    
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Test the service
    service = DNSService()
    
    # Test domains
    test_urls = [
        'https://google.com',
        'https://example.com',
        'https://nonexistent-phishing-domain-12345.com',
        'http://192.168.1.1',
    ]
    
    if len(sys.argv) > 1:
        test_urls = sys.argv[1:]
    
    for url in test_urls:
        print(f"\n{'='*70}")
        print(f"Analyzing: {url}")
        print('='*70)
        
        result = service.analyze_domain(url)
        
        print(f"\nDomain: {result['domain']}")
        print(f"\nFacts for Rules:")
        print(f"  Rule 16 (sem_dns_records):")
        print(f"    dns_a_record_exists = {result['dns_a_record_exists']}")
        print(f"  Rule 17 (ttl_muito_baixo):")
        print(f"    dns_min_ttl = {result['dns_min_ttl']}")
        print(f"  Rule 18 (cadeia_cname_longa):")
        print(f"    dns_cname_chain_length = {result['dns_cname_chain_length']}")
        print(f"  Rule 25 (sem_mx_spf):")
        print(f"    dns_mx_exists = {result['dns_mx_exists']}")
        print(f"    dns_spf_dmarc = {result['dns_spf_dmarc']}")
        
        if result['errors']:
            print(f"\nErrors:")
            for error in result['errors']:
                print(f"  - {error}")
        
        print(f"\nDetailed Results:")
        print(f"  IP Addresses: {result['details']['a_records']['ip_addresses']}")
        print(f"  Record TTLs: {result['details']['ttl']['record_ttls']}")
        print(f"  CNAME Chain: {result['details']['cname']['cname_chain']}")
        print(f"  MX Records: {result['details']['mx_spf']['mx_records']}")
        print(f"  SPF Records: {result['details']['mx_spf']['spf_records']}")
