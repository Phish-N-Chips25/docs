from __future__ import annotations

import os
import sys
import json
import re
import unicodedata
import math
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
import socket
import ssl
from http.client import HTTPConnection, HTTPSConnection
from typing import Iterable, Mapping, Sequence
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin, urlparse
from urllib.request import Request, urlopen

from pyswip import Prolog

# Import DNS service for DNS fact integration
# Add parent directories to path to support different execution contexts
_current_dir = Path(__file__).resolve().parent
_backend_dir = _current_dir.parent
_project_root = _backend_dir.parent

if str(_project_root) not in sys.path:
    sys.path.insert(0, str(_project_root))
if str(_backend_dir) not in sys.path:
    sys.path.insert(0, str(_backend_dir))

try:
    from backend.services.dns_service import DNSService
    from backend.services.dns_facts_integration import DNSFactsIntegration
    from backend.services.rdap_service import RDAPService
    from backend.services.whois_service import WhoisXmlApiService
    DNS_SERVICE_AVAILABLE = True
    RDAP_SERVICE_AVAILABLE = True
    WHOIS_SERVICE_AVAILABLE = True
except ImportError as e1:
    try:
        from services.dns_service import DNSService
        from services.dns_facts_integration import DNSFactsIntegration
        from services.rdap_service import RDAPService
        from services.whois_service import WhoisXmlApiService
        DNS_SERVICE_AVAILABLE = True
        RDAP_SERVICE_AVAILABLE = True
        WHOIS_SERVICE_AVAILABLE = True
    except ImportError as e2:
        DNS_SERVICE_AVAILABLE = 'DNSService' in globals()
        RDAP_SERVICE_AVAILABLE = 'RDAPService' in globals()
        WHOIS_SERVICE_AVAILABLE = False
        print(f"[WARNING] DNS/RDAP/WHOIS service import issues:")
        print(f"  - backend.services: {e1}")
        print(f"  - services: {e2}")

# DOM analyzer (lightweight, requests+BS4)
try:
    from backend.engine.dom_analyzer import analyze_dom
    DOM_ANALYZER_AVAILABLE = True
    print("[INFO] DOM analyzer loaded successfully (backend.engine.dom_analyzer)")
except Exception as e1:
    try:
        from engine.dom_analyzer import analyze_dom
        DOM_ANALYZER_AVAILABLE = True
        print("[INFO] DOM analyzer loaded successfully (engine.dom_analyzer)")
    except Exception as e2:
        DOM_ANALYZER_AVAILABLE = False
        print(f"[WARNING] DOM analyzer not available:")
        print(f"  - backend.engine.dom_analyzer: {e1}")
        print(f"  - engine.dom_analyzer: {e2}")

KNOWN_WHITELISTED_DOMAINS = {"trusted.com", "isep.ipp.pt"}

# Redirect chain analysis constants
KNOWN_URL_SHORTENERS = {
    "bit.ly", "tinyurl.com", "t.co", "goo.gl", "ow.ly", 
    "is.gd", "cutt.ly", "amzn.to", "amzn.eu", "rebrand.ly",
    "short.link", "tiny.cc"
}
MAX_REDIRECT_HOPS = 10


def _get_url_parts(url: str) -> tuple[str | None, str | None, str | None]:
    """Parse URL into (host, path, query) components."""
    parsed = urlparse(url if url else "")
    host = (parsed.hostname or "").lower()
    path = parsed.path or "/"
    query = parsed.query or ""
    return host or None, path, query


def _build_request_path(parsed) -> str:
    path = parsed.path or "/"
    if parsed.query:
        path = f"{path}?{parsed.query}"
    return path


def _check_url_reachability(url: str) -> tuple[bool | None, int | None, str | None]:
    """
    Attempt a HEAD request to confirm the URL resolves.
    
    Returns:
        (reachable, status_code, reason)
        - reachable: True if 2xx/3xx, False if error/timeout, None if invalid URL
        - status_code: HTTP status code if available, None otherwise
        - reason: 'success', 'redirect', 'network_failure', 'client_error', 'server_error', 'http_error', or None
    """

    parsed = urlparse(url if url else "")
    scheme = (parsed.scheme or "").lower()
    host = parsed.hostname

    if not scheme or not host:
        return None, None, None

    if scheme == "https":
        connection_cls = HTTPSConnection
        default_port = 443
    elif scheme == "http":
        connection_cls = HTTPConnection
        default_port = 80
    else:
        return None, None, None

    port = parsed.port or default_port
    path = _build_request_path(parsed)
    headers = {"User-Agent": "phish-n-chips/1.0"}

    try:
        status, _ = _probe_redirect_location(connection_cls, host, port, path, headers)
        
        # Determine reachability and reason based on status code
        if 200 <= status < 300:
            return True, status, 'success'
        elif 300 <= status < 400:
            return True, status, 'redirect'
        elif 400 <= status < 500:
            return False, status, 'client_error'
        elif 500 <= status < 600:
            return False, status, 'server_error'
        else:
            return False, status, 'http_error'
            
    except (socket.timeout, ssl.SSLError, OSError, ValueError):
        return False, None, 'network_failure'


def _issue_connection_request(
    connection_cls: type[HTTPConnection],
    host: str,
    port: int,
    path: str,
    headers: Mapping[str, str],
    method: str,
) -> tuple[int, str | None]:
    connection = None
    try:
        connection = connection_cls(host, port, timeout=2)
        connection.request(method, path, headers=headers)
        response = connection.getresponse()
        status_code = response.status
        location_header = response.getheader("Location")
        return status_code, location_header
    finally:
        if connection is not None:
            try:
                connection.close()
            except Exception:
                pass


def _probe_redirect_location(
    connection_cls: type[HTTPConnection],
    host: str,
    port: int,
    path: str,
    headers: Mapping[str, str],
) -> tuple[int, str | None]:
    status, location = _issue_connection_request(connection_cls, host, port, path, headers, "HEAD")

    if status == 405:
        return _issue_connection_request(connection_cls, host, port, path, headers, "GET")

    if status >= 400 or (status in {301, 302, 303, 307, 308} and not location):
        # Some providers (e.g. Amazon short links) do not honour HEAD redirects;
        # fall back to a lightweight GET so we capture the Location header.
        return _issue_connection_request(connection_cls, host, port, path, headers, "GET")

    return status, location


def _escape_url(url: str) -> str:
    return url.replace("\\", "\\\\").replace("'", "\\'")


def _normalize_url_for_comparison(url: str) -> str:
    """Normalize URL for comparison (lowercase, remove trailing slash, remove fragment).
    Matches Drools RedirectChainService.normalizeUrl() logic.
    """
    try:
        parsed = urlparse(url if url else "")
        normalized = (parsed.scheme or "").lower() + "://" + \
                    (parsed.hostname or "").lower() + \
                    (":" + str(parsed.port) if parsed.port else "") + \
                    (parsed.path or "") + \
                    ("?" + parsed.query if parsed.query else "")
        
        # Remove trailing slash
        if normalized.endswith("/"):
            normalized = normalized[:-1]
        
        return normalized
    except Exception:
        return url.lower()


def _get_root_domain(url: str) -> str | None:
    """Extract root domain from URL (normalized, without www).
    Matches Drools RedirectChainService.getRootDomain() logic.
    """
    try:
        parsed = urlparse(url if url else "")
        host = (parsed.hostname or "").lower()
        if not host:
            return None
        
        # Remove www. prefix
        if host.startswith("www."):
            host = host[4:]
        
        return host
    except Exception:
        return None


def _get_second_level_label(host: str) -> str | None:
    """Extract second-level domain label (e.g., 'example' from 'example.com')."""
    try:
        parts = host.split(".")
        if len(parts) < 2:
            return None
        return parts[-2]
    except Exception:
        return None


def _levenshtein_distance(a: str, b: str) -> int:
    """Calculate Levenshtein edit distance between two strings."""
    n, m = len(a), len(b)
    if n == 0:
        return m
    if m == 0:
        return n
    
    # Create distance matrix
    dp = [[0] * (m + 1) for _ in range(n + 1)]
    
    # Initialize first column and row
    for i in range(n + 1):
        dp[i][0] = i
    for j in range(m + 1):
        dp[0][j] = j
    
    # Fill matrix
    for i in range(1, n + 1):
        for j in range(1, m + 1):
            cost = 0 if a[i-1] == b[j-1] else 1
            dp[i][j] = min(
                dp[i-1][j] + 1,      # deletion
                dp[i][j-1] + 1,      # insertion
                dp[i-1][j-1] + cost  # substitution
            )
    
    return dp[n][m]


def _is_brand_similar(root_a: str | None, root_b: str | None) -> bool:
    """Brand similarity heuristic between two root domains.
    Treats domains as similar if their SLDs match after removing hyphens/digits,
    or have edit distance <= 1 (e.g., coolmath-games.com -> coolmathgames.com).
    Matches Drools RedirectChainService.isBrandSimilar() logic.
    """
    if not root_a or not root_b:
        return False
    
    sld_a = _get_second_level_label(root_a)
    sld_b = _get_second_level_label(root_b)
    
    if not sld_a or not sld_b:
        return False
    
    # Normalize: lowercase and remove digits/hyphens
    norm_a = re.sub(r'[0-9-]', '', sld_a.lower())
    norm_b = re.sub(r'[0-9-]', '', sld_b.lower())
    
    if norm_a == norm_b:
        return True
    
    return _levenshtein_distance(norm_a, norm_b) <= 1


def _is_shortener_url(url: str) -> bool:
    """Heuristic shortener detection matching Drools ShortnerDetectorService.

    Indicators:
    - single-label domain (no subdomains)
    - very short SLD (1-5 chars)
    - short single-segment path (2-10 chars)
    - alphanumeric path, typically no query string
    Additionally, known shortener list is used as strong signal.
    """
    try:
        parsed = urlparse(url if url else "")
        parsed = urlparse(url if url else "")
        host = parsed.hostname or ""
        path = parsed.path or ""
        query = parsed.query or ""
        if not host:
            return False
        host_l = host.lower()
        if host_l.startswith("www."):
            host_l = host_l[4:]

        # Known list shortcut
        if host_l in KNOWN_URL_SHORTENERS:
            # Require not obviously long multi-segment path to avoid false positives
            clean_path = path.strip("/")
            if clean_path and "/" not in clean_path and len(clean_path) <= 20:
                return True

        parts = [p for p in host_l.split('.') if p]
        if len(parts) < 2:
            return False
        sld = parts[-2]
        is_single_label = len(parts) == 2

        # Path features
        clean_path = path.strip('/')
        single_segment = clean_path != "" and "/" not in clean_path
        short_path = single_segment and 2 <= len(clean_path) <= 10
        alpha_num_path = bool(re.fullmatch(r"[A-Za-z0-9_-]+", clean_path)) if clean_path else False
        no_query = query == ""

        has_short_domain = 1 <= len(sld) <= 5

        if is_single_label and has_short_domain and short_path and no_query:
            return True
        if is_single_label and has_short_domain and short_path and alpha_num_path:
            return True
    except Exception:
        return False
    return False


def _analyze_redirect_chain(url: str) -> dict[str, object]:
    """
    Follow HTTP redirects and analyze the redirect chain.
    
    Returns dict with:
        - hops: number of redirects
        - domains: list of domains in chain
        - unique_domains: count of unique domains
        - diversity_ratio: unique_domains / total_domains
        - shortener_count: number of URL shorteners in chain
        - final_url: final destination URL
        - redirect_urls: complete list of URLs in chain
        - open_redirect: 1 if open redirect params detected, 0 otherwise
        - obfuscated_url: 1 if hex/multi-encoding detected, 0 otherwise
        - chain_broken: 1 if loops/errors detected, 0 otherwise
        - untrusted_domain: 1 if any domain in chain fails trust checks, 0 otherwise
    """
    original_url = url or ""
    parsed_origin = urlparse(original_url)
    scheme = (parsed_origin.scheme or "").lower()
    host = parsed_origin.hostname

    if scheme not in {"http", "https"} or not host:
        return {
            "hops": 0,
            "domains": [],
            "unique_domains": 0,
            "diversity_ratio": 0.0,
            "shortener_count": 0,
            "final_url": original_url,
            "redirect_urls": [original_url],
            "open_redirect": 0,
            "obfuscated_url": 0,
            "chain_broken": 0,
            "untrusted_domain": 0,
        }

    current_url = original_url
    visited_urls: list[str] = []
    domains: list[str] = []
    seen: set[str] = set()
    seen.add(_normalize_url_for_comparison(current_url))
    open_redirect_detected = False
    obfuscated_detected = False
    chain_broken = False
    untrusted_detected = False
    

    headers = {"User-Agent": "phish-n-chips/1.0"}

    for _ in range(MAX_REDIRECT_HOPS):
        parsed = urlparse(current_url)
        scheme = (parsed.scheme or "").lower()
        host = parsed.hostname
        query = parsed.query or ""

        if scheme not in {"http", "https"} or not host:
            break

        # Check for open redirect generically: any parameter value that looks like an absolute URL
        if query:
            # detect ...=http://... or ...=https://... (also percent-encoded variants)
            if re.search(r"=(?:https?://|https?%3A%2F%2F)", query, flags=re.IGNORECASE):
                open_redirect_detected = True

        # Check for obfuscated/encoded URLs in query
        if query and ("%" in query or "\\x" in query):
            # Heuristic: multiple percent-encodings or hex escapes
            if query.count("%") > 5 or "\\x" in query:
                obfuscated_detected = True

        connection_cls = HTTPSConnection if scheme == "https" else HTTPConnection
        port = parsed.port or (443 if scheme == "https" else 80)
        path = _build_request_path(parsed)

        try:
            status, location = _probe_redirect_location(connection_cls, host, port, path, headers)
        except (socket.timeout, ssl.SSLError, OSError, ValueError):
            # Network error - mark chain as broken
            chain_broken = True
            break

        # Check if this is a redirect status code
        if status not in {301, 302, 303, 307, 308} or not location:
            break

        next_url = urljoin(current_url, location.strip())
        if not next_url or next_url == current_url:
            break

        # Normalize URL for loop detection (matches Drools logic)
        normalized_next = _normalize_url_for_comparison(next_url)
        if normalized_next in seen:
            # URL normalizes to same as previous - end of chain, NOT a broken loop
            # (e.g., trailing slash difference: https://example.com -> https://example.com/)
            break

        seen.add(normalized_next)
        visited_urls.append(next_url)
        
        # Analyze cross-domain redirect for untrusted pattern
        # Only flag as untrusted if redirecting to a DIFFERENT domain that's not brand-similar
        current_root = _get_root_domain(current_url)
        next_root = _get_root_domain(next_url)
        
        if current_root and next_root and current_root != next_root:
            # Cross-domain redirect detected
            if not _is_brand_similar(current_root, next_root):
                # Domains are not brand-similar - mark as untrusted
                untrusted_detected = True
        
        # Extract domain from this hop
        next_parsed = urlparse(next_url)
        next_domain = (next_parsed.hostname or "").lower()
        if next_domain:
            domains.append(next_domain)
        
        current_url = next_url
    
    # Check if we hit the hard limit (possible infinite loop)
    if len(visited_urls) >= MAX_REDIRECT_HOPS:
        chain_broken = True

    hops = len(visited_urls)
    unique_domains = len({d for d in domains if d})
    total_domains = len([d for d in domains if d])
    diversity_ratio = (unique_domains / total_domains) if total_domains > 0 else 0.0
    # Count shorteners using heuristics across the full redirect sequence
    shortener_count = 0
    redirect_sequence = [original_url] + visited_urls
    for u in redirect_sequence:
        try:
            if _is_shortener_url(u):
                shortener_count += 1
        except Exception:
            continue


    return {
        "hops": hops,
        "domains": domains,
        "unique_domains": unique_domains,
        "diversity_ratio": diversity_ratio,
        "shortener_count": shortener_count,
        "final_url": current_url,
        "redirect_urls": redirect_sequence,
        "open_redirect": 1 if open_redirect_detected else 0,
        "obfuscated_url": 1 if obfuscated_detected else 0,
        "chain_broken": 1 if chain_broken else 0,
        "untrusted_domain": 1 if untrusted_detected else 0,
    }


def _get_url_parts(url: str) -> tuple[str | None, str | None, str | None]:
    parsed = urlparse(url if url else "")
    host = (parsed.hostname or "").lower()
    path = parsed.path or "/"
    query = parsed.query or ""
    return host or None, path, query


def _count_encoded_params(query: str) -> int:
    if not query:
        return 0
    # Count percent-encodings like %2F
    return len(re.findall(r"%[0-9A-Fa-f]{2}", query))


def _has_suspicious_blob(query: str) -> bool:
    if not query:
        return False
    # Look for long base64/base64url-like tokens in query values
    # Heuristic: 40+ chars of [A-Za-z0-9+/_-], possibly ending with '=' padding
    return re.search(r"(?<![A-Za-z0-9_\-])[A-Za-z0-9+/_-]{40,}={0,2}(?![A-Za-z0-9_\-])", query) is not None


def _leet_substitution_count(host: str | None) -> int:
    if not host:
        return 0
    # Common leet mappings; count their occurrences in host labels (excluding dots)
    mappings = {
        '0': 'o', '1': 'li', '3': 'e', '4': 'a', '5': 's', '7': 't', '2': 'z', '8': 'b', '9': 'g',
        '@': 'a', '$': 's'
    }
    count = 0
    for ch in host:
        if ch in mappings:
            count += 1
    return count


def _decode_punycode_host(host: str) -> str:
    try:
        return host.encode("ascii", errors="ignore").decode("idna")
    except Exception:
        return host


def _confusable_char_count(host: str | None) -> int:
    if not host:
        return 0
    unicode_host = _decode_punycode_host(host)
    total = 0
    for ch in unicode_host:
        if ord(ch) > 127:
            cat = unicodedata.category(ch)
            if cat and cat[0] in ("L", "M"):
                total += 1
    return total


def _misleading_host_pattern(host: str | None) -> bool:
    if not host:
        return False
    labels = [lbl for lbl in host.split('.') if lbl]
    if len(labels) < 3:
        return False
    keywords = {"login", "secure", "account", "verify"}
    # Consider labels before the registrable domain (exclude last two labels)
    for lbl in labels[:-2]:
        if lbl.lower() in keywords:
            return True
    return False


def _has_suspicious_at_char(url: str) -> bool:
    """
    Check if URL contains suspicious '@' character.
    
    Returns True if '@' is present, EXCEPT for legitimate /@username/ patterns
    (e.g., https://github.com/@octocat, https://medium.com/@author).
    
    Drools exclusion pattern: ^https?://[^/]+/@[^@]*$
    
    Args:
        url: Full URL to check
        
    Returns:
        True if suspicious '@' found, False otherwise
    """
    if not url or '@' not in url:
        return False
    
    # Exclude legitimate /@username/ pattern
    # Pattern: protocol://host/@username (and optionally more path)
    # Match: ^https?://[^/]+/@[^@]*$
    legitimate_pattern = re.compile(r'^https?://[^/]+/@[^@]*$')
    
    if legitimate_pattern.match(url):
        return False
    
    # If @ exists but doesn't match the legitimate pattern, it's suspicious
    return True


def _registrable_domain(host: str | None) -> str | None:
    """Best-effort extraction of the registrable domain from a host.
    Avoids adding heavy PSL dependencies; handles common multi-label TLDs.
    """
    if not host:
        return None
    labels = [p for p in host.lower().split('.') if p]
    if len(labels) <= 2:
        return '.'.join(labels) if labels else None
    # Common multi-label public suffixes
    multi_suffixes = {
        'co.uk', 'ac.uk', 'gov.uk', 'org.uk', 'co.jp', 'ne.jp', 'or.jp', 'com.au', 'net.au', 'org.au',
        'com.br', 'net.br', 'org.br', 'com.tr', 'com.mx', 'com.ar', 'com.cn', 'com.hk',
    }
    last_two = '.'.join(labels[-2:])
    last_three = '.'.join(labels[-3:])
    if last_two in multi_suffixes and len(labels) >= 3:
        return '.'.join(labels[-3:])
    if last_three in multi_suffixes and len(labels) >= 4:
        return '.'.join(labels[-4:])
    return '.'.join(labels[-2:])


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    freq = {}
    for ch in s:
        freq[ch] = freq.get(ch, 0) + 1
    length = len(s)
    ent = 0.0
    for count in freq.values():
        p = count / length
        ent -= p * (0 if p == 0 else math.log2(p))
    return ent


def _check_suspicious_path(url: str) -> bool:
    """
    Statistical detection of suspicious URL path patterns, matching Drools logic.
    
    Uses entropy analysis, segment structure analysis, and statistical anomalies
    to identify obfuscated or malicious paths while avoiding false positives on
    legitimate hyphenated URLs.
    
    Statistical anomalies detected:
    1. High entropy + structural anomalies (short segments, no alpha-only tokens)
    2. Very short average segment length (< 5 chars) with multiple segments
    3. All segments are mixed alphanumeric (no semantic names)
    4. Multiple numeric-only segments (unusual pattern)
    """
    parsed = urlparse(url if url else "")
    path = parsed.path or "/"
    
    # Empty or root path is not suspicious
    if not path or path == "/":
        return False
    
    # Calculate entropy of full path
    path_entropy = _shannon_entropy(path)
    
    # Segment analysis
    segments = [seg for seg in path.split('/') if seg.strip()]
    if not segments:
        return False
    
    non_empty_segments = len(segments)
    total_length = sum(len(seg) for seg in segments)
    avg_length = total_length / non_empty_segments if non_empty_segments > 0 else 0
    
    # Classify segments
    alpha_only = 0
    numeric_only = 0
    mixed = 0
    
    for seg in segments:
        if re.match(r'^[a-zA-Z]+$', seg):
            alpha_only += 1
        elif re.match(r'^\d+$', seg):
            numeric_only += 1
        elif re.search(r'[a-zA-Z]', seg) and re.search(r'\d', seg):
            mixed += 1
    
    # STATISTICAL ANOMALY 1: High entropy (randomness/obfuscation)
    # BUT: Exclude legitimate hyphenated slugs (e.g., /user-name/article-title)
    # High entropy alone is insufficient; require EITHER:
    # - Very high entropy (>4.3) indicating true randomness, OR
    # - Moderate entropy (3.8-4.3) + structural indicators (short tokens, numeric mix, no alpha-only)
    high_entropy_with_structural_anomaly = False
    
    if path_entropy > 4.3:
        # Clearly random/obfuscated path
        high_entropy_with_structural_anomaly = True
    elif path_entropy > 3.8:
        # Moderate entropy - check for structural anomalies to avoid false positives
        # Legitimate paths like /user-name/article-title have high entropy but good structure
        # (longer average tokens, some alpha-only segments)
        if avg_length < 6 or (alpha_only == 0 and non_empty_segments >= 2):
            # Short average segment length OR no pure-alpha segments = likely obfuscated
            high_entropy_with_structural_anomaly = True
    
    if high_entropy_with_structural_anomaly:
        return True
    
    # STATISTICAL ANOMALY 2: Path with very short segments (minimal semantic value)
    # Normal: /products/ (avg 8), /contact/ (avg 7)
    # Suspicious: /img/rank/ (avg 3.5), /a/b/c/ (avg 1)
    if non_empty_segments >= 2 and avg_length < 5:
        return True
    
    # STATISTICAL ANOMALY 3: All segments are mixed alphanumeric (no semantic names)
    if non_empty_segments >= 2 and mixed >= 2 and alpha_only == 0:
        return True
    
    # STATISTICAL ANOMALY 4: Multiple numeric-only segments (unusual)
    if numeric_only >= 2 and alpha_only == 0:
        return True
    
    return False


def _check_tls_certificate_error(url: str) -> bool:
    """
    Check if HTTPS URL has TLS certificate errors (expired, self-signed, hostname mismatch).
    
    Returns True if certificate error detected, False otherwise.
    """
    parsed = urlparse(url if url else "")
    scheme = (parsed.scheme or "").lower()
    host = parsed.hostname
    
    if scheme != "https" or not host:
        return False
    
    port = parsed.port or 443
    
    try:
        context = ssl.create_default_context()
        # By default, this context will raise errors for invalid certs
        with socket.create_connection((host, port), timeout=2) as sock:
            with context.wrap_socket(sock, server_hostname=host) as ssock:
                # If we get here, cert is valid
                return False
    except (ssl.SSLError, ssl.CertificateError):
        # Certificate error detected
        return True
    except (socket.timeout, OSError, ValueError):
        # Network error or invalid host - not a cert error per se
        return False


def _analyze_final_destination(redirect_data: dict[str, object]) -> dict[str, object]:
    """
    Analyze the final destination of a redirect chain.
    
    Returns:
        - final_destination_trusted: 1 if final domain is in whitelist, 0 otherwise
        - final_destination_age_days: age of final domain in days (placeholder for now)
    """
    final_url = redirect_data.get("final_url", "")
    parsed_final = urlparse(final_url if final_url else "")
    final_host = (parsed_final.hostname or "").lower()
    
    # Check if final destination is trusted
    final_trusted = 1 if final_host in KNOWN_WHITELISTED_DOMAINS else 0
    
    # Domain age would require WHOIS lookup; placeholder for now
    # In production, integrate a WHOIS library or API
    final_age_days = -1  # -1 indicates unknown
    
    return {
        "final_destination_trusted": final_trusted,
        "final_destination_age_days": final_age_days,
    }


def _check_domain_dnsbl(host: str | None) -> bool:
    """
    Check if domain is listed in DNS-based blocklists.
    
    Queries:
    - Spamhaus DBL (Domain Block List)
    - SURBL (Spam URI Realtime Blocklists)
    
    Returns True if domain is listed in any DNSBL.
    """
    if not host:
        return False
    
    # Normalize host (remove port, lowercase)
    domain = host.lower().strip()
    if not domain or domain.startswith('['):  # Skip IPv6
        return False
    
    # Remove port if present
    if ':' in domain:
        domain = domain.split(':')[0]
    
    # List of DNSBL zones to check
    dnsbl_zones = [
        'dbl.spamhaus.org',      # Spamhaus Domain Block List
        'multi.surbl.org',        # SURBL multi (combines multiple lists)
    ]
    
    for zone in dnsbl_zones:
        query_name = f"{domain}.{zone}"
        try:
            # If the query succeeds, domain is listed
            # DNSBL returns 127.0.0.x responses for listed domains
            socket.gethostbyname(query_name)
            # If we get here, domain is listed
            return True
        except socket.gaierror:
            # DNS lookup failed - domain not listed in this DNSBL
            continue
        except Exception:
            # Other errors - skip this DNSBL
            continue
    
    return False


def evaluate_url_prolog(url: str):
    
    prolog = Prolog()

    file_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "prolog", "motorInferencia.pl"))

    try:
        prolog.consult(file_path)
    except Exception as e:
        print(f"[ERROR] Failed to consult Prolog file: {e}")
        import traceback
        traceback.print_exc()
        return []

    # Assert DNS facts BEFORE running inference
    if DNS_SERVICE_AVAILABLE:
        try:
            dns_service = DNSService(timeout=3.0)
            dns_integration = DNSFactsIntegration(prolog, dns_service)
            result = dns_integration.assert_dns_facts(url)
            if not result['success']:
                print(f"[WARNING] DNS facts assertion failed: {result.get('error', 'Unknown error')}")
        except Exception as e:
            print(f"[WARNING] DNS lookup failed: {e}")
            # Continue anyway - non-DNS rules will still work
    else:
        print("[INFO] DNS service not available - DNS-based rules will not fire")

    # Assert URL reachability facts (status and reason)
    try:
        reachable, status_code, reason = _check_url_reachability(url)
        safe_url = url.replace("'", "\\'")
        
        # Assert url_reachability/2
        if reachable is True:
            prolog.assertz(f"url_reachability('{safe_url}', reachable)")
        elif reachable is False:
            prolog.assertz(f"url_reachability('{safe_url}', unreachable)")
        
        # Assert url_reachability_status/2 if we have a status code
        if status_code is not None:
            prolog.assertz(f"url_reachability_status('{safe_url}', {status_code})")
        
        # Assert url_reachability_reason/2 if we have a reason
        if reason is not None:
            prolog.assertz(f"url_reachability_reason('{safe_url}', {reason})")
            
    except Exception as e:
        print(f"[WARNING] URL reachability check failed: {e}")
        # Continue anyway - other rules will still work

    # Assert additional URL/domain analysis facts
    try:
        host, path, query = _get_url_parts(url)
        safe_url = _escape_url(url)

        # @ character detection (Rule 202) - excluding legitimate /@username/ patterns
        has_at = 1 if _has_suspicious_at_char(url) else 0
        prolog.assertz(f"has_at('{safe_url}', {has_at})")

        # Encoded parameters count
        enc_count = _count_encoded_params(query or "")
        prolog.assertz(f"encoded_param_count('{safe_url}', {enc_count})")

        # Suspicious opaque blob in query
        has_blob = 1 if _has_suspicious_blob(query or "") else 0
        prolog.assertz(f"url_suspicious_blob('{safe_url}', {has_blob})")

        # Leet substitutions in host
        leet_count = _leet_substitution_count(host)
        prolog.assertz(f"leet_substitution_count('{safe_url}', {leet_count})")

        # Confusable Unicode characters in host
        confusables = _confusable_char_count(host)
        prolog.assertz(f"confusable_char_count('{safe_url}', {confusables})")

        # Misleading host pattern (login|secure|account|verify before registrable domain)
        mislead = 1 if _misleading_host_pattern(host) else 0
        prolog.assertz(f"misleading_host_pattern('{safe_url}', {mislead})")

        # Domain DNSBL reputation check
        dnsbl_listed = 1 if _check_domain_dnsbl(host) else 0
        prolog.assertz(f"domain_dnsbl_listed('{safe_url}', {dnsbl_listed})")

        # Redirect chain analysis
        redirect_data = _analyze_redirect_chain(url)
        prolog.assertz(f"redirect_chain_hops('{safe_url}', {redirect_data['hops']})")
        prolog.assertz(f"redirect_diversity_ratio('{safe_url}', {redirect_data['diversity_ratio']})")
        prolog.assertz(f"redirect_shortener_count('{safe_url}', {redirect_data['shortener_count']})")
        prolog.assertz(f"redirect_unique_domains('{safe_url}', {redirect_data['unique_domains']})")

        # Assert new redirect indicators
        prolog.assertz(f"redirect_untrusted_domain('{safe_url}', {redirect_data['untrusted_domain']})")
        prolog.assertz(f"redirect_open_redirect('{safe_url}', {redirect_data['open_redirect']})")
        prolog.assertz(f"redirect_obfuscated_url('{safe_url}', {redirect_data['obfuscated_url']})")
        prolog.assertz(f"redirect_chain_broken('{safe_url}', {redirect_data['chain_broken']})")

        # Analyze final destination
        final_dest_data = _analyze_final_destination(redirect_data)
        prolog.assertz(f"final_destination_trusted('{safe_url}', {final_dest_data['final_destination_trusted']})")

        # RDAP-based domain metadata (age, expiration, suspension)
        # Compute registrable domains for source and (if any) final destination
        base_host = host
        base_domain = _registrable_domain(base_host)
        final_url = redirect_data.get('final_url', url)
        final_host = (urlparse(final_url if final_url else '').hostname or '').lower()
        final_domain = _registrable_domain(final_host)

        rdap_age_days: int | None = None
        rdap_exp_days: int | None = None
        rdap_suspended: int = 0

        rdap_final_age_days: int | None = None

        if RDAP_SERVICE_AVAILABLE:
            try:
                rdap = RDAPService(timeout=3.0)
                if base_domain:
                    age, exp, susp = rdap.get_domain_metadata(base_domain)
                    rdap_age_days = age
                    rdap_exp_days = exp
                    rdap_suspended = susp
                if final_domain and (redirect_data.get('hops', 0) or base_domain != final_domain):
                    fage, _, _ = rdap.get_domain_metadata(final_domain)
                    rdap_final_age_days = fage
            except Exception as e:
                print(f"[WARNING] RDAP lookup failed: {e}")

        # WHOISXML fallback when RDAP missing/failed
        whois_api_key = os.getenv('WHOISXML_API_KEY')
        if WHOIS_SERVICE_AVAILABLE and whois_api_key and (rdap_age_days is None or rdap_exp_days is None or (redirect_data.get('hops', 0) and rdap_final_age_days is None)):
            try:
                whois = WhoisXmlApiService(api_key=whois_api_key, timeout=4.0)
                if base_domain and (rdap_age_days is None or rdap_exp_days is None):
                    age, exp, susp = whois.get_domain_metadata(base_domain)
                    if rdap_age_days is None:
                        rdap_age_days = age
                    if rdap_exp_days is None:
                        rdap_exp_days = exp
                    if not rdap_suspended:
                        rdap_suspended = susp
                if final_domain and (redirect_data.get('hops', 0)) and rdap_final_age_days is None:
                    fage, _, _ = whois.get_domain_metadata(final_domain)
                    rdap_final_age_days = fage
            except Exception as e:
                print(f"[WARNING] WHOIS lookup failed: {e}")

        # Assert dns_domain_age_days using RDAP if available, else safe default
        if isinstance(rdap_age_days, int) and rdap_age_days >= 0:
            prolog.assertz(f"dns_domain_age_days('{safe_url}', {rdap_age_days})")
        else:
            prolog.assertz(f"dns_domain_age_days('{safe_url}', 3650)")  # Safe default: 10 years

        # Assert expiration days and suspension using RDAP if available; keep safe defaults otherwise
        if isinstance(rdap_exp_days, int) and rdap_exp_days >= 0:
            prolog.assertz(f"dns_days_until_expiration('{safe_url}', {rdap_exp_days})")
        else:
            prolog.assertz(f"dns_days_until_expiration('{safe_url}', 90)")
        prolog.assertz(f"dns_domain_suspended('{safe_url}', {1 if rdap_suspended else 0})")

        # Assert final destination age days
        if redirect_data['hops'] > 0:
            if isinstance(rdap_final_age_days, int) and rdap_final_age_days >= 0:
                prolog.assertz(f"final_destination_age_days('{safe_url}', {rdap_final_age_days})")
            else:
                prolog.assertz(f"final_destination_age_days('{safe_url}', 3650)")
        else:
            # No redirects — use the same domain age (prefer RDAP age; fallback 3650)
            if isinstance(rdap_age_days, int) and rdap_age_days >= 0:
                prolog.assertz(f"final_destination_age_days('{safe_url}', {rdap_age_days})")
            else:
                prolog.assertz(f"final_destination_age_days('{safe_url}', 3650)")

        # Check for suspicious path patterns using statistical analysis
        # Uses entropy, segment structure, and statistical anomalies to detect obfuscated paths
        # Matches Drools logic: high entropy (>3.8) + structural indicators OR specific anomalies
        suspicious_path = 1 if _check_suspicious_path(url) else 0
        prolog.assertz(f"url_suspicious_path('{safe_url}', {suspicious_path})")

        # Check for TLS certificate errors
        tls_error = 1 if _check_tls_certificate_error(url) else 0
        prolog.assertz(f"http_tls_certificate_error('{safe_url}', {tls_error})")

    # RDAP-based assertions above already handled dns_domain_suspended, dns_days_until_expiration,
    # and dns_domain_age_days with safe fallbacks.

    except Exception as e:
        print(f"[WARNING] URL/domain analysis assertion failed: {e}")

    # Assert DOM analysis facts (lightweight) only for http(s) URLs and when analyzer is available
    try:
        parsed = urlparse(url if url else "")
        scheme = (parsed.scheme or "").lower()
        if DOM_ANALYZER_AVAILABLE and scheme in {"http", "https"}:
            dom = analyze_dom(url, timeout=4.0)
            safe_url = _escape_url(url)
            # Map returned fields into base facts that rules can use
            prolog.assertz(f"sensitive_fields_present('{safe_url}', {int(dom.get('sensitive_fields_count', 0))})")
            prolog.assertz(f"password_field_present('{safe_url}', {1 if dom.get('password_field_present', 0) else 0})")
            prolog.assertz(f"external_form_actions('{safe_url}', {int(dom.get('external_form_actions_count', 0))})")
            prolog.assertz(f"external_or_null_links('{safe_url}', {int(dom.get('external_or_null_links_count', 0))})")
            prolog.assertz(f"external_media('{safe_url}', {int(dom.get('external_media_count', 0))})")
            prolog.assertz(f"dom_entropy('{safe_url}', {float(dom.get('dom_entropy', 0.0))})")
            prolog.assertz(f"title_obfuscated('{safe_url}', {1 if dom.get('title_obfuscated', 0) else 0})")
            prolog.assertz(f"link_feature_ratio('{safe_url}', {float(dom.get('link_feature_ratio', 0.0))})")
            prolog.assertz(f"dependent_request_ratio('{safe_url}', {float(dom.get('dependent_request_ratio', 0.0))})")
    except Exception as e:
        print(f"[WARNING] DOM analysis assertion failed: {e}")
        import traceback
        traceback.print_exc()

    query = f"arranca_motor('{url}')."
    try:
        for _ in prolog.query(query):
            pass
    except Exception as e:
        print(f"[ERROR] Failed to execute Prolog query: {e}")
        import traceback
        traceback.print_exc()
        return []

    # Extract fired rules using explicacoes_regras_json/1
    results = []
    try:
        for sol in prolog.query("explicacoes_regras_json(JSONList)."):
            results = sol["JSONList"]
    except Exception as e:
        print(f"[ERROR] Failed to get Prolog explanations: {e}")
        import traceback
        traceback.print_exc()
        return []

    # Clean up result fields (handle bytes/encoding issues)
    for entry in results:
        rule_name = entry.get("rule_name", "")
        if isinstance(rule_name, (bytes, bytearray)):
            try:
                rule_name = rule_name.decode("utf-8", errors="ignore")
            except Exception:
                rule_name = str(rule_name)
        else:
            rule_name = str(rule_name)
        entry["rule_name"] = rule_name

        score_value = entry.get("score", 0)
        try:
            score = float(score_value)
        except (TypeError, ValueError):
            score = 0.0
        entry["score"] = score
        
        # Handle details field
        details = entry.get("details", "")
        if isinstance(details, (bytes, bytearray)):
            try:
                details = details.decode("utf-8", errors="ignore")
            except Exception:
                details = str(details)
        else:
            details = str(details)
        entry["details"] = details

    return results


def evaluate_url(url: str):
    """Evaluate a URL using the Prolog DSL inference engine.
    
    Returns a list of triggered rules with their scores.
    """
    return evaluate_url_prolog(url)


def assess_risk(rule_results: Sequence[Mapping[str, object]] | Sequence[dict[str, object]]):
    """Derive a simple risk score and level from triggered rule results."""

    if not rule_results:
        return {"risk_score": 0.0, "risk_level": "safe"}

    # Simple scoring based on Prolog rule scores
    # Each Prolog rule returns a numeric score
    total_score = 0.0
    
    for result in rule_results:
        score_value = result.get("score", 0)
        try:
            score = float(score_value)
        except (TypeError, ValueError):
            score = 0.0
        total_score += score

    # Map total score to risk level thresholds
    # Thresholds:
    #   - phishing:           score >= 150
    #   - probable_phishing:  100 <= score < 150
    #   - suspicious:         60 <= score < 100
    #   - safe (legitimate):  score < 60
    if total_score >= 150:
        risk_level = "phishing"
    elif total_score >= 100:
        risk_level = "probable_phishing"    
    elif total_score >= 60:
        risk_level = "suspicious"
    else:
        risk_level = "safe"

    return {"risk_score": round(total_score, 3), "risk_level": risk_level}
