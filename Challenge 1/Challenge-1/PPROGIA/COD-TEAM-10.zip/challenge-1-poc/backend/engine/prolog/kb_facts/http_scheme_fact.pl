% HTTP scheme fact extractor
% Detects if URL uses insecure HTTP instead of HTTPS

:- multifile feature_extractor/1.

% Register this extractor
feature_extractor(http_scheme_check).

% Check if URL starts with http:// (not https://)
http_scheme_check(URL) :-
    catch((
        (   sub_string(URL, 0, 7, _, "http://")
        ->  assertz(facto(_, http_scheme(URL, 1)))
        ;   assertz(facto(_, http_scheme(URL, 0)))
        )
    ), _, assertz(facto(_, http_scheme(URL, 0)))).
