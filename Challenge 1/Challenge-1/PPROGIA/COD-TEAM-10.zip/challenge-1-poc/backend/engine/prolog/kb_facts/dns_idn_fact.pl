% ============================================================================
% IDN PUNYCODE DETECTION FACT
% ============================================================================
% Detects Internationalized Domain Names (IDN) using punycode
% Returns: 1 if domain uses punycode (xn--), 0 otherwise
% ============================================================================

:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.

feature_extractor(dns_idn_check).

dns_idn_check(URL) :-
    ultimo_facto(N), ultima_caracteristica(C),
    retract(ultima_caracteristica(_)), C1 is C + 1, asserta(ultima_caracteristica(C1)),
    retract(ultimo_facto(_)), N1 is N + 1, asserta(ultimo_facto(N1)),
    dns_idn_punycode(URL, Result),
    assertz(facto(N1, dns_idn_punycode(URL, Result))).

% Fact extraction predicate
dns_idn_punycode(Url, HasIDN) :-
    extract_domain_from_url(Url, Domain),
    dns_idn_punycode_domain(Domain, HasIDN).

% Implementation: check for xn-- prefix in domain parts
dns_idn_punycode_domain(Domain, 1) :-
    atom_codes(Domain, Codes),
    contains_punycode(Codes),
    !.
dns_idn_punycode_domain(_, 0).

% Check if domain contains punycode markers
contains_punycode(Codes) :-
    % Look for "xn--" pattern in domain
    append(_, [120,110,45,45|_], Codes).  % "xn--" as ASCII codes

% Testing predicates
test_dns_idn_fact :-
    write('Testing DNS IDN punycode fact extraction...'), nl,
    dns_idn_punycode('https://example.com/path', IDN1),
    format('https://example.com/path -> Has IDN: ~w~n', [IDN1]),
    dns_idn_punycode('https://xn--e1afmkfd.xn--p1ai/', IDN2),
    format('https://xn--e1afmkfd.xn--p1ai/ -> Has IDN: ~w~n', [IDN2]),
    dns_idn_punycode('subdomain.xn--fsq.com', IDN3),
    format('subdomain.xn--fsq.com -> Has IDN: ~w~n', [IDN3]),
    dns_idn_punycode('normal-domain.com', IDN4),
    format('normal-domain.com -> Has IDN: ~w~n', [IDN4]),
    write('IDN domains use punycode (xn--) and can be abused for homograph attacks.'), nl.