% redirect_unique_domains_fact.pl
% Extractor for count of unique domains in redirect chain

facto_redirect_unique_domains(Url, Count) :-
    redirect_unique_domains(Url, Count).
