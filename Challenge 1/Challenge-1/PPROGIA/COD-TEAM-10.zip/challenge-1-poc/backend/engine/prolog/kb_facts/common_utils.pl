% Common utilities for fact extractors
:- module(kb_utils, [
    extract_host/2,
    extract_hostname/2,
    is_ip/1,
    valid_octet/1,
    extract_tld/2,
    suspicious_tld/1,
    extract_domain_without_tld/2,
    count_subdomains/2,
    count_numeric_chars/2,
    is_digit_char/1,
    count_hyphens/2,
    is_hyphen/1,
    extract_path/2,
    count_path_segments/2
]).

% Alias for compatibility
extract_hostname(URL, Hostname) :- extract_host(URL, Host), atom_string(Hostname, Host).

extract_host(URL, Host) :-
    ( sub_string(URL, 0, 7, _, "http://") -> sub_string(URL, 7, _, 0, Rest)
    ; sub_string(URL, 0, 8, _, "https://") -> sub_string(URL, 8, _, 0, Rest)
    ; Rest = URL
    ),
    split_string(Rest, "/?#", "", [HostWithPort|_]),
    ( sub_string(HostWithPort, _, _, _, "@")
    -> split_string(HostWithPort, "@", "", [_UserInfo, HostPort])
    ; HostPort = HostWithPort
    ),
    split_string(HostPort, ":", "", [Host|_]).


is_ip(Address) :-
    split_string(Address, ".", "", Parts),
    length(Parts, 4),
    maplist(valid_octet, Parts).

valid_octet(Part) :-
    catch(number_string(Number, Part), _, fail),
    Number >= 0, Number =< 255.

extract_tld(Host, TLD) :-
    split_string(Host, ".", "", Parts),
    Parts \= [], last(Parts, TLDString), string_lower(TLDString, TLD).

% Suspicious TLDs
suspicious_tld("tk").
suspicious_tld("ml").
suspicious_tld("ga").
suspicious_tld("cf").
suspicious_tld("gq").
suspicious_tld("xyz").
suspicious_tld("zip").
suspicious_tld("top").
suspicious_tld("click").
suspicious_tld("link").
suspicious_tld("loan").
suspicious_tld("download").
suspicious_tld("stream").

extract_domain_without_tld(Host, Domain) :-
    split_string(Host, ".", "", Parts), length(Parts, Len), Len >= 2,
    reverse(Parts, [_TLD|Rest]), reverse(Rest, [LastPart|_]), Domain = LastPart.

count_subdomains(Host, Count) :-
    split_string(Host, ".", "", Parts), length(Parts, Len), Len >= 2,
    Count is max(0, Len - 2).

count_numeric_chars(String, Count) :-
    string_chars(String, Chars), include(is_digit_char, Chars, Digits), length(Digits, Count).

is_digit_char(Char) :- char_type(Char, digit).

count_hyphens(String, Count) :-
    string_chars(String, Chars), include(is_hyphen, Chars, Hyphens), length(Hyphens, Count).

is_hyphen('-').

extract_path(URL, Path) :-
    split_string(URL, "?#", "", [URLWithoutQuery|_]),
    (   sub_string(URLWithoutQuery, Idx, _, _, "/"), Idx > 7
    ->  sub_string(URLWithoutQuery, Idx, _, 0, Path)
    ;   Path = "/"
    ).

count_path_segments(Path, Depth) :-
    split_string(Path, "/", "", Segments), exclude(=(""), Segments, NonEmpty), length(NonEmpty, Depth).
