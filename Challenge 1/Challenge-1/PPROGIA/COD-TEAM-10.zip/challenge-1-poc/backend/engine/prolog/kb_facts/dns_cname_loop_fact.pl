% ============================================================================
% DNS CNAME LOOP DETECTION FACT
% ============================================================================
% Detects circular CNAME chains (loop detection)
% 
% This file declares the dynamic predicate that Python will assert.
% No feature_extractor needed - kb_rules.pl queries this directly via avalia().
%
% Predicate: dns_cname_loop/2
%   Args: dns_cname_loop(URL, HasLoop)
%   Values: HasLoop = 1 if CNAME loop detected, 0 otherwise
%
% Asserted by: DNSFactsIntegration.assert_dns_facts() in dns_facts_integration.py
% Queried by: Rule 513 (loop_cname) in kb_rules.pl
% ============================================================================

:- dynamic dns_cname_loop/2.
