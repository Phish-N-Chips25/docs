% TLS certificate error fact
:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.
:- dynamic http_tls_certificate_error/2.

feature_extractor(tls_certificate_error_check).

tls_certificate_error_check(URL) :-
    (   ultimo_facto(N0) -> true ; N0 = 0 ),
    (   ultima_caracteristica(C0) -> true ; C0 = 0 ),
    retractall(ultima_caracteristica(_)), C1 is C0 + 1, asserta(ultima_caracteristica(C1)),
    retractall(ultimo_facto(_)), N1 is N0 + 1, asserta(ultimo_facto(N1)),
    (   http_tls_certificate_error(URL, V) -> assertz(facto(N1, http_tls_certificate_error(URL, V))) ; assertz(facto(N1, http_tls_certificate_error(URL, 0))) ).
