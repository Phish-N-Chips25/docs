% Engine core for modular rules/facts with custom DSL
% Operators for rule DSL
:- op(220, xfx, entao).
:- op(35,  xfy, se).
:- op(240, fx,  regra).
:- op(500, fy,  nao).
:- op(600, xfy, e).

% Dynamics
:- use_module(library(aggregate)).

:- dynamic justifica/3.
:- dynamic regra_disparada/2.
:- dynamic ultimo_facto/1.
:- dynamic ultima_caracteristica/1.
:- dynamic score_total/1.
:- dynamic facto/2.
:- dynamic current_url/1.
:- dynamic regra/1.
:- dynamic python_fact/2.

% Multifile registries (populated by kb_facts/ and kb_rules/)
:- multifile feature_extractor/1.
:- multifile facto_dispara_regras/2.
:- multifile caracteristicas_regras/3.
:- multifile regra/1.
:- multifile user:file_search_path/2.
:- dynamic  user:file_search_path/2.

% Initial state
ultimo_facto(0).
ultima_caracteristica(0).
score_total(0).

% -------- Path helpers --------
:- dynamic cached_base_dir/1.

% Cache the base directory during file loading
:- prolog_load_context(directory, Dir), assertz(cached_base_dir(Dir)).

join_path(Dir, Sub, Path) :-
    atomic_list_concat([Dir, '/', Sub], Path).

get_base_dir(Base) :-
    % Get cached base directory that was set during load
    cached_base_dir(Base).

% -------- Loaders --------
carrega_base_conhecimento :-
    carrega_regras,
    carrega_factos.

carrega_regras :-
    get_base_dir(Base),
    % Load consolidated rules file
    join_path(Base, 'kb_rules.pl', RulesFile),
    ( exists_file(RulesFile) -> consult(RulesFile) ; true ).

carrega_factos :-
    get_base_dir(Base),
    join_path(Base, 'kb_facts', FactsDir),
    % ensure alias so use_module(kb_facts/...) works inside fact files
    asserta(user:file_search_path(kb_facts, FactsDir)),
    atomic_list_concat([FactsDir, '/common_utils.pl'], UtilsPath),
    (   exists_file(UtilsPath) -> use_module(UtilsPath) ; true),
    atomic_list_concat([FactsDir, '/*.pl'], Pattern),
    expand_file_name(Pattern, Files0),
    exclude(is_common_utils, Files0, Files),
    maplist(consult, Files).

is_common_utils(File) :-
    file_base_name(File, Base),
    Base == 'common_utils.pl'.

% -------- Feature extraction --------
averigua_caracteristicas(URL) :-
    forall(feature_extractor(Pred),
           (Goal =.. [Pred, URL],
            (catch(Goal, _, fail) -> true ; true))).

% -------- Inference engine entry --------
arranca_motor(URL) :-
    reset_engine,
    asserta(current_url(URL)),
    carrega_base_conhecimento,
    % seed score fact at 0
    next_fact_index(N1),
    assertz(facto(N1, score_URL(URL, 0))),
    % extract facts
    averigua_caracteristicas(URL),
    % Check if URL is whitelisted - if so, only fire whitelist rule
    (   url_is_whitelisted(URL) ->
        fire_whitelist_rule_only
    ;   % Otherwise, run full inference
        inferate_fixpoint
    ).

% Check if URL is whitelisted
url_is_whitelisted(URL) :-
    facto(_, url_whitelisted(URL, 1)).

% Fire only the whitelist rule and skip other inference
fire_whitelist_rule_only :-
    % Check if already fired to prevent duplicates
    \+ regra_disparada(100, _),
    % Find the whitelist rule ID and score
    caracteristicas_regras(100, whitelist, Score),
    % Collect whitelisted fact
    findall(N, facto(N, url_whitelisted(_, 1)), FactList),
    FactList \= [],  % Make sure we found the fact
    % Mark rule as fired with the facts
    assertz(regra_disparada(100, FactList)),
    % Add whitelist score
    add_score(Score),
    !.  % Cut to prevent backtracking
fire_whitelist_rule_only.  % Succeed even if already fired

inferate_fixpoint :-
    fact_count(C1),
    forall(facto(N, F),
           (   (facto_dispara_regras(F, IDs) -> true ; IDs = []),
               dispara_regras(N, F, IDs))),
    fact_count(C2),
    (C1 == C2 -> true ; inferate_fixpoint).

fact_count(C) :-
    aggregate_all(count, facto(_, _), C).

% -------- Rule firing --------
dispara_regras(N, Facto, [ID|LRegras]):-
    regra ID se LHS entao RHS,
    % Gating: skip rules that are not applicable in current context
    \+ should_skip_rule(ID),
    facto_esta_numa_condicao(Facto,LHS),
    verifica_condicoes(LHS, LFactos),
    member(N,LFactos),
    % Check if this rule has already fired (regardless of facts)
    \+ regra_disparada(ID, _),
    Facto =.. [Functor | _],
    (   Functor \= score_URL ->
        (   caracteristicas_regras(ID,_, Score)
        ->  add_score(Score),
            % Track that this rule fired
            assertz(regra_disparada(ID, LFactos))
        ;   true)
    ;   true
    ),
    concluir(RHS,ID,LFactos),!,
    dispara_regras(N, Facto, LRegras).

dispara_regras(N, Facto, [_|LRegras]):-
    dispara_regras(N, Facto, LRegras).

dispara_regras(_, _, []).

% -------- Matching and evaluation --------
facto_esta_numa_condicao(F,[F  e _]).
facto_esta_numa_condicao(F,[avalia(F1)  e _]):-
    F=..[X,X1|_],F1=..[X,X1|_].
facto_esta_numa_condicao(F,[_ e Fs]):-
    facto_esta_numa_condicao(F,[Fs]).
facto_esta_numa_condicao(F,[F]).
facto_esta_numa_condicao(F,[avalia(F1)]):-
    F=..[X,X1|_],F1=..[X,X1|_].

verifica_condicoes([X e Y],[N|LF]):-
    facto(N,X),!,
    verifica_condicoes([Y],LF).
verifica_condicoes([avalia(X) e Y],[N|LF]):-
    avalia(N,X),!,
    verifica_condicoes([Y],LF).
verifica_condicoes([X],[N]):- facto(N,X),!.
verifica_condicoes([avalia(X)],[N]):- avalia(N,X).

avalia(N,P):-
    P=..[Functor,Entidade,Operando,Valor],
    P1=..[Functor,Entidade,Valor1],
    facto(N,P1),
    compara(Valor1,Operando,Valor).

compara(V1,==,V):- V1==V.
compara(V1,\==,V):- V1\==V.
compara(V1,>,V):-V1>V.
compara(V1,<,V):-V1<V.
compara(V1,>=,V):-V1>=V.
compara(V1,=<,V):-V1=<V.

% -------- RHS application --------
concluir([cria_facto(F)|Y],ID,LFactos):-
    !,
    cria_facto(F,ID,LFactos),
    concluir(Y,ID,LFactos).
concluir([],_,_):-!.

cria_facto(F,_,_):-
    facto(_,F),!.
cria_facto(F,ID,LFactos):-
    next_fact_index(N),
    assertz(justifica(N,ID,LFactos)),
    assertz(facto(N,F)).

% -------- Scoring --------
add_score(Delta) :-
    retract(score_total(T0)),
    T is T0 + Delta,
    asserta(score_total(T)),
    update_score_fact.

update_score_fact :-
    current_url(URL),
    % remove existing score facts for URL
    findall(N, facto(N, score_URL(URL,_)), Ns),
    forall(member(K, Ns), (retractall(justifica(K,_,_)), retractall(facto(K,_)))),
    % assert updated score fact
    next_fact_index(N1),
    score_total(T),
    assertz(facto(N1, score_URL(URL, T))).

% Next fact index helper updates ultimo_facto/1 safely
next_fact_index(N) :-
    (   retract(ultimo_facto(K)) -> true ; K = 0 ),
    N is K + 1,
    asserta(ultimo_facto(N)).

% -------- Explanations as JSON-like dicts --------
explicacoes_regras_json(JSONList) :-
    findall(ID-LFactos, regra_disparada(ID, LFactos), Pairs),
    sort(Pairs, SortedPairs),
    findall(_{rule_name: NomeAtom, score: Score, details: Details},
            ( member(IDx-FactList, SortedPairs),
              caracteristicas_regras(IDx, Nome, Score),
              atom_string(Nome, NomeAtom),
              build_explanation(IDx, FactList, Details)
            ),
            JSONList).

% Build human-readable explanation from fact list
build_explanation(RuleID, FactList, Details) :-
    caracteristicas_regras(RuleID, RuleName, _),
    % Special case for whitelist - simpler explanation
    (   RuleName = whitelist ->
        Details = 'This is a trusted domain on the whitelist'
    % All other rules - show relevant facts
    ;   get_rule_explanation(RuleName, FactList, Details)
    ).

% Get explanation for non-whitelist rules
get_rule_explanation(RuleName, FactList, Details) :-
    % Get rule-specific key facts
    findall(FactStr, 
            ( member(N, FactList),
              facto(N, Fact),
              is_relevant_fact_for_rule(RuleName, Fact),
              format_fact(Fact, FactStr),
              FactStr \= ''  % Skip empty strings
            ),
            AllFactStrings),
    % Limit to first 3 most relevant facts to avoid overwhelming users
    (   length(AllFactStrings, Len), Len > 3 ->
        append(FirstThree, _, AllFactStrings),
        length(FirstThree, 3),
        FactStrings = FirstThree
    ;   FactStrings = AllFactStrings
    ),
    (   FactStrings = [] ->
        atom_string(RuleName, RuleNameStr),
        format(atom(Details), 'Rule ~w triggered', [RuleNameStr])
    ;   atomic_list_concat(FactStrings, ', ', FactsConcat),
        format(atom(Details), 'Triggered by: ~w', [FactsConcat])
    ).

% Determine if a fact is relevant for a specific rule
% Whitelist rule - only show whitelisting info
is_relevant_fact_for_rule(whitelist, url_whitelisted(_, 1)) :- !.
is_relevant_fact_for_rule(whitelist, dns_a_record_exists(_, _)) :- !.
is_relevant_fact_for_rule(whitelist, dns_cname_chain_length(_, _)) :- !.
is_relevant_fact_for_rule(whitelist, dns_domain_age_days(_, _)) :- !.

% URL length rule - show length and validity
is_relevant_fact_for_rule(comprimento_url, comprimentoUrl(_, _)) :- !.
is_relevant_fact_for_rule(comprimento_url, comprimentoValido(_)) :- !.

% Young domain rule - show age-related facts
is_relevant_fact_for_rule(dominio_jovem, dns_domain_age_days(_, _)) :- !.
is_relevant_fact_for_rule(dominio_jovem, dominioJovem(_)) :- !.

% TTL rule - show TTL-related facts
is_relevant_fact_for_rule(ttl_muito_baixo, dns_min_ttl(_, _)) :- !.

% HTTP without TLS rule
is_relevant_fact_for_rule(http_sem_tls, http_scheme(_, _)) :- !.

% DNS A record rule
is_relevant_fact_for_rule(sem_dns_records, dns_a_record_exists(_, _)) :- !.

% CNAME rule
is_relevant_fact_for_rule(cadeia_cname_longa, dns_cname_chain_length(_, _)) :- !.

% MX/SPF rule
is_relevant_fact_for_rule(sem_mx_spf, dns_mx_exists(_, _)) :- !.
is_relevant_fact_for_rule(sem_mx_spf, dns_spf_dmarc(_, _)) :- !.

% IP address rule
is_relevant_fact_for_rule(ip_na_url, is_ip_address(_, _)) :- !.

% Domain length rule
is_relevant_fact_for_rule(dominio_longo, dns_domain_length(_, _)) :- !.

% Subdomain rule
is_relevant_fact_for_rule(muitos_subdominios, dns_subdomain_count(_, _)) :- !.

% Numeric ratio rule
is_relevant_fact_for_rule(razao_numerica_alta, dns_numeric_ratio(_, _)) :- !.

% Hyphen rule
is_relevant_fact_for_rule(muitos_hifens, dns_hyphen_count(_, _)) :- !.

% Path depth rule
is_relevant_fact_for_rule(caminho_profundo, dns_path_depth(_, _)) :- !.

% Encoded params
is_relevant_fact_for_rule(parametros_codificados, encoded_param_count(_, _)) :- !.
% Suspicious blob
is_relevant_fact_for_rule(blob_opaco_suspeito, url_suspicious_blob(_, _)) :- !.
% Domain DNSBL
is_relevant_fact_for_rule(dominio_dnsbl, domain_dnsbl_listed(_, _)) :- !.
% Leet substitutions
is_relevant_fact_for_rule(leet_substituicoes, leet_substitution_count(_, _)) :- !.
% Confusable unicode
is_relevant_fact_for_rule(unicode_confundivel, confusable_char_count(_, _)) :- !.
% Misleading host pattern
is_relevant_fact_for_rule(padrao_host_enganoso, misleading_host_pattern(_, _)) :- !.

% TLD rule
is_relevant_fact_for_rule(tld_suspeito, dns_tld_suspicious(_, _)) :- !.

% Credential tokens rule
is_relevant_fact_for_rule(tokens_credenciais, dns_credential_tokens(_, _)) :- !.

% IDN rule
is_relevant_fact_for_rule(idn_punycode, dns_idn_punycode(_, _)) :- !.

% Granular reachability rules - show status and reason
is_relevant_fact_for_rule(url_inatingivel_rede, url_reachability(_, _)) :- !.
is_relevant_fact_for_rule(url_inatingivel_rede, url_reachability_reason(_, _)) :- !.
is_relevant_fact_for_rule(url_inatingivel_rede, url_reachability_status(_, _)) :- !.

is_relevant_fact_for_rule(url_inatingivel_erro_cliente, url_reachability(_, _)) :- !.
is_relevant_fact_for_rule(url_inatingivel_erro_cliente, url_reachability_reason(_, _)) :- !.
is_relevant_fact_for_rule(url_inatingivel_erro_cliente, url_reachability_status(_, _)) :- !.

is_relevant_fact_for_rule(url_inatingivel_erro_servidor, url_reachability(_, _)) :- !.
is_relevant_fact_for_rule(url_inatingivel_erro_servidor, url_reachability_reason(_, _)) :- !.
is_relevant_fact_for_rule(url_inatingivel_erro_servidor, url_reachability_status(_, _)) :- !.

is_relevant_fact_for_rule(url_atingivel_redirect, url_reachability(_, _)) :- !.
is_relevant_fact_for_rule(url_atingivel_redirect, url_reachability_reason(_, _)) :- !.
is_relevant_fact_for_rule(url_atingivel_redirect, url_reachability_status(_, _)) :- !.

% Redirect chain analysis rules
is_relevant_fact_for_rule(cadeia_redirecionamento, redirect_chain_hops(_, _)) :- !.
is_relevant_fact_for_rule(cadeia_redirecionamento_profunda, redirect_chain_hops(_, _)) :- !.
is_relevant_fact_for_rule(diversidade_dominios_redirect, redirect_diversity_ratio(_, _)) :- !.
is_relevant_fact_for_rule(encurtadores_em_cadeia, redirect_shortener_count(_, _)) :- !.
is_relevant_fact_for_rule(multiplos_encurtadores, redirect_shortener_count(_, _)) :- !.

% New redirect/HTTP indicators
is_relevant_fact_for_rule(redirectDominiosNaoConfiaveis, redirect_untrusted_domain(_, _)) :- !.
is_relevant_fact_for_rule(redirectAbertoParametro, redirect_open_redirect(_, _)) :- !.
is_relevant_fact_for_rule(redirectUrlOfuscada, redirect_obfuscated_url(_, _)) :- !.
is_relevant_fact_for_rule(cadeiaRedirectQuebrada, redirect_chain_broken(_, _)) :- !.
is_relevant_fact_for_rule(multiplosIndicadoresRedirect, redirect_chain_hops(_, _)) :- !.
is_relevant_fact_for_rule(multiplosIndicadoresRedirect, redirect_untrusted_domain(_, _)) :- !.
is_relevant_fact_for_rule(multiplosIndicadoresRedirect, redirect_open_redirect(_, _)) :- !.
is_relevant_fact_for_rule(multiplosIndicadoresRedirect, redirect_obfuscated_url(_, _)) :- !.
is_relevant_fact_for_rule(encurtadorComRedirects, redirect_shortener_count(_, _)) :- !.
is_relevant_fact_for_rule(encurtadorComRedirectAberto, redirect_shortener_count(_, _)) :- !.
is_relevant_fact_for_rule(encurtadorComRedirectAberto, redirect_open_redirect(_, _)) :- !.
is_relevant_fact_for_rule(destinoFinalConfiavel, final_destination_trusted(_, _)) :- !.
is_relevant_fact_for_rule(destinoFinalMuitoNovo, final_destination_age_days(_, _)) :- !.
is_relevant_fact_for_rule(destinoFinalMenosUmAno, final_destination_age_days(_, _)) :- !.
is_relevant_fact_for_rule(destinoFinalMaisUmAno, final_destination_age_days(_, _)) :- !.
is_relevant_fact_for_rule(erroCertificadoTLS, http_tls_certificate_error(_, _)) :- !.

% New URL/DNS status facts
is_relevant_fact_for_rule(caminhoSuspeito, url_suspicious_path(_, _)) :- !.
is_relevant_fact_for_rule(dominioSuspenso, dns_domain_suspended(_, _)) :- !.
is_relevant_fact_for_rule(dominioExpiraBreve, dns_days_until_expiration(_, _)) :- !.
is_relevant_fact_for_rule(loopCname, dns_cname_loop(_, _)) :- !.
is_relevant_fact_for_rule(nameserverUnico, dns_nameserver_count(_, _)) :- !.
is_relevant_fact_for_rule(semReverseDns, dns_reverse_dns_exists(_, _)) :- !.
is_relevant_fact_for_rule(semAutenticacaoEmail, dns_email_auth_count(_, _)) :- !.
is_relevant_fact_for_rule(autenticacaoEmailParcial, dns_email_auth_count(_, _)) :- !.
is_relevant_fact_for_rule(respostaDnsLenta, dns_response_time_seconds(_, _)) :- !.

% DOM analysis rules (700s)
is_relevant_fact_for_rule(domCamposSensiveis, sensitive_fields_present(_, _)) :- !.
is_relevant_fact_for_rule(domSenhaPresente, password_field_present(_, _)) :- !.
is_relevant_fact_for_rule(domFormActionExterna, external_form_actions(_, _)) :- !.
is_relevant_fact_for_rule(domMuitosLinksExternos, external_or_null_links(_, _)) :- !.
is_relevant_fact_for_rule(domMidiaExterna, external_media(_, _)) :- !.
is_relevant_fact_for_rule(domEntropiaAlta, dom_entropy(_, _)) :- !.
is_relevant_fact_for_rule(domTituloOfuscado, title_obfuscated(_, _)) :- !.
is_relevant_fact_for_rule(domLinksSuspeitos, link_feature_ratio(_, _)) :- !.
is_relevant_fact_for_rule(domMultiplosIndicadores, password_field_present(_, _)) :- !.
is_relevant_fact_for_rule(domMultiplosIndicadores, external_form_actions(_, _)) :- !.
is_relevant_fact_for_rule(domMultiplosIndicadores, external_or_null_links(_, _)) :- !.

% Default: exclude common consulted facts that arent rule-specific
is_relevant_fact_for_rule(_, Fact) :-
    \+ functor(Fact, url_whitelisted, _),
    \+ functor(Fact, http_scheme, _),
    \+ functor(Fact, dominioConfiavel, _),
    \+ functor(Fact, phishingNaoConfirmado, _),
    \+ functor(Fact, score_URL, _).

% Format individual facts into readable strings
format_fact(is_ip_address(_URL, 1), Str) :- 
    format(atom(Str), 'IP address detected in URL', []).
format_fact(comprimentoUrl(_URL, Len), Str) :- 
    format(atom(Str), 'URL length: ~w characters', [Len]).
format_fact(has_at(_URL, 1), Str) :-
    format(atom(Str), 'URL contains "@" character', []).
format_fact(dns_tld_suspicious(_URL, 1), Str) :-
    format(atom(Str), 'suspicious TLD detected', []).
format_fact(dns_domain_length(_URL, Len), Str) :- 
    format(atom(Str), 'domain length: ~w characters', [Len]).
format_fact(dns_subdomain_count(_URL, Count), Str) :- 
    format(atom(Str), 'subdomain count: ~w', [Count]).
format_fact(dns_numeric_ratio(_URL, Ratio), Str) :- 
    Percent is Ratio * 100,
    format(atom(Str), 'numeric ratio: ~1f%', [Percent]).
format_fact(dns_hyphen_count(_URL, Count), Str) :- 
    format(atom(Str), 'hyphen count: ~w', [Count]).
format_fact(dns_credential_tokens(_URL, 1), Str) :- 
    format(atom(Str), 'credential-related keywords found', []).
format_fact(dns_path_depth(_URL, Depth), Str) :- 
    format(atom(Str), 'path depth: ~w segments', [Depth]).
format_fact(encoded_param_count(_URL, C), Str) :-
    C > 0,
    format(atom(Str), 'encoded parameters in query (~w)', [C]).
format_fact(url_suspicious_blob(_URL, 1), Str) :-
    format(atom(Str), 'suspicious opaque blob in query', []).
format_fact(domain_dnsbl_listed(_URL, 1), Str) :-
    format(atom(Str), 'domain listed in DNS blocklists (SURBL/Spamhaus)', []).
format_fact(leet_substitution_count(_URL, C), Str) :-
    C > 0,
    format(atom(Str), 'leet substitutions in domain (~w)', [C]).
format_fact(confusable_char_count(_URL, C), Str) :-
    C >= 1,
    format(atom(Str), 'confusable Unicode chars in domain (~w)', [C]).
format_fact(misleading_host_pattern(_URL, 1), Str) :-
    format(atom(Str), 'misleading host pattern detected', []).
format_fact(dns_domain_age_days(_URL, Days), Str) :- 
    format(atom(Str), 'domain age: ~w days', [Days]).
format_fact(dns_mx_exists(_URL, 0), Str) :- 
    format(atom(Str), 'no MX records found', []).
format_fact(dns_mx_exists(_URL, 1), Str) :- 
    format(atom(Str), 'MX records exist', []).
format_fact(dns_spf_dmarc(_URL, 0), Str) :- 
    format(atom(Str), 'no SPF/DMARC records', []).
format_fact(dns_spf_dmarc(_URL, 1), Str) :- 
    format(atom(Str), 'SPF/DMARC records found', []).
format_fact(dns_a_record_exists(_URL, 0), Str) :- 
    format(atom(Str), 'no DNS A records', []).
format_fact(dns_a_record_exists(_URL, 1), Str) :- 
    format(atom(Str), 'DNS A records exist', []).
format_fact(dns_cname_chain_length(_URL, 0), Str) :- 
    format(atom(Str), 'no CNAME chain', []).
format_fact(dns_cname_chain_length(_URL, Len), Str) :- 
    Len > 0,
    format(atom(Str), 'CNAME chain length: ~w', [Len]).
format_fact(dns_min_ttl(_URL, -1), Str) :- 
    format(atom(Str), 'TTL not available', []).
format_fact(dns_min_ttl(_URL, TTL), Str) :- 
    TTL >= 0,
    format(atom(Str), 'minimum TTL: ~w seconds', [TTL]).
format_fact(dns_idn_punycode(_URL, 0), Str) :- 
    format(atom(Str), 'no IDN punycode', []).
format_fact(dns_idn_punycode(_URL, 1), Str) :- 
    format(atom(Str), 'IDN punycode detected', []).
format_fact(redirect_has_untrusted(_URL, 1), Str) :-
    format(atom(Str), 'redirect chain passes through untrusted domain', []).
format_fact(redirect_uses_shortener(_URL, 1), Str) :-
    format(atom(Str), 'URL shortener detected in redirect chain', []).
format_fact(dom_external_link_count(_URL, Count), Str) :-
    format(atom(Str), 'external or null links detected: ~w', [Count]).
format_fact(dom_external_form_count(_URL, Count), Str) :-
    format(atom(Str), 'external form actions detected: ~w', [Count]).
format_fact(dom_external_media_count(_URL, Count), Str) :-
    format(atom(Str), 'external media references detected: ~w', [Count]).
format_fact(dom_entropy_flag(_URL, 1), Str) :-
    format(atom(Str), 'DOM entropy above suspicious threshold', []).
format_fact(dom_entropy_score(_URL, Value), Str) :-
    format(atom(Str), 'DOM entropy score: ~2f', [Value]).
format_fact(dns_no_mx_spf(_URL, 1), Str) :-
    format(atom(Str), 'MX and SPF records missing', []).
format_fact(url_whitelisted(_URL, 1), Str) :- 
    format(atom(Str), 'trusted domain in whitelist', []).
format_fact(http_scheme(_URL, 1), Str) :- 
    format(atom(Str), 'HTTP without TLS', []).
format_fact(url_reachability(_URL, reachable), Str) :- 
    format(atom(Str), 'URL is reachable', []).
format_fact(url_reachability(_URL, unreachable), Str) :- 
    format(atom(Str), 'URL is unreachable', []).
format_fact(url_reachability_status(_URL, Status), Str) :- 
    format(atom(Str), 'HTTP status: ~w', [Status]).
format_fact(url_reachability_reason(_URL, network_failure), Str) :- 
    format(atom(Str), 'network failure (timeout/DNS error)', []).
format_fact(url_reachability_reason(_URL, client_error), Str) :- 
    format(atom(Str), 'client error (4xx response)', []).
format_fact(url_reachability_reason(_URL, server_error), Str) :- 
    format(atom(Str), 'server error (5xx response)', []).
format_fact(url_reachability_reason(_URL, redirect), Str) :- 
    format(atom(Str), 'redirect issued (3xx)', []).
format_fact(url_reachability_reason(_URL, success), Str) :- 
    format(atom(Str), 'successful response (2xx)', []).
format_fact(url_reachability_reason(_URL, http_error), Str) :- 
    format(atom(Str), 'HTTP error (unexpected status)', []).
format_fact(redirect_chain_hops(_URL, Hops), Str) :- 
    format(atom(Str), 'redirect chain hops: ~w', [Hops]).
format_fact(redirect_diversity_ratio(_URL, Ratio), Str) :- 
    format(atom(Str), 'redirect domain diversity: ~2f', [Ratio]).
format_fact(redirect_shortener_count(_URL, Count), Str) :- 
    format(atom(Str), 'URL shorteners in chain: ~w', [Count]).
format_fact(redirect_unique_domains(_URL, Count), Str) :- 
    format(atom(Str), 'unique domains in chain: ~w', [Count]).
format_fact(redirect_untrusted_domain(_URL, 1), Str) :- 
    format(atom(Str), 'untrusted domain in redirect chain', []).
format_fact(redirect_open_redirect(_URL, 1), Str) :- 
    format(atom(Str), 'open redirect params detected', []).
format_fact(redirect_obfuscated_url(_URL, 1), Str) :- 
    format(atom(Str), 'obfuscated URL in chain', []).
format_fact(redirect_chain_broken(_URL, 1), Str) :- 
    format(atom(Str), 'broken redirect chain (loop/error)', []).
format_fact(final_destination_trusted(_URL, 1), Str) :- 
    format(atom(Str), 'final destination is trusted', []).
format_fact(final_destination_age_days(_URL, Days), Str) :- 
    Days >= 0,
    format(atom(Str), 'final destination age: ~w days', [Days]).
format_fact(url_suspicious_path(_URL, 1), Str) :- 
    format(atom(Str), 'suspicious URL path pattern', []).
format_fact(http_tls_certificate_error(_URL, 1), Str) :- 
    format(atom(Str), 'TLS certificate error', []).
format_fact(dns_domain_suspended(_URL, 1), Str) :- 
    format(atom(Str), 'domain suspended/redemption', []).
format_fact(dns_days_until_expiration(_URL, Days), Str) :- 
    Days < 9999,
    format(atom(Str), 'domain expires in ~w days', [Days]).
format_fact(dns_cname_loop(_URL, 1), Str) :- 
    format(atom(Str), 'CNAME loop detected', []).
format_fact(dns_nameserver_count(_URL, Count), Str) :- 
    format(atom(Str), 'nameservers: ~w', [Count]).
format_fact(dns_reverse_dns_exists(_URL, 0), Str) :- 
    format(atom(Str), 'no reverse DNS (PTR)', []).
format_fact(dns_email_auth_count(_URL, Count), Str) :- 
    format(atom(Str), 'email auth mechanisms: ~w/3', [Count]).
format_fact(dns_response_time_seconds(_URL, Time), Str) :- 
    Time > 0,
    format(atom(Str), 'DNS response time: ~2f seconds', [Time]).
% DOM analysis facts (700s)
format_fact(sensitive_fields_present(_URL, 1), Str) :- 
    format(atom(Str), 'sensitive input fields detected', []).
format_fact(password_field_present(_URL, 1), Str) :- 
    format(atom(Str), 'password field present', []).
format_fact(external_form_actions(_URL, Count), Str) :- 
    Count > 0,
    format(atom(Str), 'external/null form actions: ~w', [Count]).
format_fact(external_or_null_links(_URL, Count), Str) :- 
    Count > 0,
    format(atom(Str), 'external/null links: ~w', [Count]).
format_fact(external_media(_URL, Count), Str) :- 
    Count > 0,
    format(atom(Str), 'external media resources: ~w', [Count]).
format_fact(dom_entropy(_URL, Entropy), Str) :- 
    Entropy > 0,
    format(atom(Str), 'DOM entropy: ~2f', [Entropy]).
format_fact(title_obfuscated(_URL, 1), Str) :- 
    format(atom(Str), 'obfuscated page title', []).
format_fact(link_feature_ratio(_URL, Ratio), Str) :- 
    Ratio > 0,
    format(atom(Str), 'suspicious link ratio: ~2f', [Ratio]).
format_fact(dependent_request_ratio(_URL, Ratio), Str) :- 
    Ratio > 0,
    format(atom(Str), 'external dependency ratio: ~2f', [Ratio]).
format_fact(score_URL(_URL, Score), Str) :- 
    format(atom(Str), 'URL risk score: ~w', [Score]).
format_fact(phishingNaoConfirmado(_URL), Str) :- 
    format(atom(Str), 'potential phishing detected', []).
format_fact(dominioConfiavel(_URL), Str) :- 
    format(atom(Str), 'domain appears trustworthy', []).
format_fact(dominioJovem(_URL), Str) :- 
    format(atom(Str), 'young domain', []).
format_fact(comprimentoValido(_URL), Str) :- 
    format(atom(Str), 'URL length is valid', []).
format_fact(caracteristicas(_URL, Attr), Str) :- 
    format(atom(Str), 'characteristic: ~w', [Attr]).
% Catch-all for unknown facts - hide internal predicates and raw fact representations
format_fact(Fact, '') :- 
    % Skip internal facts and raw consulted facts
    functor(Fact, Name, _),
    member(Name, [
        consulsao, ultimo_facto, ultima_caracteristica, current_url, justifica,
        comprimentoUrl, dns_domain_age_days, dns_domain_length, dns_subdomain_count,
        dns_numeric_ratio, dns_hyphen_count, dns_path_depth, dns_tld_suspicious,
        dns_credential_tokens, is_ip_address, url_whitelisted, http_scheme, score_URL,
        phishingNaoConfirmado, dominioConfiavel, dominioJovem, comprimentoValido,
        caracteristicas, encoded_param_count, url_suspicious_blob, domain_dnsbl_listed,
        leet_substitution_count, confusable_char_count, misleading_host_pattern,
        redirect_chain_hops, redirect_diversity_ratio, redirect_shortener_count, redirect_unique_domains,
        redirect_untrusted_domain, redirect_open_redirect, redirect_obfuscated_url, redirect_chain_broken,
        final_destination_trusted, final_destination_age_days, url_suspicious_path,
        http_tls_certificate_error, dns_domain_suspended, dns_days_until_expiration,
        dns_cname_loop, dns_nameserver_count, dns_reverse_dns_exists, 
        dns_email_auth_count, dns_response_time_seconds,
        sensitive_fields_present, password_field_present, external_form_actions,
        external_or_null_links, external_media, dom_entropy, title_obfuscated,
        link_feature_ratio, dependent_request_ratio
    ]),
    !.
format_fact(_, '').

% -------- Utilities --------
reset_engine :-
    retractall(justifica(_,_,_)),
    retractall(regra_disparada(_,_)),
    retractall(facto(_,_)),
    retractall(score_total(_)), asserta(score_total(0)),
    retractall(ultimo_facto(_)), asserta(ultimo_facto(0)),
    retractall(ultima_caracteristica(_)), asserta(ultima_caracteristica(0)),
    retractall(current_url(_)).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Geracao de explicacoes do tipo "Como"

como(N):-ultimo_facto(Last),Last<N,!,
	write('Essa conclusao nao foi tirada'),nl,nl.
como(N):-justifica(N,ID,LFactos),!,
	facto(N,F),
        caracteristicas_regras(ID, Nome, _),
	write('Conclui o facto numero '),write(N),write(' -> '),write(F),nl,
	write('pela regra de '), write(Nome), write(" - "),write(ID),nl,
	write('por se ter verificado que:'),nl,
	escreve_factos(LFactos),
	write('********************************************************'),nl,
	explica(LFactos).
como(N):-facto(N,F),
	write('O facto n '),write(N),write(' -> '),write(F),nl,
	write('foi conhecido inicialmente'),nl,
	write('********************************************************'),nl.

escreve_factos([I|R]):-facto(I,F), !,
	write('O facto n '),write(I),write(' -> '),write(F),write(' e verdadeiro'),nl,
	escreve_factos(R).
escreve_factos([I|R]):-
	write('A condicao '),write(I),write(' e verdadeira'),nl,
	escreve_factos(R).
escreve_factos([]).

explica([I|R]):- \+ integer(I),!,explica(R).
explica([I|R]):-como(I),
		explica(R).
explica([]):-	write('********************************************************'),nl.




%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Geracao de explicacoes do tipo "Porque nao"
% Exemplo: ?- whynot(classe(meu_veiculo,ligeiro)).

whynot(Facto):-
	whynot(Facto,1).

whynot(Facto,_):-
	facto(_, Facto),
	!,
	write('O facto '),write(Facto),write(' nao e falso!'),nl.
whynot(Facto,Nivel):-
	encontra_regras_whynot(Facto,LLPF),
	whynot1(LLPF,Nivel).
whynot(nao Facto,Nivel):-
	formata(Nivel),write('Porque:'),write(' O facto '),write(Facto),
	write(' e verdadeiro'),nl.
whynot(Facto,Nivel):-
	formata(Nivel),write('Porque:'),write(' O facto '),write(Facto),
	write(' nao esta definido na base de conhecimento'),nl.

%  As explicacoes do whynot(Facto) devem considerar todas as regras que poderiam dar origem a conclusao relativa ao facto Facto

encontra_regras_whynot(Facto,LLPF):-
	findall((ID,LPF),
		(
		regra ID se LHS entao RHS,
		member(cria_facto(Facto),RHS),
		encontra_premissas_falsas(LHS,LPF),
		LPF \== []
		),
		LLPF).

whynot1([],_).
whynot1([(ID,LPF)|LLPF],Nivel):-
	formata(Nivel),write('Porque pela regra '),write(ID),write(':'),nl,
	Nivel1 is Nivel+1,
	explica_porque_nao(LPF,Nivel1),
	whynot1(LLPF,Nivel).

encontra_premissas_falsas([nao X e Y], LPF):-
	verifica_condicoes([nao X], _),
	!,
	encontra_premissas_falsas([Y], LPF).
encontra_premissas_falsas([X e Y], LPF):-
	verifica_condicoes([X], _),
	!,
	encontra_premissas_falsas([Y], LPF).
encontra_premissas_falsas([nao X], []):-
	verifica_condicoes([nao X], _),
	!.
encontra_premissas_falsas([X], []):-
	verifica_condicoes([X], _),
	!.
encontra_premissas_falsas([nao X e Y], [nao X|LPF]):-
	!,
	encontra_premissas_falsas([Y], LPF).
encontra_premissas_falsas([X e Y], [X|LPF]):-
	!,
	encontra_premissas_falsas([Y], LPF).
encontra_premissas_falsas([nao X], [nao X]):-!.
encontra_premissas_falsas([X], [X]).
encontra_premissas_falsas([]).

explica_porque_nao([],_).
explica_porque_nao([nao avalia(X)|LPF],Nivel):-
	!,
	formata(Nivel),write('A condicao nao '),write(X),write(' e falsa'),nl,
	explica_porque_nao(LPF,Nivel).
explica_porque_nao([avalia(X)|LPF],Nivel):-
	!,
	formata(Nivel),write('A condicao '),write(X),write(' e falsa'),nl,
	explica_porque_nao(LPF,Nivel).
explica_porque_nao([P|LPF],Nivel):-
	formata(Nivel),write('A premissa '),write(P),write(' e falsa'),nl,
	Nivel1 is Nivel+1,
	whynot(P,Nivel1),
	explica_porque_nao(LPF,Nivel).

formata(Nivel):-
	Esp is (Nivel-1)*5, tab(Esp).


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Visualizacao da base de factos

mostra_factos:-
	findall(N, facto(N, _), LFactos),
	escreve_factos(LFactos).

    % -------- Rule gating / evaluation workflow --------
    % Certain rules can be safely skipped based on already-known facts or state.
    % This reduces redundant checks and avoids irrelevant evaluations.

    % Helper: check if a fact exists
    fact_exists(Term) :- facto(_, Term), !.

    % Skip groups when URL is whitelisted: handled earlier by fire_whitelist_rule_only/0
    % so by the time we reach rule firing, nothing else should run.

% Skip domain-based rules when URL uses a raw IP address
% IP URLs make domain lexical checks and many DNS-based rules inapplicable.
should_skip_rule(ID) :-
    current_url(URL),
    fact_exists(is_ip_address(URL, 1)),
    member(ID, [400,401,402,403,404,405,406,407,408,409,410,411,412,500,501,502,503,504,505]),
    !.

% Skip HTTP/redirect/DNS-resolution specifics when there are no A/AAAA records
% If the domain does not resolve, TTL/CNAME/HTTP redirect checks are irrelevant.
should_skip_rule(ID) :-
    current_url(URL),
    fact_exists(dns_a_record_exists(URL, 0)),
    member(ID, [600,601,602,603,604,605,606,501,502]),
    !.

% Skip redirect-chain evaluation when already deemed unreachable
should_skip_rule(606) :-
    current_url(URL),
    fact_exists(url_reachability(URL, unreachable)),
    !.

% Skip granular reachability rules if generic Rule 14 already fired or URL is reachable
% This prevents double-counting and reduces noise
should_skip_rule(ID) :-
    member(ID, [602,603,604,605]),
    current_url(URL),
    (   regra_disparada(601, _) ;  % Generic unreachability already counted
        fact_exists(url_reachability(URL, reachable))  % URL is reachable, no need for failure modes
    ),
    !.

% Early stop on high risk: once score >= 500, skip further scoring rules
% but allow classification/conclusion rules (3: safe, 4: phishing) to evaluate.
should_skip_rule(ID) :-
    score_total(T), T >= 500,
    \+ member(ID, [300,301]),
    !.    % Default: do not skip
    should_skip_rule(_) :- fail.
