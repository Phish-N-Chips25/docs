% ============================================================================
% DNS MX RECORD EXISTENCE FACT
% ============================================================================
% Checks if domain has MX (mail exchange) records
%
% This file declares the dynamic predicate that Python will assert.
% No feature_extractor needed - kb_rules.pl queries this directly via avalia().
%
% Predicate: dns_mx_exists/2
%   Args: dns_mx_exists(URL, Exists)
%   Values: Exists = 1 if MX records found, 0 otherwise
%
% Asserted by: DNSFactsIntegration.assert_dns_facts() in dns_facts_integration.py
% Queried by: Rule 503 (sem_mx_spf) in kb_rules.pl
% ============================================================================

:- dynamic dns_mx_exists/2.
