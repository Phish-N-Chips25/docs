% Has @ character fact extractor (Python-based)
% Detects suspicious '@' character in URLs, excluding legitimate /@username/ patterns
:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.
:- dynamic has_at/2.  % Python will assert this base fact

feature_extractor(has_at_check).

has_at_check(URL) :-
    (   ultimo_facto(N0) -> true ; N0 = 0 ),
    (   ultima_caracteristica(C0) -> true ; C0 = 0 ),
    retractall(ultima_caracteristica(_)), C1 is C0 + 1, asserta(ultima_caracteristica(C1)),
    retractall(ultimo_facto(_)), N1 is N0 + 1, asserta(ultimo_facto(N1)),
    (   has_at(URL, V)
    ->  assertz(facto(N1, has_at(URL, V)))
    ;   assertz(facto(N1, has_at(URL, 0)))
    ).
