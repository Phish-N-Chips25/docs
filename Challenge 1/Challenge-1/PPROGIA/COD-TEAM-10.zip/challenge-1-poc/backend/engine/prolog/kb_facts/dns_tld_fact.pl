% Suspicious TLD fact
:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.
:- use_module(common_utils, [extract_host/2, extract_tld/2, suspicious_tld/1]).

feature_extractor(dns_suspicious_tld_check).

dns_suspicious_tld_check(URL) :-
    ultimo_facto(N), ultima_caracteristica(C),
    retract(ultima_caracteristica(_)), C1 is C + 1, asserta(ultima_caracteristica(C1)),
    retract(ultimo_facto(_)), N1 is N + 1, asserta(ultimo_facto(N1)),
    (   extract_host(URL, Host), extract_tld(Host, TLD), suspicious_tld(TLD)
    ->  assertz(facto(N1, dns_tld_suspicious(URL, 1)))
    ;   assertz(facto(N1, dns_tld_suspicious(URL, 0)))
    ).
