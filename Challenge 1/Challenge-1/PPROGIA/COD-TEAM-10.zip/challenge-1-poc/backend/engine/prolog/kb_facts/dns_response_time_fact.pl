% ============================================================================
% DNS RESPONSE TIME FACT
% ============================================================================
% Measures DNS query response time in seconds
%
% This file declares the dynamic predicate that Python will assert.
% No feature_extractor needed - kb_rules.pl queries this directly via avalia().
%
% Predicate: dns_response_time_seconds/2
%   Args: dns_response_time_seconds(URL, Time)
%   Values: Time = response time as float (e.g., 0.15 for 150ms, 2.5 for 2.5s)
%
% Asserted by: DNSFactsIntegration.assert_dns_facts() in dns_facts_integration.py
% Queried by: Rule 518 (resposta_dns_lenta) in kb_rules.pl
% ============================================================================

:- dynamic dns_response_time_seconds/2.
