% Credential token detection fact
:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.

feature_extractor(dns_credential_tokens_check).

dns_credential_tokens_check(URL) :-
    ultimo_facto(N), ultima_caracteristica(C),
    retract(ultima_caracteristica(_)), C1 is C + 1, asserta(ultima_caracteristica(C1)),
    retract(ultimo_facto(_)), N1 is N + 1, asserta(ultimo_facto(N1)),
    (   has_credential_tokens(URL)
    ->  assertz(facto(N1, dns_credential_tokens(URL, 1)))
    ;   assertz(facto(N1, dns_credential_tokens(URL, 0)))
    ).

has_credential_tokens(URL) :-
    string_lower(URL, LowerURL),
    (   sub_string(LowerURL, _, _, _, "login")
    ;   sub_string(LowerURL, _, _, _, "verify")
    ;   sub_string(LowerURL, _, _, _, "reset")
    ;   sub_string(LowerURL, _, _, _, "account")
    ;   sub_string(LowerURL, _, _, _, "signin")
    ;   sub_string(LowerURL, _, _, _, "auth")
    ;   sub_string(LowerURL, _, _, _, "secure")
    ;   sub_string(LowerURL, _, _, _, "update")
    ;   sub_string(LowerURL, _, _, _, "confirm")
    ;   sub_string(LowerURL, _, _, _, "password")
    ;   sub_string(LowerURL, _, _, _, "credential")
    ).
