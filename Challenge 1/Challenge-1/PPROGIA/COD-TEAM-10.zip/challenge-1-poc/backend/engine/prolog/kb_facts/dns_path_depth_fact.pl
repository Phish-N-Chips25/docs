% Path depth fact
:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.
:- use_module(common_utils, [extract_path/2, count_path_segments/2]).

feature_extractor(dns_path_depth_check).

dns_path_depth_check(URL) :-
    ultimo_facto(N), ultima_caracteristica(C),
    retract(ultima_caracteristica(_)), C1 is C + 1, asserta(ultima_caracteristica(C1)),
    retract(ultimo_facto(_)), N1 is N + 1, asserta(ultimo_facto(N1)),
    (   extract_path(URL, Path), count_path_segments(Path, Depth)
    ->  assertz(facto(N1, dns_path_depth(URL, Depth)))
    ;   assertz(facto(N1, dns_path_depth(URL, 0)))
    ).
