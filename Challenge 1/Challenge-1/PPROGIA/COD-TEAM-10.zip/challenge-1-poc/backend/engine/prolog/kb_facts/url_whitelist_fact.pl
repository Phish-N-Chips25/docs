% Whitelist fact extractor
% Checks if URL domain is in the trusted whitelist

:- use_module(kb_facts(common_utils), [extract_hostname/2]).
:- multifile feature_extractor/1.
:- dynamic whitelist_domain/1.

% Register this extractor
feature_extractor(url_whitelist_check).

% Known trusted domains
whitelist_domain('isep.ipp.pt').

% Extract hostname and check whitelist
url_whitelist_check(URL) :-
    catch((
        % Extract hostname from URL
        extract_hostname(URL, Hostname),
        % Check if whitelisted
        (   whitelist_domain(Hostname)
        ->  assertz(facto(_, url_whitelisted(URL, 1)))
        ;   assertz(facto(_, url_whitelisted(URL, 0)))
        )
    ), _, assertz(facto(_, url_whitelisted(URL, 0)))).
