% ============================================================================
% DNS REVERSE DNS (PTR) FACT
% ============================================================================
% Checks if reverse DNS (PTR record) exists for the domains IP
%
% This file declares the dynamic predicate that Python will assert.
% No feature_extractor needed - kb_rules.pl queries this directly via avalia().
%
% Predicate: dns_reverse_dns_exists/2
%   Args: dns_reverse_dns_exists(URL, Exists)
%   Values: Exists = 1 if PTR record found, 0 otherwise
%
% Asserted by: DNSFactsIntegration.assert_dns_facts() in dns_facts_integration.py
% Queried by: Rule 515 (sem_reverse_dns) in kb_rules.pl
% ============================================================================

:- dynamic dns_reverse_dns_exists/2.
