% ============================================================================
% DNS CNAME CHAIN LENGTH FACT
% ============================================================================
% Checks length of CNAME chain for redirection/cloaking detection
%
% This file declares the dynamic predicate that Python will assert.
% No feature_extractor needed - kb_rules.pl queries this directly via avalia().
%
% Predicate: dns_cname_chain_length/2
%   Args: dns_cname_chain_length(URL, Length)
%   Values: Length = number of CNAME hops in chain, 0 if none
%
% Asserted by: DNSFactsIntegration.assert_dns_facts() in dns_facts_integration.py
% Queried by: Rule 502 (cadeia_cname_longa) in kb_rules.pl
% ============================================================================

:- dynamic dns_cname_chain_length/2.