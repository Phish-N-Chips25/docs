% ============================================================================
% DNS EMAIL AUTHENTICATION GRANULAR FACT
% ============================================================================
% Counts how many email authentication mechanisms are present (SPF, DMARC, DKIM)
%
% Python asserts the dynamic predicate dns_email_auth_count/2 with the raw
% value; this extractor wraps it as facto/2 so the inference engine can use it
% with avalia/2 in rules 516-517. If Python didnt provide a value, default to 0.
%
% Predicate: dns_email_auth_count/2
%   Args: dns_email_auth_count(URL, Count)
%   Values: Count = 0-3 (number of mechanisms found)
%     0 = none, 1 = one mechanism, 2 = two mechanisms, 3 = all three
%
% Asserted by: DNSFactsIntegration.assert_dns_facts() in dns_facts_integration.py
% Queried by: Rules 516-517 (sem_autenticacao_email, autenticacao_email_parcial) in kb_rules.pl
% ============================================================================

:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.
:- dynamic dns_email_auth_count/2.

feature_extractor(dns_email_auth_granular_check).

dns_email_auth_granular_check(URL) :-
    (   ultimo_facto(N0) -> true ; N0 = 0 ),
    (   ultima_caracteristica(C0) -> true ; C0 = 0 ),
    retractall(ultima_caracteristica(_)), C1 is C0 + 1, asserta(ultima_caracteristica(C1)),
    retractall(ultimo_facto(_)), N1 is N0 + 1, asserta(ultimo_facto(N1)),
    (   dns_email_auth_count(URL, Count)
    ->  assertz(facto(N1, dns_email_auth_count(URL, Count)))
    ;   assertz(facto(N1, dns_email_auth_count(URL, 0)))
    ).
