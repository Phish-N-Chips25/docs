% ============================================================================
% DNS SPF/DMARC FACT
% ============================================================================
% Checks for SPF and DMARC email authentication records
%
% This file declares the dynamic predicate that Python will assert.
% No feature_extractor needed - kb_rules.pl queries this directly via avalia().
%
% Predicate: dns_spf_dmarc/2
%   Args: dns_spf_dmarc(URL, Exists)
%   Values: Exists = 1 if SPF or DMARC found, 0 otherwise
%
% Asserted by: DNSFactsIntegration.assert_dns_facts() in dns_facts_integration.py
% Queried by: Rule 503 (sem_mx_spf) in kb_rules.pl
% ============================================================================

:- dynamic dns_spf_dmarc/2.
