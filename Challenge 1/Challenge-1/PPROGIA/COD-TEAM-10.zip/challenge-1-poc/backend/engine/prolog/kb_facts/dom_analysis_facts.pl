% DOM Analysis fact extractors (Python-based)
% Extracts DOM phishing indicators using lightweight BeautifulSoup analysis
:- multifile feature_extractor/1.
:- multifile next_fact_index/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.

% Dynamic declarations for base facts that Python will assert
:- dynamic sensitive_fields_present/2.
:- dynamic password_field_present/2.
:- dynamic external_form_actions/2.
:- dynamic external_or_null_links/2.
:- dynamic external_media/2.
:- dynamic dom_entropy/2.
:- dynamic title_obfuscated/2.
:- dynamic link_feature_ratio/2.
:- dynamic dependent_request_ratio/2.

% Register feature extractors
feature_extractor(dom_sensitive_fields_check).
feature_extractor(dom_password_field_check).
feature_extractor(dom_external_form_actions_check).
feature_extractor(dom_external_links_check).
feature_extractor(dom_external_media_check).
feature_extractor(dom_entropy_check).
feature_extractor(dom_title_obfuscated_check).
feature_extractor(dom_link_feature_ratio_check).
feature_extractor(dom_dependent_request_ratio_check).

% Feature extractor: sensitive_fields_present (count of sensitive input fields)
dom_sensitive_fields_check(URL) :-
    next_fact_index(N),
    (   sensitive_fields_present(URL, V)
    ->  assertz(facto(N, sensitive_fields_present(URL, V)))
    ;   assertz(facto(N, sensitive_fields_present(URL, 0)))
    ).

% Feature extractor: password_field_present (boolean)
dom_password_field_check(URL) :-
    next_fact_index(N),
    (   password_field_present(URL, V)
    ->  assertz(facto(N, password_field_present(URL, V)))
    ;   assertz(facto(N, password_field_present(URL, 0)))
    ).

% Feature extractor: external_form_actions (count of forms with external actions)
dom_external_form_actions_check(URL) :-
    next_fact_index(N),
    (   external_form_actions(URL, V)
    ->  assertz(facto(N, external_form_actions(URL, V)))
    ;   assertz(facto(N, external_form_actions(URL, 0)))
    ).

% Feature extractor: external_or_null_links (count of external/null links)
dom_external_links_check(URL) :-
    next_fact_index(N),
    (   external_or_null_links(URL, V)
    ->  assertz(facto(N, external_or_null_links(URL, V)))
    ;   assertz(facto(N, external_or_null_links(URL, 0)))
    ).

% Feature extractor: external_media (count of external media resources)
dom_external_media_check(URL) :-
    next_fact_index(N),
    (   external_media(URL, V)
    ->  assertz(facto(N, external_media(URL, V)))
    ;   assertz(facto(N, external_media(URL, 0)))
    ).

% Feature extractor: dom_entropy (DOM structure entropy)
dom_entropy_check(URL) :-
    next_fact_index(N),
    (   dom_entropy(URL, V)
    ->  assertz(facto(N, dom_entropy(URL, V)))
    ;   assertz(facto(N, dom_entropy(URL, 0.0)))
    ).

% Feature extractor: title_obfuscated (boolean)
dom_title_obfuscated_check(URL) :-
    next_fact_index(N),
    (   title_obfuscated(URL, V)
    ->  assertz(facto(N, title_obfuscated(URL, V)))
    ;   assertz(facto(N, title_obfuscated(URL, 0)))
    ).

% Feature extractor: link_feature_ratio (ratio metric)
dom_link_feature_ratio_check(URL) :-
    next_fact_index(N),
    (   link_feature_ratio(URL, V)
    ->  assertz(facto(N, link_feature_ratio(URL, V)))
    ;   assertz(facto(N, link_feature_ratio(URL, 0.0)))
    ).

% Feature extractor: dependent_request_ratio (ratio metric)
dom_dependent_request_ratio_check(URL) :-
    next_fact_index(N),
    (   dependent_request_ratio(URL, V)
    ->  assertz(facto(N, dependent_request_ratio(URL, V)))
    ;   assertz(facto(N, dependent_request_ratio(URL, 0.0)))
    ).
