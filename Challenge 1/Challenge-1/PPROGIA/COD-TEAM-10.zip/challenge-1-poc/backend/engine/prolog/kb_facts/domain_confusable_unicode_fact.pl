% Confusable Unicode characters count in domain fact
:- multifile feature_extractor/1.
:- dynamic ultimo_facto/1, ultima_caracteristica/1, facto/2.
:- dynamic confusable_char_count/2.  % Python will assert this fact

feature_extractor(domain_confusable_unicode_check).

domain_confusable_unicode_check(URL) :-
    ultimo_facto(N), ultima_caracteristica(C),
    retract(ultima_caracteristica(_)), C1 is C + 1, asserta(ultima_caracteristica(C1)),
    retract(ultimo_facto(_)), N1 is N + 1, asserta(ultimo_facto(N1)),
    ( confusable_char_count(URL, Count) ->
        assertz(facto(N1, confusable_char_count(URL, Count)))
    ;   assertz(facto(N1, confusable_char_count(URL, 0)))
    ).
