const axios = require('axios');

async function main() {
  try {
    const response = await axios.get('http://127.0.0.1:8000/health');
    console.log('status', response.status);
    console.log('body', response.data);
  } catch (error) {
    if (error.response) {
      console.error('status', error.response.status);
      console.error('body', error.response.data);
    } else {
      console.error('error', error.message);
    }
    process.exitCode = 1;
  }
}

main();
