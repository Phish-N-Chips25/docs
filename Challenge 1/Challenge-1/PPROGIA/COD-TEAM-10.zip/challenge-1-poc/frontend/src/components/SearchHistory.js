import React, { useMemo } from 'react';
import styles from './SearchHistory.module.css';
import { ENGINE_TITLES } from '../constants/engineRules';

const timeFormatter = new Intl.DateTimeFormat(undefined, {
  hour: '2-digit',
  minute: '2-digit',
});

function formatTimestamp(timestamp) {
  if (!timestamp) {
    return '';
  }

  try {
    return timeFormatter.format(new Date(timestamp));
  } catch (error) {
    return '';
  }
}

export default function SearchHistory({ entries = [], onSelectEntry, onClearHistory }) {
  const visibleEntries = useMemo(() => entries.slice(0, 6), [entries]);
  const hasEntries = visibleEntries.length > 0;

  return (
    <nav className={styles.history} aria-label="Session navigation">
      <header className={styles.header}>
        <div className={styles.headerText}>
          <p className={styles.overline}>Workspace</p>
          <h3 className={styles.title}>Recent analyses</h3>
        </div>
        <div className={styles.headerActions}>
          <span className={styles.badge}>{visibleEntries.length}</span>
          {hasEntries && onClearHistory && (
            <button type="button" className={styles.clearButton} onClick={onClearHistory}>
              Clear
            </button>
          )}
        </div>
      </header>

      <div className={styles.content}>
        {hasEntries ? (
          <ul className={styles.list}>
            {visibleEntries.map((entry) => (
              <li key={entry.id} className={styles.item}>
                <button
                  type="button"
                  className={styles.itemButton}
                  onClick={() => onSelectEntry?.(entry)}
                  aria-label={`Re-run analysis for ${entry.url}`}
                >
                  <div className={styles.row}>
                    <span className={styles.url} title={entry.url}>
                      {entry.url}
                    </span>
                    <span className={styles.count}>
                      {entry.results?.length ?? 0}
                      <span className={styles.countLabel}>hits</span>
                    </span>
                  </div>
                  <div className={styles.meta}>
                    <span className={styles.engine}>{ENGINE_TITLES[entry.engine] ?? entry.engine}</span>
                    <time className={styles.time} dateTime={entry.timestamp}>
                      {formatTimestamp(entry.timestamp)}
                    </time>
                  </div>
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <div className={styles.empty}>
            <p className={styles.emptyTitle}>No investigations yet</p>
            <p className={styles.emptyHint}>Run your first analysis to anchor quick navigation here.</p>
          </div>
        )}
      </div>

    </nav>
  );
}
