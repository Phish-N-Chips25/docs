import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import api from "../services/api";
import { evaluateDroolsUrl } from "../services/droolsApi";
import EngineSelector from "./EngineSelector";
import ResultsPanel from "./ResultsPanel";
import { ENGINE_TITLES } from "../constants/engineRules";
import "./UrlSearch.css";

export default function UrlSearch({
  engine,
  onEngineChange,
  totalRules = 0,
  onRecordSearch,
  prefillRequest,
}) {
  const [inputUrl, setInputUrl] = useState("");
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [hasSearched, setHasSearched] = useState(false);
  const [analysisMeta, setAnalysisMeta] = useState(null);
  const lastPrefillId = useRef(null);

  const riskLabelMap = useMemo(
    () => ({
      safe: "Safe",
      suspicious: "Suspicious",
      phishing: "Phishing",
      CLEAR: "Clear",
      LOW_RISK: "Low Risk",
      REVIEW: "Review",
      SUSPICIOUS: "Suspicious",
      PROBABLE_PHISHING: "Probable Phishing",
      CONFIRMED_PHISHING: "Most Likely Phishing",
    }),
    []
  );

  const riskCopyMap = useMemo(
    () => ({
      safe: "No critical heuristics triggered. Continue routine monitoring.",
      suspicious: "Signals detected. Investigate before trusting this URL.",
      phishing:
        "Strong phishing indicators present. Block and escalate immediately.",
      CLEAR:
        "Drools did not detect meaningful risk indicators. Maintain routine monitoring.",
      LOW_RISK:
        "Low-risk signals surfaced. Track user reports but no immediate action is required.",
      REVIEW: "Manual review recommended before trusting this URL.",
      SUSPICIOUS:
        "Suspicious heuristics detected. Investigate thoroughly before interacting.",
      PROBABLE_PHISHING:
        "High-confidence phishing patterns found. Treat as hostile and escalate.",
      CONFIRMED_PHISHING:
        "Critical indicators confirm a phishing attempt. Block and notify stakeholders immediately.",
    }),
    []
  );

  const submitUrl = useCallback(
    async (event, overrideUrl) => {
      if (event?.preventDefault) {
        event.preventDefault();
      }
      const candidate = overrideUrl ?? inputUrl;
      const sanitizedUrl = candidate.trim();
      if (!sanitizedUrl) {
        setError("Please provide a URL to analyze.");
        return;
      }

      setLoading(true);
      setError(null);
      setHasSearched(true);
      setResults([]);

      try {
        let receivedResults = [];
        let riskLevel = "safe";
        let riskLabel = null;
        let riskCopy = null;
        let riskScore = 0;
        let redirectHops = null;
        let redirectMetrics = null;
        let triggeredCount = 0;
        let evaluatedCount = totalRules;

        if (engine === "drools") {
          const droolsEvaluation = await evaluateDroolsUrl(sanitizedUrl);
          receivedResults = droolsEvaluation.toRuleResults();
          riskLevel = droolsEvaluation.riskLevel();
          riskLabel = droolsEvaluation.riskLabel();
          riskCopy = droolsEvaluation.riskCopy();
          riskScore = droolsEvaluation.score;
          triggeredCount = droolsEvaluation.triggeredCount();
          evaluatedCount = droolsEvaluation.evaluatedCount();
        } else {
          const response = await api.post("/analyze-url", null, {
            params: { url: sanitizedUrl, engine },
          });
          receivedResults = response.data.results ?? [];
          riskLevel = response.data.risk_level ?? "safe";
          riskLabel = riskLabelMap[riskLevel] ?? null;
          riskCopy = riskCopyMap[riskLevel] ?? null;
          riskScore =
            typeof response.data.risk_score === "number"
              ? response.data.risk_score
              : 0;
          redirectHops =
            typeof response.data.redirect_hops === "number" &&
            Number.isFinite(response.data.redirect_hops)
              ? response.data.redirect_hops
              : null;
          redirectMetrics = response.data.redirect_metrics ?? null;
          triggeredCount = receivedResults.length;
        }

        const timestamp = new Date().toISOString();
        const record = {
          id:
            typeof crypto !== "undefined" && crypto.randomUUID
              ? crypto.randomUUID()
              : `${Date.now().toString(36)}-${Math.random()
                  .toString(36)
                  .slice(2, 8)}`,
          url: sanitizedUrl,
          engine,
          results: receivedResults,
          riskLevel,
          riskLabel: riskLabel ?? riskLabelMap[riskLevel] ?? "Risk unknown",
          riskCopy:
            riskCopy ?? riskCopyMap[riskLevel] ?? "Risk status unavailable.",
          riskScore,
          redirectHops,
          redirectMetrics,
          timestamp,
        };
        setResults(receivedResults);
        setAnalysisMeta({
          url: sanitizedUrl,
          triggered: triggeredCount,
          evaluated: evaluatedCount,
          engineId: engine,
          engineLabel: ENGINE_TITLES[engine] ?? engine,
          timestamp,
          riskLevel,
          riskLabel: riskLabel ?? riskLabelMap[riskLevel] ?? "Risk unknown",
          riskCopy:
            riskCopy ?? riskCopyMap[riskLevel] ?? "Risk status unavailable.",
          riskScore,
          redirectHops,
          redirectMetrics,
        });
        if (onRecordSearch) {
          onRecordSearch(record);
        }
      } catch (err) {
        setError("We could not analyze the URL. Try again.");
      } finally {
        setLoading(false);
      }
    },
    [engine, inputUrl, onRecordSearch, riskCopyMap, riskLabelMap, totalRules]
  );

  const handleEngineChange = useCallback(
    (engineId) => {
      if (onEngineChange) {
        onEngineChange(engineId);
      }
    },
    [onEngineChange]
  );

  useEffect(() => {
    if (!prefillRequest || !prefillRequest.url) {
      return;
    }

    const requestId = prefillRequest.id ?? prefillRequest.url;
    if (lastPrefillId.current === requestId) {
      return;
    }

    lastPrefillId.current = requestId;
    setInputUrl(prefillRequest.url);
    setResults([]);
    setAnalysisMeta(null);
    setError(null);
    setHasSearched(false);

    submitUrl(undefined, prefillRequest.url);
  }, [prefillRequest, submitUrl]);

  const redirectMetrics = analysisMeta?.redirectMetrics ?? null;
  const redirectUrls = Array.isArray(redirectMetrics?.redirect_urls)
    ? redirectMetrics.redirect_urls
    : [];
  const formatDecimal = (value, digits = 2) => {
    const numeric = typeof value === "number" ? value : Number(value);
    return Number.isFinite(numeric) ? numeric.toFixed(digits) : "—";
  };
  const formatInteger = (value) => {
    const numeric = typeof value === "number" ? value : Number(value);
    return Number.isFinite(numeric) ? Math.round(numeric) : "—";
  };
  const formatText = (value) => {
    if (!value) {
      return "—";
    }
    if (typeof value === "string" && value.trim().toLowerCase() === "unknown") {
      return "—";
    }
    return value;
  };

  return (
    <section className="url-search" aria-busy={loading}>
      <form className="url-search__form" onSubmit={submitUrl} noValidate>
        <label htmlFor="url-input" className="sr-only">
          URL to analyze
        </label>
        <input
          id="url-input"
          type="url"
          placeholder="Paste or type the suspicious URL"
          value={inputUrl}
          onChange={(event) => setInputUrl(event.target.value)}
          className="url-search__input"
          autoComplete="off"
          aria-required="true"
          disabled={loading}
        />
        <button
          type="submit"
          disabled={loading || !inputUrl.trim()}
          className="url-search__button"
        >
          {loading ? "Analyzing..." : "Analyze URL"}
        </button>
      </form>

      <header className="url-search__header">
        <h2 className="url-search__title">Real-time Phishing URL Scanner</h2>
        <p className="url-search__subtitle">
          Select the rule engine, analyze suspicious links, and get prioritized
          insights to accelerate your SOC response.
        </p>
      </header>

      <EngineSelector
        engine={engine}
        onChange={handleEngineChange}
        disabled={loading}
      />

      {analysisMeta && (
        <section className="analysis-meta" aria-label="Latest scan summary">
          <div className="analysis-meta__header">
            <h3 className="analysis-meta__title">Latest scan</h3>
            <span className="analysis-meta__time">
              {new Date(analysisMeta.timestamp).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
          </div>
          <p className="analysis-meta__url" title={analysisMeta.url}>
            {analysisMeta.url}
          </p>
          <div className="analysis-meta__stats">
            <div className="analysis-meta__stat">
              <span className="analysis-meta__stat-value">
                {analysisMeta.triggered}
              </span>
              <span className="analysis-meta__stat-label">Rules triggered</span>
            </div>
            <div className="analysis-meta__stat">
              <span className="analysis-meta__stat-value">
                {analysisMeta.evaluated}
              </span>
              <span className="analysis-meta__stat-label">Rules evaluated</span>
            </div>
            {Number.isFinite(analysisMeta.redirectHops) && (
              <div className="analysis-meta__stat">
                <span className="analysis-meta__stat-value">
                  {analysisMeta.redirectHops}
                </span>
                <span className="analysis-meta__stat-label">Redirect hops</span>
              </div>
            )}
          </div>
          <div className="analysis-meta__tags" role="status" aria-live="polite">
            <span className="analysis-meta__tag">
              {analysisMeta.engineLabel}
            </span>
            <span
              className={`analysis-meta__tag analysis-meta__tag--risk analysis-meta__tag--risk-${analysisMeta.riskLevel}`}
            >
              {analysisMeta.riskLabel ??
                riskLabelMap[analysisMeta.riskLevel] ??
                "Risk unknown"}
            </span>
            {redirectMetrics && (
              <span className="analysis-meta__tag analysis-meta__tag--classification">
                Redirect {redirectMetrics.classification} ·{" "}
                {redirectMetrics.confidence} confidence
              </span>
            )}
          </div>
          {redirectMetrics && (
            <div
              className="analysis-meta__insights"
              aria-label="Redirect chain insights"
            >
              <h4 className="analysis-meta__insightsTitle">
                Redirect chain details
              </h4>
              <ul className="analysis-meta__insightsList">
                <li className="analysis-meta__insightsItem">
                  <span>Landing host</span>
                  <strong title={redirectMetrics.final_url ?? undefined}>
                    {formatText(redirectMetrics.final_hostname)}
                  </strong>
                </li>
                <li className="analysis-meta__insightsItem">
                  <span>Expanded URL length</span>
                  <strong>
                    {formatInteger(redirectMetrics.final_url_length)}
                  </strong>
                </li>
                <li className="analysis-meta__insightsItem">
                  <span>Shorteners detected</span>
                  <strong>
                    {formatInteger(redirectMetrics.shortener_count)}
                  </strong>
                </li>
                <li className="analysis-meta__insightsItem">
                  <span>Domain diversity</span>
                  <strong>
                    {formatDecimal(redirectMetrics.diversity_ratio)}
                  </strong>
                </li>
                <li className="analysis-meta__insightsItem">
                  <span>Redirect score</span>
                  <strong>{formatDecimal(redirectMetrics.final_score)}</strong>
                </li>
                <li className="analysis-meta__insightsItem">
                  <span>Reputation component</span>
                  <strong>
                    {formatDecimal(redirectMetrics.reputation_component)}
                  </strong>
                </li>
              </ul>
            </div>
          )}
          {redirectUrls.length > 0 && (
            <div
              className="analysis-meta__redirectPath"
              aria-label="Redirect path"
            >
              <h4 className="analysis-meta__redirectPathTitle">
                Redirect path
              </h4>
              <ol className="analysis-meta__redirectPathList">
                {redirectUrls.map((redirectUrl, index) => (
                  <li
                    key={`${redirectUrl}-${index}`}
                    className="analysis-meta__redirectPathItem"
                  >
                    <span className="analysis-meta__redirectPathIndex">
                      {index + 1}
                    </span>
                    <span
                      className="analysis-meta__redirectPathUrl"
                      title={redirectUrl}
                    >
                      {redirectUrl}
                    </span>
                  </li>
                ))}
              </ol>
            </div>
          )}
          <p className="analysis-meta__riskCopy">
            {analysisMeta.riskCopy ??
              riskCopyMap[analysisMeta.riskLevel] ??
              "Risk status unavailable."}
            <span className="analysis-meta__riskScore" aria-label="Risk score">
              Score{" "}
              {Number.isFinite(analysisMeta.riskScore)
                ? analysisMeta.riskScore.toFixed(2)
                : "0.00"}
            </span>
          </p>
        </section>
      )}

      <ResultsPanel
        results={results}
        loading={loading}
        error={error}
        hasSearched={hasSearched}
        redirectMetrics={redirectMetrics}
      />
    </section>
  );
}
